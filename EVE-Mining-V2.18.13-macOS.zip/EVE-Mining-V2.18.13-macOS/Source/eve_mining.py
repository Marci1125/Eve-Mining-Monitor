"""EVE Mining V2.18.13: Python/Tkinter GUI with optional GitHub release notifications."""
from __future__ import annotations

import copy
import hashlib
from threading import Thread
from queue import SimpleQueue
from collections import Counter
from decimal import Decimal as D
from datetime import date, datetime, timedelta, timezone
import math
import os
from pathlib import Path
import sys
import time
import webbrowser
import tkinter as tk
from tkinter import font as tkfont
from tkinter import ttk, filedialog, messagebox, simpledialog

from mining_engine import (Engine, app_root, bundle_root, local_path, reject_link, janice,
                           parse_number, laser_count, price_age, SHIPS, BOOSTERS, MIN_TIME, MAX_REPROCESS_YIELD)
from local_audio import LocalAudio
from setup_tutorial import SetupTutorial
from mining_engine import belt_boost_history, belt_boost_estimates
from mining_engine import belt_scan_quantities, belt_scan_units, ice_belt_history, ore_belt_history, estimate_belt
from i18n import format_number, language, set_language, tr
from mining_engine import VERSION
from release_updates import UpdateCheckError, fetch_latest_release

BG, PANEL, MUTED, ACCENT = "#10161d", "#1e2732", "#8fa0b5", "#64e8b2"
COLORS = dict(red="#eb4b4b", orange="#ff9f43", yellow="#ffd237", green="#3abe78")


def isk(value):
    return f"{format_number(float(value) / (1000000000.0 if abs(value) >= 1000000000.0 else 1000000.0), ',.2f')} {('B' if abs(value) >= 1000000000.0 else 'M')}"


def label(parent, text="", **kwargs):
    return tk.Label(parent, text=text, bg=BG, fg="#f5f5f5", anchor="w", **kwargs)


def button(parent, text, command, **kwargs):
    return ttk.Button(parent, text=text, command=command, **kwargs)


def bind_cargo_menu(widget, menu):
    def popup(event):
        menu.tk_popup(event.x_root, event.y_root)
        return "break"

    widget.bind("<Button-3>", popup)
    if widget.tk.call("tk", "windowingsystem") == "aqua":
        widget.bind("<Button-2>", popup)
        widget.bind("<Control-Button-1>", popup)


def show_price_age(widget, as_of):
    date, outdated = price_age(as_of)
    suffix = tr(' · Outdated') if outdated else ""
    widget.configure(text=f"{tr('Last Price update: ')}{date}{suffix}", fg=COLORS["red"] if outdated else MUTED)


class Tooltip:
    def __init__(self, widget, text):
        self.widget, self.text, self.window = widget, text, None
        widget.bind("<Enter>", self.show)
        widget.bind("<Leave>", self.hide)
        widget.bind("<ButtonPress>", self.hide, add="+")

    def show(self, _=None):
        if not self.text or self.window:
            return
        self.window = tk.Toplevel(self.widget)
        self.window.overrideredirect(True)
        self.window.attributes("-topmost", True)
        self.window.geometry(f"+{self.widget.winfo_rootx()+10}+{self.widget.winfo_rooty()+25}")
        tk.Label(self.window, text=self.text, bg=PANEL, fg="white", justify="left", wraplength=440, padx=8, pady=6).pack()

    def hide(self, _=None):
        if self.window:
            self.window.destroy()
            self.window = None


class App:
    def __init__(self, root, engine=None, live=True):
        self.root, self.engine, self.live = root, engine or Engine(), live
        set_language(self.engine.state["Language"])
        self.audio = LocalAudio(self.engine.root)
        self.settings = None
        self.tutorial = SetupTutorial(self)
        self.tutorial_buttons = {}
        self.rows = []
        self.cargo_queued = False
        self.headline_at = self.saved_at = 0
        self.timer = None
        self.startup_update_timer = self.update_poll_timer = None
        self.update_queue = SimpleQueue()
        self.update_pending = self.update_failed = False
        self.available_release = self.update_dialog = None
        self.update_message = tr('No update check has been run this session.')
        root.title("EVE Mining V2.18.13 - Python")
        root.configure(bg=BG)
        root.option_add("*Font", "{Segoe UI} 9")
        root.resizable(False, False)
        self.style = ttk.Style(root)
        self.style.theme_use("clam")
        self.style.configure("TFrame", background=BG)
        self.style.configure("TLabel", background=BG, foreground="white")
        self.style.configure("TButton", background=PANEL, foreground="white", padding=(8, 3), borderwidth=1)
        self.style.map("TButton", background=[("active", "#304253")])
        self.style.configure("Header.TButton", width=0, padding=(5, 3))
        for button_style in ("TButton", "Header.TButton"):
            tutorial_style = "Tutorial." + button_style
            self.style.configure(tutorial_style, background="#ffda6a", foreground="#10161d",
                                 bordercolor="#fff0b5", lightcolor="#fff0b5", darkcolor="#c28b30")
            self.style.map(tutorial_style, background=[("pressed", "#e8b847"), ("active", "#fff0b5")])
        self.style.map("Tutorial.TNotebook.Tab", background=[("selected", "#f4cf75")],
                       foreground=[("selected", "#10161d")])
        self.style.configure("TCheckbutton", background=BG, foreground="white")
        self.style.map("TCheckbutton", background=[("active", BG)])
        self.style.configure("TNotebook", background=BG, borderwidth=0)
        self.style.configure("TNotebook.Tab", background=PANEL, foreground="white", padding=(12, 6))
        self.style.map("TNotebook.Tab", background=[("selected", "#304253")])
        self.style.configure("Treeview", background=PANEL, fieldbackground=PANEL, foreground="white", rowheight=25)
        self.style.configure("Treeview.Heading", background="#273343", foreground="white")
        self.style.map("Treeview", background=[("selected", "#314c60")])
        try:
            if sys.platform == "darwin":
                root.iconphoto(True, tk.PhotoImage(file=str(bundle_root() / "Corp-Logo.png")))
            else:
                root.iconbitmap(str(bundle_root() / "EVE-Mining.ico"))
        except tk.TclError:
            pass
        self.body = tk.Frame(root, bg=BG, padx=8, pady=5)
        self.body.pack(fill="both", expand=True)
        header = tk.Frame(self.body, bg=BG)
        header.pack(fill="x")
        label(header, tr('MINING INCOME - ESTIMATE'), font=("Segoe UI", 9)).pack(side="left")
        self.options_button = button(header, tr('Options'), self.open_settings, style="Header.TButton")
        self.options_button.pack(side="right")
        self.tutorial_buttons["options"] = self.options_button
        self.tutorial_buttons["reprocess"] = button(header, tr('Reprocess'), self.open_reprocessing, style="Header.TButton")
        self.tutorial_buttons["reprocess"].pack(side="right", padx=(0, 4))
        self.tutorial_buttons["rock"] = button(header, tr('Track Rock'), self.open_rock_tracker, style="Header.TButton")
        self.tutorial_buttons["rock"].pack(side="right", padx=(0, 4))
        totals = tk.Frame(self.body, bg=BG)
        totals.pack(fill="x", pady=(2, 0))
        self.headline = tk.Label(totals, text="0.00 M ISK/h", font=("Segoe UI", 22, "bold"), fg=ACCENT, bg=BG, anchor="w")
        self.headline.pack(side="left")
        free_group = tk.Frame(totals, bg=BG)
        free_group.pack(side="right")
        self.free = tk.Label(free_group, bg=BG, fg=ACCENT, justify="right", font=("Segoe UI", 8))
        self.free.pack(anchor="e")
        self.boost = tk.Label(free_group, bg=BG, fg=ACCENT, justify="right", font=("Segoe UI", 8))
        self.boost.pack(anchor="e")
        self.rock_status = tk.Label(free_group, bg=BG, anchor="e", justify="right", font=("Segoe UI", 8))
        Tooltip(self.boost, tr('Estimated from raw versus observed laser cycles. Booster ships may belong to other players; the fleet profile does not identify the boost source. Overlapping strengths may remain ambiguous.'))
        self.summary, self.prices = label(self.body), label(self.body, font=("Segoe UI", 8))
        self.summary.pack(fill="x", pady=(0, 1))
        price_line = tk.Frame(self.body, bg=BG)
        price_line.pack(fill="x")
        self.prices.destroy()
        self.prices = label(price_line, font=("Segoe UI", 8))
        self.prices.pack(side="left")
        self.price_age_label = label(price_line, font=("Segoe UI", 8))
        self.price_age_label.pack(side="right")
        self.graph = tk.Canvas(self.body, height=22, bg="#0c1219", highlightthickness=0)
        self.graph.pack(fill="x", pady=(4, 2))
        Tooltip(self.graph, tr('10 MIN TREND - estimated ISK/h per minute'))
        selectors = tk.Frame(self.body, bg=BG)
        selectors.pack(fill="x", pady=(3, 3))
        self.profile_var, self.mode_var = tk.StringVar(), tk.StringVar(value=self.engine.state["Mode"])
        self.profiles = ttk.Combobox(selectors, textvariable=self.profile_var, state="readonly", width=25)
        self.profiles.pack(side="left", fill="x", expand=True)
        self.profiles.bind("<<ComboboxSelected>>", lambda _: self.run(self.switch_profile))
        self.mode = ttk.Combobox(selectors, textvariable=self.mode_var, values=("ICE", "ORE"), state="readonly", width=6)
        self.mode.pack(side="left", padx=8)
        self.mode.bind("<<ComboboxSelected>>", lambda _: self.run(self.switch_mode))
        self.reset_all = button(selectors, tr('Reset all'), lambda: self.run(self.reset_everyone), width=9)
        self.reset_all.pack(side="right")
        self.tutorial_buttons["reset"] = self.reset_all
        reset_menu = tk.Menu(selectors, tearoff=False)
        reset_menu.add_command(label=tr('Confirm all displayed cargo values'), command=lambda: self.run(self.confirm_everyone))
        bind_cargo_menu(self.reset_all, reset_menu)
        self.fleet_canvas = tk.Canvas(self.body, bg=BG, highlightthickness=0, width=466)
        self.fleet_canvas.pack(fill="x")
        self.fleet_frame = tk.Frame(self.fleet_canvas, bg=BG)
        self.fleet_window = self.fleet_canvas.create_window(0, 0, window=self.fleet_frame, anchor="nw", width=450)
        self.fleet_frame.bind("<Configure>", lambda _: self.fleet_canvas.configure(scrollregion=self.fleet_canvas.bbox("all")))
        self.fleet_canvas.bind("<Configure>", lambda e: self.fleet_canvas.itemconfigure(self.fleet_window, width=e.width))
        controls = tk.Frame(self.body, bg=BG)
        controls.pack(fill="x", pady=(4, 1))
        self.tutorial_buttons["session"] = button(controls, tr('New session'), lambda: self.run(self.new_session))
        self.tutorial_buttons["session"].pack(side="left")
        self.compact = button(controls, tr('Expand'), self.toggle_compact)
        self.compact.pack(side="left", padx=7)
        self.top_var, self.attack_var = tk.BooleanVar(value=self.engine.state["Window"]["TopMost"]), tk.BooleanVar(value=self.engine.state["AttackSound"])
        ttk.Checkbutton(controls, text=tr('On top'), variable=self.top_var, command=lambda: self.run(self.set_top)).pack(side="left", padx=4)
        ttk.Checkbutton(controls, text=tr('Attack sound'), variable=self.attack_var, command=lambda: self.run(self.set_attack)).pack(side="right")
        second = tk.Frame(self.body, bg=BG)
        second.pack(fill="x", pady=1)
        self.pause_button = button(second, tr('Pause session'), lambda: self.run(self.pause_session), width=17)
        self.pause_button.pack(side="left")
        self.status = label(second, wraplength=300, justify="left", font=("Segoe UI", 8))
        self.status.pack(side="left", padx=(10, 0), fill="x", expand=True)
        footer = tk.Frame(self.body, bg=BG)
        footer.pack(fill="x", pady=(2, 0))
        try:
            self.logo = tk.PhotoImage(file=str(bundle_root() / "Corp-Logo.png")).subsample(32)
            tk.Label(footer, image=self.logo, bg=BG).pack(side="left", padx=(0, 7))
        except tk.TclError:
            self.logo = None
        link = label(footer, tr('Quick setup'), cursor="hand2", font=("Segoe UI", 8, "underline"))
        link.pack(side="left")
        link.bind("<Button-1>", lambda _: self.quick_setup())
        self.tutorial_buttons["ledger"] = button(footer, tr('Ledger'), self.open_ledger)
        self.tutorial_buttons["ledger"].pack(side="left", padx=(6, 0))
        self.tutorial_buttons["belt"] = button(footer, tr('Belt Estimate'), self.open_belt_estimate, style="Header.TButton")
        self.tutorial_buttons["belt"].pack(side="left", padx=(6, 0))
        self.version_label = label(footer, "V2.18.13 · Python", font=("Segoe UI", 8))
        self.version_label.pack(side="right")
        self.version_label.bind("<Button-1>", lambda _: self.show_update_dialog())
        self.sync_profiles()
        self.build_rows()
        position = self.engine.state["Window"]
        if position.get("Left", -1) >= 0 and position.get("Top", -1) >= 0:
            x, y = int(position["Left"]), int(position["Top"])
            if x < root.winfo_screenwidth() and y < root.winfo_screenheight(): root.geometry(f"+{x}+{y}")
        self.root.attributes("-topmost", self.top_var.get())
        self.root.protocol("WM_DELETE_WINDOW", self.close)
        self.refresh()
        if live:
            self.timer = root.after(1000, self.tick)
            if self.engine.state["CheckUpdatesOnStartup"]:
                self.startup_update_timer = root.after(1500, self.check_updates)
            if not self.engine.state["Profiles"] and not self.engine.state.get("TutorialDone"):
                root.after(250, self.start_first_run_tutorial)

    def check_updates(self, *, manual=False):
        if self.startup_update_timer is not None:
            self.root.after_cancel(self.startup_update_timer)
            self.startup_update_timer = None
        if self.update_pending or (not manual and not self.engine.state["CheckUpdatesOnStartup"]):
            return
        self.update_pending = True
        self.update_message = tr('Checking GitHub for updates…')
        self.update_failed = False
        self.refresh_update_settings()

        def check():
            try:
                release = fetch_latest_release(VERSION)
                self.update_queue.put((release, None, manual))
            except (UpdateCheckError, OSError, ValueError) as error:
                self.update_queue.put((None, str(error), manual))

        Thread(target=check, daemon=True).start()
        self.update_poll_timer = self.root.after(100, self.receive_update_check)

    def receive_update_check(self):
        self.update_poll_timer = None
        if self.update_queue.empty():
            self.update_poll_timer = self.root.after(100, self.receive_update_check)
            return
        release, error, manual = self.update_queue.get()
        self.update_pending = False
        if error:
            self.update_message = tr(error)
            self.update_failed = True
        else:
            self.update_failed = False
            if release["IsNewer"]:
                self.available_release = release
                self.update_message = tr('A new version is available: {version}').format(version=release["Tag"])
                self.version_label.configure(text=tr('Update {version}').format(version=release["Tag"]),
                                             fg=ACCENT, cursor="hand2", font=("Segoe UI", 8, "underline"))
                if manual or self.engine.state["CheckUpdatesOnStartup"]:
                    self.show_update_dialog()
            else:
                self.available_release = None
                if self.update_dialog is not None and self.update_dialog.winfo_exists():
                    self.update_dialog.destroy()
                self.version_label.configure(text="V2.18.13 · Python", fg="#f5f5f5", cursor="", font=("Segoe UI", 8))
                message = ('Your version is newer than the latest public release ({version}).' if release["IsOlder"]
                           else 'You are up to date ({version}).')
                self.update_message = tr(message).format(version=release["Tag"])
        self.refresh_update_settings()

    def refresh_update_settings(self):
        settings = self.settings
        if settings is not None and settings.window.winfo_exists() and hasattr(settings, "update_status"):
            settings.update_status.configure(text=self.update_message, fg=COLORS["red"] if self.update_failed else ACCENT)
            settings.update_check_button.state(["disabled"] if self.update_pending else ["!disabled"])

    def show_update_dialog(self):
        if self.available_release is None:
            return
        existing = self.update_dialog
        if existing is not None and existing.winfo_exists():
            if existing.release_tag == self.available_release["Tag"]:
                existing.lift()
                return
            existing.destroy()
        dialog = self.update_dialog = tk.Toplevel(self.root)
        dialog.release_tag = self.available_release["Tag"]
        dialog.title(tr('Update available'))
        dialog.transient(self.root)
        dialog.configure(bg=BG)
        panel = ttk.Frame(dialog, padding=18)
        panel.pack(fill="both", expand=True)
        label(panel, tr('A new version is available: {version}').format(version=self.available_release["Tag"]),
              font=("Segoe UI", 12, "bold"), wraplength=420).pack(anchor="w")
        label(panel, tr('Installed version: {version}').format(version="V2.18.13"),
              font=("Segoe UI", 9)).pack(anchor="w", pady=(8, 0))
        label(panel, tr('View the release notes and download the Windows or macOS package on GitHub.'),
              wraplength=420, justify="left").pack(anchor="w", pady=12)
        actions = ttk.Frame(panel)
        actions.pack(fill="x")
        button(actions, tr('Close'), dialog.destroy).pack(side="left")
        button(actions, tr('View update'), self.open_update_page).pack(side="right")
        dialog.bind("<Escape>", lambda _: dialog.destroy())

    def open_update_page(self):
        if self.available_release is None:
            return
        try:
            opened = webbrowser.open(self.available_release["Url"], new=2)
        except (webbrowser.Error, OSError):
            opened = False
        if not opened:
            parent = self.update_dialog if self.update_dialog is not None and self.update_dialog.winfo_exists() else self.root
            messagebox.showinfo(tr('View update'), self.available_release["Url"], parent=parent)


    def run(self, action):
        try:
            action()
            self.save()
        except Exception as exc:
            self.engine.notice = str(exc)
        self.refresh()

    def save(self):
        self.engine.state["Window"].update(Left=self.root.winfo_x(), Top=self.root.winfo_y())
        self.engine.save()
        self.saved_at = time.time()

    def poll(self):
        if self.engine.logs_available():
            self.engine.poll()
            self.play_alerts()

    def play_alerts(self):
        if self.engine.cargo_requested:
            self.cargo_queued = True
            self.engine.notice = self.engine.cargo_alert
        if self.engine.sound_requested:
            self.audio.play(self.engine.state["AttackTone"], self.engine.state["AttackVolume"], "attack")
        elif self.cargo_queued and not self.audio.busy:
            self.cargo_queued = False
            if self.engine.state["CargoSound"]:
                self.audio.play(self.engine.state["CargoTone"], self.engine.state["CargoVolume"], "cargo")
        elif not self.audio.busy:
            rock = self.engine.rock
            if rock and rock["DepletedPending"]:
                rock["DepletedPending"] = False
                self.play_saved_alert("Depleted")
            elif rock and rock["Pending"]:
                rock["Pending"] = False
                self.play_saved_alert("Rock")
            elif self.engine.attention_pending:
                self.engine.attention_pending.clear()
                self.play_saved_alert("Attention")

    def play_saved_alert(self, key):
        state = self.engine.state
        if state[key + "Sound"]:
            self.audio.play(state[key + "Tone"], state[key + "Volume"], key.lower())

    def tick(self):
        try:
            self.poll()
            self.engine.auto_pause(time.time())
            if time.time() - self.saved_at >= 5:
                self.save()
        except Exception as exc:
            self.engine.notice = str(exc)
        self.refresh()
        self.timer = self.root.after(1000, self.tick)

    def sync_profiles(self):
        self.profile_names = [p["Name"] for p in self.engine.state["Profiles"]]
        active = self.engine.state["ActiveProfile"]
        self.profiles["values"] = self.profile_names
        if active in self.profile_names:
            self.profiles.current(self.profile_names.index(active))
        else:
            self.profile_var.set("")
        self.mode_var.set(self.engine.state["Mode"])

    def switch_profile(self):
        index = self.profiles.current()
        if index < 0:
            return
        self.poll()
        if self.profile_names[index] != self.engine.state["ActiveProfile"]:
            self.engine.rock = None
        self.engine.activate(self.profile_names[index])
        self.sync_profiles()
        self.build_rows()

    def switch_mode(self):
        if self.mode_var.get() != self.engine.state["Mode"]:
            self.engine.rock = None
        self.engine.state["Mode"] = self.mode_var.get()
        if self.engine.current:
            self.engine.current["Mode"] = self.mode_var.get()

    def reset_everyone(self):
        self.poll()
        for m in self.engine.members:
            self.engine.reset(m)

    def confirm_everyone(self):
        self.poll()
        if any(self.engine.ship(m)["Unknown"] for m in self.engine.members):
            raise ValueError(tr('Correct uncounted cargo before confirming the fleet.'))
        for m in self.engine.members:
            self.engine.ship(m)["Known"] = True

    def reset_pilot(self, member):
        self.poll()
        self.engine.reset(member)

    def new_session(self):
        self.poll()
        self.engine.start_session(time.time())
        ledger = getattr(self, "ledger_window", None)
        if ledger is not None and ledger.winfo_exists():
            ledger.event_generate("<<LedgerRefresh>>")

    def pause_session(self):
        self.poll()
        self.engine.pause(not self.engine.paused, time.time())
        for activity in self.engine.activities.values():
            activity["Since"] = time.time()
        self.engine.notice = tr('Paused. Next mining yield resumes.') if self.engine.paused else tr('Session resumed; pause time excluded.')

    def set_top(self):
        self.root.attributes("-topmost", self.top_var.get())
        self.engine.state["Window"]["TopMost"] = self.top_var.get()

    def set_attack(self):
        self.engine.state["AttackSound"] = self.attack_var.get()

    def toggle_compact(self):
        self.run(lambda: self.engine.state["Window"].update(Compact=not self.engine.state["Window"]["Compact"]))
        self.build_rows()
        self.refresh()

    def build_rows(self):
        for widget in self.fleet_frame.winfo_children():
            widget.destroy()
        self.rows.clear()
        for column in range(getattr(self, "fleet_columns", 1)):
            self.fleet_frame.columnconfigure(column, weight=0, minsize=0, uniform="")
        small = self.engine.state["Window"]["Compact"]
        self.compact.configure(text=tr('Expand') if small else tr('Compact'))
        self.style.configure("Pilot.TButton", padding=(4, 0) if small else (8, 3))
        if self.engine.state["DisplayStyle"] == "gauges":
            self.build_gauge_rows(small)
            return
        if self.engine.state["DisplayStyle"] == "strip":
            self.build_strip_rows(small)
            return
        column_width = 464 if small else 660
        max_columns = max(1, (self.root.winfo_screenwidth() - 48) // column_width)
        self.fleet_columns = min(max_columns, max(1, math.ceil(len(self.engine.members) / 8)))
        per_column = max(1, math.ceil(len(self.engine.members) / self.fleet_columns))
        width = self.fleet_columns * column_width + 16
        self.layout_width = width
        self.root.minsize(width, 1)
        self.root.geometry(f"{width}x600")
        self.headline.configure(font=("Segoe UI", 18 if small else 22, "bold"))
        self.graph.configure(height=18 if small else 38)
        for column in range(self.fleet_columns):
            self.fleet_frame.columnconfigure(column, weight=1, uniform="pilots")
        for index, m in enumerate(self.engine.members):
            frame = tk.Frame(self.fleet_frame, bg=BG)
            frame.grid(row=index % per_column, column=index // per_column, sticky="ew",
                       padx=(0, 12 if index // per_column < self.fleet_columns - 1 else 0),
                       pady=(1 if small else 4, 0))
            top = tk.Frame(frame, bg=BG)
            top.pack(fill="x")
            name = label(top, m["Character"] + " - " + m["ShipClass"], font=("Segoe UI", 9, "bold"))
            reset = button(top, tr('Reset'), lambda member=m: self.run(lambda: self.reset_pilot(member)),
                           width=6, style="Pilot.TButton")
            reset.pack(side="right")
            name.pack(side="left")
            mined = label(top, font=("Segoe UI", 9, "bold"))
            mined.configure(fg=ACCENT)
            mined.pack(side="left", padx=(8, 0))
            info = tk.Frame(frame, bg=BG)
            info.pack(fill="x")
            bar = tk.Canvas(info if small else frame, width=78, height=4, highlightthickness=1,
                            highlightbackground=BG, highlightcolor=BG, bg="#2f3a47")
            bar.pack(side="left" if small else "top", fill="none" if small else "x", padx=(0, 6 if small else 0))
            text = label(info, font=("Segoe UI", 8), wraplength=column_width-110 if small else column_width-28,
                         justify="left")
            text.pack(side="left", fill="x", expand=True)
            detail = label(frame, font=("Segoe UI", 8)) if not small else None
            if detail:
                detail.pack(fill="x")
            tip = Tooltip(text, "")
            menu = tk.Menu(frame, tearoff=False)
            menu.add_command(label=tr('Set current cargo...'), command=lambda member=m: self.set_cargo(member))
            menu.add_command(label=tr('Confirm displayed cargo'), command=lambda member=m: self.run(lambda: self.confirm_cargo(member)))
            for widget in (name, text, bar):
                bind_cargo_menu(widget, menu)
            self.rows.append(dict(Member=m, Name=name, Yield=mined, Text=text, Bar=bar, Detail=detail, Tooltip=tip))
        if not self.rows:
            label(self.fleet_frame, tr('No active pilots. Open Options to configure your fleet.'), wraplength=440).pack(pady=15)
        self.root.update_idletasks()
        requested = self.fleet_frame.winfo_reqheight()
        self.fleet_canvas.configure(height=max(36, requested), width=width-16)
        self.root.update_idletasks()
        self.root.geometry(f"{width}x{self.body.winfo_reqheight()}")

    def build_gauge_rows(self, small):
        count = len(self.engine.members)
        # Four cards on a typical small fleet; add columns for larger fleets.
        card_width = 136 if small else 164
        available = max(3, (self.root.winfo_screenwidth() - 48) // card_width)
        self.fleet_columns = min(available, max(3, min(4, count), math.ceil(count / 3)))
        width = self.fleet_columns * card_width + 16
        self.layout_width = width
        self.root.minsize(width, 1)
        self.root.geometry(f"{width}x600")
        self.headline.configure(font=("Segoe UI", 18 if small else 22, "bold"))
        self.graph.configure(height=18 if small else 38)
        for column in range(self.fleet_columns):
            self.fleet_frame.columnconfigure(column, weight=1, uniform="pilots")
        for index, member in enumerate(self.engine.members):
            frame = tk.Frame(self.fleet_frame, bg=BG, highlightthickness=1, highlightbackground="#2f3a47", padx=2, pady=1 if small else 2)
            frame.grid(row=index // self.fleet_columns, column=index % self.fleet_columns,
                       sticky="nsew", padx=1 if small else 2, pady=1 if small else 2)
            capacity = label(frame, font=("Segoe UI", 8))
            capacity.configure(anchor="center")
            capacity.pack(fill="x")
            gauge = tk.Canvas(frame, width=122 if small else 150, height=48 if small else 56, bg=BG, highlightthickness=0)
            gauge.pack()
            text = label(frame, font=("Segoe UI", 8), wraplength=card_width-12, justify="center")
            text.configure(anchor="center")
            text.pack(fill="x")
            name = label(frame, member["Character"], font=("Segoe UI", 8 if small else 9, "bold"), wraplength=card_width-12, justify="center")
            name.configure(anchor="center")
            name.pack(fill="x")
            card_controls = tk.Frame(frame, bg=BG)
            card_controls.pack(fill="x", pady=(1, 0))
            ship_label = label(card_controls, member["ShipClass"], font=("Segoe UI", 8))
            ship_label.configure(anchor="center", fg=MUTED)
            ship_label.pack(side="left")
            reset = button(card_controls, tr('Reset'), lambda m=member: self.run(lambda: self.reset_pilot(m)), width=6, style="Pilot.TButton")
            reset.pack(side="right")
            detail = None
            if not small:
                detail = label(frame, font=("Segoe UI", 8), wraplength=150, justify="center")
                detail.pack(fill="x")
            tip = Tooltip(gauge, "")
            menu = tk.Menu(frame, tearoff=False)
            menu.add_command(label=tr('Set current cargo...'), command=lambda m=member: self.set_cargo(m))
            menu.add_command(label=tr('Confirm displayed cargo'), command=lambda m=member: self.run(lambda: self.confirm_cargo(m)))
            for widget in (gauge, capacity, name, text, ship_label):
                bind_cargo_menu(widget, menu)
            self.rows.append(dict(Member=member, Name=name, Text=text, Bar=gauge, Detail=detail,
                                  Tooltip=tip, Gauge=True, Capacity=capacity, Yield=None))
        if not count:
            label(self.fleet_frame, tr('No active pilots. Open Options to configure your fleet.')).grid(columnspan=self.fleet_columns, pady=15)
        self.root.update_idletasks()
        self.fleet_canvas.configure(height=max(36, self.fleet_frame.winfo_reqheight()), width=width-16)
        self.root.update_idletasks()
        self.root.geometry(f"{width}x{self.body.winfo_reqheight()}")

    def build_strip_rows(self, small):
        count = len(self.engine.members)
        card_width = 136 if small else 172
        available = max(1, (self.root.winfo_screenwidth() - 48) // card_width)
        self.fleet_columns = min(available, max(3, min(4, count), math.ceil(count / 3)))
        self.layout_width = self.fleet_columns * card_width + 16
        self.root.minsize(self.layout_width, 1)
        self.root.geometry(f"{self.layout_width}x600")
        self.headline.configure(font=("Segoe UI", 18 if small else 22, "bold"))
        self.graph.configure(height=18 if small else 38)
        name_font = tkfont.Font(root=self.root, family="Segoe UI", size=8, weight="bold")
        for column in range(self.fleet_columns):
            self.fleet_frame.columnconfigure(column, weight=1, uniform="pilots")
        for index, member in enumerate(self.engine.members):
            frame = tk.Frame(self.fleet_frame, bg=BG)
            frame.grid(row=index // self.fleet_columns, column=index % self.fleet_columns,
                       sticky="nsew", padx=2, pady=2)
            tile = tk.Canvas(frame, width=card_width-4, height=44, bg=PANEL, highlightthickness=0)
            tile.pack(fill="x")
            reset = button(tile, "↺", lambda m=member: self.run(lambda: self.reset_pilot(m)), style="Pilot.TButton")
            tile.create_window(card_width-7, 41, anchor="se", window=reset, width=23, height=19, tags="reset")
            Tooltip(reset, tr('Reset cargo'))
            menu = tk.Menu(frame, tearoff=False)
            menu.add_command(label=tr('Set current cargo...'), command=lambda m=member: self.set_cargo(m))
            menu.add_command(label=tr('Confirm displayed cargo'), command=lambda m=member: self.run(lambda: self.confirm_cargo(m)))
            bind_cargo_menu(tile, menu)
            detail = None
            if not small:
                detail = label(frame, font=("Segoe UI", 8), wraplength=card_width-10)
                detail.pack(fill="x")
            self.rows.append(dict(Member=member, Name=None, Yield=None, Text=None, Bar=tile,
                                  Detail=detail, Tooltip=Tooltip(tile, ""), Strip=True, NameFont=name_font))
        if not count:
            label(self.fleet_frame, tr('No active pilots. Open Options to configure your fleet.')).grid(columnspan=self.fleet_columns, pady=15)
        self.root.update_idletasks()
        self.fleet_canvas.configure(height=max(36, self.fleet_frame.winfo_reqheight()), width=self.layout_width-16)
        self.root.update_idletasks()
        self.root.geometry(f"{self.layout_width}x{self.body.winfo_reqheight()}")

    def draw_strip(self, row, ratio, color, value, info, attacked, highlighted):
        tile = row["Bar"]
        width, height = int(tile["width"]), int(tile["height"])
        fill = {"green": "#236445", "yellow": "#6b5717", "orange": "#86411a", "red": "#922f3b"}
        tile.delete("paint")
        if ratio > 0:
            tile.create_rectangle(1, 1, 1+(width-2)*ratio, height-1, fill=fill[color], outline="", tags="paint")
        tile.create_rectangle(0, 0, width-1, height-1, outline="#fff3c4" if highlighted else "#465364", tags="paint")
        font = row["NameFont"]
        name = row["Member"]["Character"]
        space = width-20-font.measure(value)
        if font.measure(name) > space:
            while name and font.measure(name+"…") > space:
                name = name[:-1]
            name += "…"
        tile.create_text(6, 12, anchor="w", text=name, fill="#fa8072" if attacked else "white", font=font, tags="paint")
        tile.create_text(width-6, 12, anchor="e", text=value, fill="white", font=font, tags="paint")
        tile.create_text(6, 32, anchor="w", text=info, fill="#f5f6f8", font=("Segoe UI", 8), tags="paint")
        tile.tag_raise("reset")

    def draw_gauge(self, row, ratio, color, quantity, flags, highlighted, compressed_ratio=0):
        canvas = row["Bar"]
        canvas.delete("all")
        edge = "#fff3c4" if highlighted else BG
        canvas.configure(highlightbackground=edge, highlightcolor=edge, highlightthickness=1)
        small = int(canvas["width"]) < 150
        center = int(canvas["width"]) / 2
        radius, top, center_y, status_y = (36, 7, 30, 43) if small else (45, 9, 36, 51)
        box = (center-radius, top, center+radius, top+radius*2)
        arc_width = 8 if small else 10
        canvas.create_arc(*box, start=180, extent=-180, style="arc", width=arc_width, outline="#2f3a47")
        if ratio > compressed_ratio:
            canvas.create_arc(*box, start=180*(1-compressed_ratio), extent=-180*(ratio-compressed_ratio),
                              style="arc", width=arc_width, outline=COLORS[color])
        if compressed_ratio > 0:
            canvas.create_arc(*box, start=180, extent=-180*compressed_ratio, style="arc",
                              width=arc_width, outline=MUTED, dash=(3, 2), tags="compressed")
        percent = 100 if ratio >= 1 else min(99, round(ratio*100))
        status = " · ".join(flags)
        if quantity:
            canvas.create_text(center, center_y, text=f"+{format_number(quantity, ',.0f')}", fill=COLORS["yellow"] if "CRIT" in flags else ACCENT,
                               font=("Segoe UI", 12 if small else 13, "bold"))
        else:
            canvas.create_text(center, center_y, text=f"{percent}%", fill=COLORS[color], font=("Segoe UI", 12 if small else 14, "bold"))
        if status:
            short = tr('FULL') if ratio >= 1 else tr('ATTACK') if tr('ATTACK') in flags else tr('CHECK') if any(f in flags for f in (tr('IRREGULAR'), tr('VERIFY CARGO'), tr('UNCOUNTED'))) else tr('CARGO') if color in ("orange", "red") else tr("CRIT") if "CRIT" in flags else tr("RESET")
            canvas.create_text(center, status_y, text=short, fill=COLORS[color], font=("Segoe UI", 7, "bold"))

    def confirm_cargo(self, member):
        self.poll()
        ship = self.engine.ship(member)
        if ship["Unknown"]:
            raise ValueError(tr('Correct uncounted cargo first.'))
        ship["Known"] = True

    def set_cargo(self, member):
        self.run(self.poll)
        ship = self.engine.ship(member)
        result = simpledialog.askstring(tr('Set current cargo'), tr('Current cargo in m³ (Reset is for an empty hold):'), initialvalue=str(ship["Volume"]), parent=self.root)
        if result is None:
            return
        def apply():
            value = parse_number(result)
            if not 0 <= value <= 1000000000:
                raise ValueError(tr('Cargo must be 0 to 1,000,000,000 m³.'))
            self.poll()
            self.engine.reset(member)
            ship.update(Volume=value, UnassignedVolume=value)
            if self.engine.state["Mode"] == "ICE":
                ship["Units"] = ship["IceBlocks"] = value / 1000
        self.run(apply)

    def refresh(self):
        now, combat = time.time(), ""
        highlight_now = time.monotonic()
        for row in self.rows:
            m = row["Member"]
            quantity = self.engine.recent_yield(m["Character"], highlight_now)
            if row["Yield"] is not None:
                row["Yield"].configure(text=f"+{format_number(quantity, ',.0f')}" if quantity else "")
            ship = self.engine.ship(m)
            ratio = self.engine.hold_ratio(ship)
            warning, color = self.engine.activity_warning(m, now), self.engine.color(ship, now)
            flags = []
            if color == "red": flags.append(tr('FULL') if ratio >= 1 else tr('CARGO'))
            elif color == "orange": flags.append(tr('CARGO'))
            if ship["CriticalUntil"] > now and color != "red": flags.append("CRIT")
            if warning: flags.append(tr('IRREGULAR'))
            if not ship["Known"]: flags.append(tr('VERIFY CARGO'))
            if ship["Unknown"]: flags.append(tr('UNCOUNTED'))
            if self.engine.unload_highlights.get(m["Character"], 0) > highlight_now:
                flags.append(tr('Auto-reset: unloaded'))
            attack = self.engine.attacks.get(m["Character"])
            attacked = attack and now - attack["Time"] <= 45
            if row["Name"] is not None:
                row["Name"].configure(fg="#fa8072" if attacked else "white")
            if attacked:
                flags.insert(0, tr('ATTACK'))
                combat = f"{tr('UNDER ATTACK: ')}{m['Character']}"
                combat += f" - {attack['Attacker']}"
            free = max(D(0), ship["Capacity"] - ship["Volume"])
            eta, _ = self.engine.eta(m, now)
            compact = self.engine.state["Window"]["Compact"]
            percent = 100 if ratio >= 1 else min(99, round(ratio*100))
            text = (" | ".join(flags) + " | " if flags else "") + (
                f"{format_number(ship['Volume'], ',.0f')}/{format_number(ship['Capacity'], ',.0f')} m³ · {percent}%" if compact else
                f"{format_number(ship['Volume'], ',.0f')} / {format_number(ship['Capacity'], ',.0f')} m³ ({percent}%)")
            if self.engine.state["Mode"] == "ICE": text += f" | {format_number(int(free // 1000), ',')}{tr(' blocks fit')}"
            text += " | " + eta
            if row.get("Gauge"):
                row["Capacity"].configure(text=f"{format_number(ship['Volume'], ',.0f')} / {format_number(ship['Capacity'], ',.0f')} m³")
                info = f"{format_number(int(free // 1000), ',')}{tr(' fit')}" if self.engine.state["Mode"] == "ICE" else f"{format_number(free, ',.0f')}{tr(' m³ free')}"
                visible_flags = [f for f in flags if f not in (tr('FULL'), tr('CARGO'), "CRIT")]
                text = info + " · " + eta + ("\n" + " · ".join(visible_flags) if visible_flags else "")
            if row["Text"] is not None:
                row["Text"].configure(text=text, fg="#ffa500" if warning or not ship["Known"] or ship["Unknown"] else MUTED)
            bar = row["Bar"]
            border = "#fff3c4" if self.engine.cargo_highlights.get(m["Character"], 0) > highlight_now else BG
            bar.configure(highlightbackground=border, highlightcolor=border)
            compressed_volume = D(0)
            if row.get("Strip"):
                short_flags = {tr('IRREGULAR'): tr('CHECK'), tr('VERIFY CARGO'): tr("CHECK"), tr('UNCOUNTED'): tr('UNCOUNTED'),
                               tr('Auto-reset: unloaded'): tr('UNLOADED'), tr('ATTACK'): tr('ATTACK')}
                info = next((short_flags[flag] for flag in flags if flag in short_flags), eta)
                value = f"+{format_number(quantity, ',.0f')}" if quantity else f"{percent}%"
                self.draw_strip(row, ratio, color, value, info, attacked, border != BG)
            elif row.get("Gauge"):
                compressed_volume = self.engine.compressed_hold_volume(ship)
                compressed_ratio = ratio * float(compressed_volume / ship["Volume"]) if ship["Volume"] > 0 else 0
                self.draw_gauge(row, ratio, color, quantity, flags, border != BG, compressed_ratio)
            else:
                bar.delete("all")
                bar.create_rectangle(1, 1, 1 + max(1, bar.winfo_width() - 2) * min(1, max(0, ratio)), 5, fill=COLORS[color], outline="")
            cycle = self.engine.cycle(m, now)
            detail = f"{tr('Cycle ~')}{cycle['Seconds']:.1f}s ({cycle['Source']}{tr('); raw reference ')}{m.get('CycleSeconds', 0):.1f}s" if laser_count(m) else tr('Boost-only ship; mining activity hints disabled.')
            if row["Detail"]: row["Detail"].configure(text=detail, fg=MUTED)
            row["Tooltip"].text = f"{format_number(free, ',.2f')}{tr(' m³ free\n')}" + " · ".join(flags) + f"\n{detail}"
            row["Tooltip"].text += f"{tr('\nLast: ')}{ship['Last']}"
            row["Tooltip"].text += f"\n{warning}"
            row["Tooltip"].text += f"\n{ship['Unknown']}"
            if compressed_volume:
                row["Tooltip"].text = f"{tr('Tracked compressed cargo: ')}{format_number(compressed_volume, ',.2f')} m³\n{row['Tooltip'].text}"
            if row.get("Strip"):
                cargo = f"{m['Character']} · {m['ShipClass']}\n{format_number(ship['Volume'], ',.0f')} / {format_number(ship['Capacity'], ',.0f')} m³ ({percent}%)"
                row["Tooltip"].text = f"{cargo} · {eta}\n{row['Tooltip'].text}"
        # Wrapped warnings can make a row taller. Keep the whole fleet visible.
        self.root.update_idletasks()
        requested = max(36, self.fleet_frame.winfo_reqheight())
        if int(self.fleet_canvas["height"]) != requested:
            self.fleet_canvas.configure(height=requested)
        income = self.engine.income(now)
        if self.engine.rate_refresh or now - self.headline_at >= 60:
            self.headline.configure(text=isk(income["Rate"]) + " ISK/h")
            self.headline_at, self.engine.rate_refresh = now, False
        self.headline.configure(fg=MUTED if self.engine.paused else ACCENT)
        seconds = int(income["Seconds"])
        self.summary.configure(text=(tr('PAUSED | ') if self.engine.paused else "") + f"{tr('Session ')}{isk(income['Value'])} ISK | {seconds // 3600:02}:{seconds % 3600 // 60:02}:{seconds % 60:02} | {format_number(income['Units'], ',.0f')}{tr(' units mined')}")
        partial = income["Missing"] or income["Unsupported"]
        price_label = f"{tr('Reprocessed BUY (')}{format_number(MAX_REPROCESS_YIELD, '.2f')}%)"
        self.prices.configure(text=price_label + (tr(' · PARTIAL') if partial else tr(' · before fees')),
                              fg="#ffa500" if partial else MUTED)
        show_price_age(self.price_age_label, self.engine.state["LastPriceUpdate"])
        free = self.engine.free_fleet()
        self.free.configure(text=(f"{tr('Miners free: ')}{format_number(free['Blocks'], ',')}/{format_number(free['TotalBlocks'], ',')}{tr(' ice blocks')}" if self.engine.state["Mode"] == "ICE" else f"{tr('Miners free: ')}{format_number(free['Volume'], ',.0f')}/{format_number(free['Capacity'], ',.0f')} m³"), fg=COLORS[self.engine.fleet_capacity_color(free)])
        self.boost.configure(text=tr('Verify cargo values first') if free["Unconfirmed"] else self.engine.boost_label(now))
        self.pause_button.configure(text=tr('Resume session') if self.engine.paused else tr('Pause session'))
        status = tr(self.engine.notice)
        self.status.configure(text=combat or status, fg="#fa8072" if combat else MUTED)
        self.refresh_rock()
        self.root.update_idletasks()
        height = self.body.winfo_reqheight()
        if self.root.winfo_width() != self.layout_width or self.root.winfo_height() != height:
            self.root.geometry(f"{self.layout_width}x{height}")
        canvas, values = self.graph, self.engine.trend(now)
        width, height = max(100, canvas.winfo_width()), int(canvas["height"])
        canvas.delete("all")
        canvas.create_line(0, height-2, width, height-2, fill="#3e576a")
        maximum = max(1, max(values))
        points = [coordinate for i, value in enumerate(values) for coordinate in (4+i*(width-8)/9, height-5-value/maximum*(height-12))]
        canvas.create_line(*points, fill=ACCENT, width=1.5)
        if self.settings and self.settings.window.winfo_exists():
            self.settings.update_free()
            show_price_age(self.settings.price_age_label, self.engine.state["LastPriceUpdate"])
        reprocess_age = getattr(self, "reprocess_price_age_label", None)
        if reprocess_age is not None and reprocess_age.winfo_exists():
            show_price_age(reprocess_age, self.engine.state["LastPriceUpdate"])

    def refresh_reprocessing_prices(self):
        dialog = getattr(self, "reprocess_window", None)
        if dialog is not None and dialog.winfo_exists():
            dialog.event_generate("<<PricesChanged>>")

    def material_label(self, name):
        return self.engine.german_materials.get(name, name) if language() == "de" else name

    def refresh_rock(self):
        rock = self.engine.rock
        if rock is None:
            self.rock_status.pack_forget()
            return
        available = self.layout_width - self.headline.winfo_reqwidth() - 28
        self.rock_status.configure(wraplength=max(100, min(260, available)))
        if not self.rock_status.winfo_manager():
            self.rock_status.pack(anchor="e")
        remaining = rock["Remaining"]
        if rock["Material"] is None:
            text = tr('{count} units · waiting for first mining yield').format(count=format_number(remaining, ",.0f"))
            self.rock_status.configure(text=text, fg=MUTED)
            return
        color = COLORS["red"] if remaining == 0 else COLORS["orange"] if remaining <= rock["Threshold"] else MUTED
        text = tr('{material} · ~{remaining}/{initial} units left').format(
            material=self.material_label(rock["Material"]),
            remaining=format_number(remaining, ",.0f"), initial=format_number(rock["Initial"], ",.0f"))
        self.rock_status.configure(text=text, fg=color)

    def open_rock_tracker(self):
        dialog = tk.Toplevel(self.root)
        dialog.title(tr('Track rock · Experimental'))
        dialog.configure(bg=BG)
        dialog.transient(self.root)
        rock = self.engine.rock
        units = ttk.Entry(dialog, width=12)
        label(dialog, tr('The first mining yield identifies the material. Aim the tracked lasers at the same rock for the estimate.'),
              wraplength=390, justify="left").grid(row=0, column=0, columnspan=2, sticky="w", padx=12, pady=10)
        label(dialog, tr('Units remaining now')).grid(row=1, column=0, sticky="w", padx=12, pady=5)
        units.grid(row=1, column=1, sticky="w", padx=12, pady=5)
        actions = ttk.Frame(dialog)
        actions.grid(row=2, column=0, columnspan=2, sticky="ew", padx=12, pady=10)

        def start():
            try:
                amount = parse_number(units.get())
                self.poll()
                self.engine.start_rock(amount, time.time())
            except (ArithmeticError, ValueError, OSError) as exc:
                message = tr('Enter a whole number of units from 1 to 1,000,000,000.') if isinstance(exc, ArithmeticError) else str(exc)
                messagebox.showerror(tr('Track rock · Experimental'), message, parent=dialog)
                return
            dialog.destroy()
            self.refresh()

        def stop():
            self.engine.rock = None
            dialog.destroy()
            self.refresh()

        if rock:
            button(actions, tr('Stop tracking'), stop).pack(side="left")
        button(actions, tr('Start tracking'), start).pack(side="right")
        dialog.bind("<Return>", lambda _: start())
        dialog.bind("<Escape>", lambda _: dialog.destroy())
        dialog.grab_set()
        units.focus_set()

    def open_belt_estimate(self):
        existing = getattr(self, "belt_window", None)
        if existing is not None and existing.winfo_exists():
            existing.lift()
            return
        dialog = self.belt_window = tk.Toplevel(self.root)
        dialog.title(tr('Belt Estimate'))
        dialog.transient(self.root)
        dialog.configure(bg=BG)
        panel = ttk.Frame(dialog, padding=12)
        panel.pack(fill="both", expand=True)
        label(panel, tr('Paste the copied survey rows. The estimate uses the active ICE or ORE fleet.'), wraplength=560).pack(anchor="w")
        scan = tk.Text(panel, width=68, height=9, bg=PANEL, fg="white", insertbackground="white", wrap="none")
        scan.pack(fill="both", expand=True, pady=8)
        reference_controls = ttk.Frame(panel)
        reference_controls.pack(fill="x")
        reference_result = label(panel, justify="left", wraplength=560)
        reference_result.pack(fill="x", pady=(6, 0))
        label(panel, tr('Reference scans use observed quantities. Initial spawn size is unverified.'),
              font=("Segoe UI", 8), wraplength=560).pack(fill="x", pady=(3, 6))

        def read_scan():
            mode = self.engine.state["Mode"]
            names = {name for name, item in self.engine.items.items()
                     if item["Mode"] == mode and item["Volume"] > 0
                     and not name.startswith(("Compressed ", "Batch Compressed ", "Ancient Compressed "))}
            names.update(self.engine.german_materials.get(name, name) for name in tuple(names))
            parsed = belt_scan_quantities(scan.get("1.0", "end"), names)
            quantities = Counter()
            for name, quantity in parsed.items():
                quantities[self.engine.canonical_material(name)] += quantity
            return mode, quantities

        def compare_scan():
            try:
                mode, quantities = read_scan()
                reference = self.engine.state["BeltReferences"].get(mode)
                if not reference:
                    reference_result.configure(text=tr('No reference for this mode. Paste a complete scan and use it as 100%.'), fg=MUTED)
                    return quantities
                missing = sorted(set(quantities) - set(reference))
                if missing:
                    message = tr('Reference does not include {materials}. Save a matching reference scan.').format(
                        materials=", ".join(self.material_label(name) for name in missing))
                    reference_result.configure(text=message, fg=COLORS["orange"])
                    return quantities
                volumes = {name: 1 if mode == "ICE" else self.engine.items[name]["Volume"] for name in reference}
                total = sum(D(str(amount)) * volumes[name] for name, amount in reference.items())
                current = sum(D(amount) * volumes[name] for name, amount in quantities.items())
                if total <= 0:
                    raise ValueError(tr('Save a reference scan with at least one unit.'))
                ratio = current / total
                unit = tr('blocks') if mode == "ICE" else "m³"
                lines = [tr('Belt remaining vs reference: {percent} · {current} / {total} {unit}').format(
                    percent=format_number(ratio, ".2%"), current=format_number(current, ",.0f"),
                    total=format_number(total, ",.0f"), unit=unit)]
                for name, amount in sorted(reference.items()):
                    count = quantities.get(name, 0)
                    share = D(count) / D(str(amount)) if amount else D(0)
                    lines.append(f"{self.material_label(name)} · {format_number(count, ',.0f')} / {format_number(D(str(amount)), ',.0f')} · {format_number(share, '.2%')}")
                exceeds = ratio > 1 or any(D(quantities.get(name, 0)) > D(str(amount)) for name, amount in reference.items())
                if exceeds:
                    lines.append(tr('Scan exceeds the reference. Check that both scans cover the same belt.'))
                reference_result.configure(text="\n".join(lines), fg=COLORS["orange"] if exceeds else ACCENT)
                return quantities
            except (ValueError, ArithmeticError, KeyError, TypeError) as error:
                message = str(error) if isinstance(error, ValueError) else tr('Save a valid reference scan for this mode.')
                reference_result.configure(text=message, fg=COLORS["red"])
                return None

        def save_reference():
            try:
                mode, quantities = read_scan()
            except ValueError as error:
                reference_result.configure(text=str(error), fg=COLORS["red"])
                return
            references = self.engine.state["BeltReferences"]
            previous = dict(references)
            references[mode] = dict(quantities)
            try:
                self.save()
            except (OSError, ValueError) as error:
                self.engine.state["BeltReferences"] = previous
                reference_result.configure(text=str(error), fg=COLORS["red"])
                return
            compare_scan()

        button(reference_controls, tr('Compare scan'), compare_scan).pack(side="left")
        button(reference_controls, tr('Use scan as 100%'), save_reference).pack(side="left", padx=8)
        reference_result.configure(text=tr('Paste a complete belt scan to compare its remaining amount with the saved reference.'))
        controls = ttk.Frame(panel)
        controls.pack(fill="x")
        label(controls, tr('Minutes of fleet downtime per unload')).pack(side="left")
        minutes = ttk.Entry(controls, width=6)
        minutes.insert(0, "1.5")
        minutes.pack(side="left", padx=8)
        result = label(panel, justify="left", wraplength=560)
        result.pack(fill="x", pady=(8, 0))

        def calculate():
            if compare_scan() is None:
                result.configure(text="")
                return
            try:
                mode = self.engine.state["Mode"]
                miners = [copy.deepcopy(m) for m in self.engine.members if laser_count(m) and m["Capacity"] >= 1000]
                holds = {m["Character"]: int(m["Capacity"] // 1000) if mode == "ICE" else m["Capacity"]
                         for m in miners}
                if not holds or not self.engine.logs_available():
                    raise ValueError(tr('Configure a mining fleet and select your Gamelogs folder first.'))
                volumes = {name: item["Volume"] for name, item in self.engine.items.items()
                           if item["Mode"] == mode and item["Volume"] > 0
                           and (mode != "ICE" or item["Volume"] == 1000)
                           and not name.startswith(("Compressed ", "Batch Compressed ", "Ancient Compressed "))}
                scan_volumes = {name: 1 if mode == "ICE" else volume for name, volume in volumes.items()}
                scan_volumes.update({self.engine.german_materials.get(name, name): volume
                                     for name, volume in scan_volumes.items()})
                units = belt_scan_units(scan.get("1.0", "end"), scan_volumes)
                downtime = parse_number(minutes.get().strip().replace(",", "."))
                if not 0 <= downtime <= 60:
                    raise ValueError(tr('Enter 0 to 60 minutes of downtime.'))
                result.configure(text=tr('Reading mining history…'), fg=MUTED)
                folder = Path(self.engine.state["Folder"])
                max_gaps = {m["Character"]: max(90, 2 * float(m.get("CycleSeconds", 0))) for m in miners}
            except (ValueError, ArithmeticError) as error:
                result.configure(text=str(error) if isinstance(error, ValueError) else tr('Enter 0 to 60 minutes of downtime.'),
                                 fg=COLORS["red"])
                return
            except OSError:
                result.configure(text=tr('Could not read your Gamelogs.'), fg=COLORS["red"])
                return
            calculate_button.state(["disabled"])
            finished = SimpleQueue()

            def read_history():
                try:
                    if mode == "ICE":
                        history = ice_belt_history(folder, holds, volumes, self.engine.canonical_material, self.engine.read_file)
                        residue = 0
                    else:
                        history, residue = ore_belt_history(
                            folder, max_gaps, volumes, self.engine.canonical_material, self.engine.read_file)
                    values = estimate_belt(units, downtime, holds, history, mode=mode, residue=residue)
                    try:
                        normalized = belt_boost_history(folder, miners, volumes, self.engine.canonical_material, self.engine.read_file)
                        volume_holds = {name: capacity * 1000 if mode == "ICE" else capacity for name, capacity in holds.items()}
                        comparisons = belt_boost_estimates(units * 1000 if mode == "ICE" else units, downtime, volume_holds, normalized)
                    except (ValueError, ArithmeticError, OSError) as error:
                        comparisons = str(error) if isinstance(error, ValueError) else tr('Could not read your Gamelogs.')
                    finished.put((values, history[0], None, comparisons))
                except (ValueError, ArithmeticError, OSError) as error:
                    message = str(error) if isinstance(error, ValueError) else tr('Could not read your Gamelogs.')
                    finished.put((None, 0, message, None))

            def show_result():
                if finished.empty():
                    dialog.after(100, show_result)
                    return
                values, samples, error, comparisons = finished.get()
                calculate_button.state(["!disabled"])
                if error:
                    result.configure(text=error, fg=COLORS["red"])
                    return
                render_estimate(units, values, samples, len(holds), mode, comparisons)

            Thread(target=read_history, daemon=True).start()
            dialog.after(100, show_result)

        def render_estimate(units, values, samples, pilots, mode, comparisons):
            active, cargo, loads, stops, total = values

            def duration(value):
                hours, remainder = divmod(round(value), 60)
                return f"{hours}:{remainder:02d} h"

            if mode == "ICE":
                belt_label = '{amount} blocks in the belt · {time} mining time'
                cargo_label = 'About {cargo} cargo blocks including crits · {loads} fleet loads'
                sample_label = 'Based on {samples} complete fills. Projected for {pilots} miners.'
                digits = ",.0f"
            else:
                belt_label = '{amount} m³ in the belt · {time} mining time'
                cargo_label = 'About {cargo} m³ of cargo including crits · {loads} fleet loads'
                sample_label = 'Based on {samples} continuous ore mining samples. Projected for {pilots} miners.'
                digits = ",.2f"
            lines = [
                tr(belt_label).format(amount=format_number(units, digits), time=duration(active)),
                tr(cargo_label).format(cargo=format_number(cargo, digits), loads=format_number(loads, ".1f")),
                tr('{time} total · {stops} unload stops before depletion').format(time=duration(total), stops=stops),
                tr(sample_label).format(samples=samples, pilots=pilots),
            ]
            lines.extend(["", tr('Boost comparison · estimated total including unloads')])
            if isinstance(comparisons, str):
                lines.append(comparisons)
            else:
                for estimate in comparisons:
                    lines.append(tr('{ship} · {reduction} cycle reduction · {time} total · {mining} mining').format(
                        ship=estimate["Ship"], reduction=format_number(estimate["Reduction"], ".2%"),
                        time=duration(estimate["TotalMinutes"]), mining=duration(estimate["MiningMinutes"])))
                lines.append(tr('Max skills, Burst II + mindlink. Porpoise core off, Orca / Rorqual T2 core on.'))
                lines.append(tr('Based on configured raw cycles and stable log samples. Detected small drone yields keep their observed rate.'))
            result.configure(text="\n".join(lines), fg=ACCENT)

        calculate_button = button(controls, tr('Calculate'), calculate)
        calculate_button.pack(side="left")
        scan.focus_set()

    def open_ledger(self):
        existing = getattr(self, "ledger_window", None)
        if existing is not None and existing.winfo_exists():
            existing.lift()
            existing.event_generate("<<LedgerRefresh>>")
            return
        dialog = self.ledger_window = tk.Toplevel(self.root)
        dialog.title(tr('Mining Ledger'))
        dialog.transient(self.root)
        dialog.configure(bg=BG)
        dialog.geometry("920x640")
        dialog.minsize(820, 510)
        panel = ttk.Frame(dialog, padding=12)
        panel.pack(fill="both", expand=True)
        filters = ttk.Frame(panel)
        filters.pack(fill="x")
        today = datetime.now(timezone.utc).date()
        auto_start, auto_end = (today - timedelta(days=7)).isoformat(), today.isoformat()
        start, end = tk.StringVar(value=auto_start), tk.StringVar(value=auto_end)
        date_entries = []
        session_only = tk.BooleanVar(value=False)
        for title, value in (('From (UTC)', start), ('To (UTC)', end)):
            ttk.Label(filters, text=tr(title)).pack(side="left")
            entry = ttk.Entry(filters, width=12, textvariable=value)
            entry.pack(side="left", padx=(4, 10))
            date_entries.append(entry)
        material = ttk.Combobox(filters, state="readonly", width=26)
        material.pack(side="left", padx=(0, 8))
        button(filters, tr('Refresh'), lambda: refresh()).pack(side="left")
        self.style.configure("LedgerScope.Toolbutton", background=PANEL, foreground="white", padding=(8, 3))
        self.style.map("LedgerScope.Toolbutton", background=[("selected", "#304253"), ("active", "#304253")],
                       foreground=[("selected", ACCENT)])
        ttk.Checkbutton(filters, text=tr('Current session'), variable=session_only, command=lambda: refresh(),
                        style="LedgerScope.Toolbutton").pack(side="left", padx=(8, 0))
        scope_hint = label(panel, font=("Segoe UI", 8))
        scope_hint.pack(fill="x", pady=(4, 0))
        summary = label(panel, font=("Segoe UI", 9, "bold"))
        summary.pack(fill="x", pady=(8, 4))
        charts = ttk.Frame(panel)
        charts.pack(fill="x")
        charts.columnconfigure((0, 1), weight=1, uniform="ledger")
        material_frame = ttk.Frame(charts)
        material_frame.grid(row=0, column=0, sticky="nsew", padx=(0, 5))
        material_frame.columnconfigure(0, weight=1)
        material_frame.rowconfigure(0, weight=1)
        material_chart = tk.Canvas(material_frame, bg=PANEL, width=360, height=205, highlightthickness=0)
        material_scroll = ttk.Scrollbar(material_frame, orient="vertical", command=material_chart.yview)
        material_chart.configure(yscrollcommand=material_scroll.set)
        day_chart = tk.Canvas(charts, bg=PANEL, width=360, height=205, highlightthickness=0)
        material_chart.grid(row=0, column=0, sticky="nsew")
        day_chart.grid(row=0, column=1, sticky="nsew", padx=(5, 0))
        table_frame = ttk.Frame(panel)
        table_frame.pack(fill="both", expand=True, pady=(10, 0))
        self.style.configure("Ledger.Treeview", rowheight=30)
        columns = ("date", "quantity", "volume", "crits", "bonus", "extra")
        table = ttk.Treeview(table_frame, columns=columns, show="tree headings", style="Ledger.Treeview")
        table.heading("#0", text=tr('Material'), anchor="w")
        table.column("#0", width=215, minwidth=150)
        titles = ('Date (UTC)', 'Quantity', 'Volume (m³)', 'Crits', 'Bonus units', '% extra')
        for key, title, width in zip(columns, titles, (108, 95, 115, 60, 95, 80)):
            anchor = "w" if key == "date" else "e"
            table.heading(key, text=tr(title), anchor=anchor)
            table.column(key, width=width, minwidth=width, anchor=anchor, stretch=False)
        scroll = ttk.Scrollbar(table_frame, orient="vertical", command=table.yview)
        table.configure(yscrollcommand=scroll.set)
        scroll.pack(side="right", fill="y")
        table.pack(side="left", fill="both", expand=True)
        icons, color_cache = {}, {}
        chart_data = Counter(), {}, {}, Counter(), {}
        selections = [("all", None), ("mode", "ICE"), ("mode", "ORE")]
        hover_text = tk.StringVar()
        hover_label = label(panel, textvariable=hover_text, font=("Segoe UI", 8))
        hover_label.configure(fg=MUTED)
        hover_label.pack(fill="x", pady=(4, 0))
        hover_text.set(tr('Hover over a chart for material quantities.'))

        def item_icon(name, size):
            key = name, size
            if key not in icons:
                item = self.engine.items.get(name)
                icons[key] = None
                if item:
                    path = bundle_root() / "mined-icons" / f"{item['TypeId']}.png"
                    try:
                        image = tk.PhotoImage(master=dialog, file=str(path))
                        scale = max(1, math.ceil(max(image.width(), image.height()) / size))
                        icons[key] = image if scale == 1 else image.subsample(scale)
                    except tk.TclError:
                        pass
            return icons[key]

        def critical_color(name):
            return "#61e8e1" if self.engine.items.get(name, {}).get("Mode") == "ORE" else COLORS["yellow"]

        def material_color(name):
            if name not in color_cache:
                # Stable colors keep each material recognizable across filters and restarts.
                mode = self.engine.items.get(name, {}).get("Mode")
                palette = ("#79d1e8", "#b0f2f5", "#ced6f7", "#a4b6d1", "#69a8d6", "#8ed6cb") if mode == "ICE" else (
                    "#d15a45", "#e18b48", "#bd783d", "#edaf69", "#b96850", "#caac72")
                fixed = {"Dark Glitter": "#79d1e8", "Clear Icicle IV-Grade": "#b0f2f5",
                         "Glare Crust": "#ced6f7", "Gelidus": "#a4b6d1"}
                digest = hashlib.sha256(name.encode("utf-8")).digest()
                color = palette[int.from_bytes(digest[:4], "big") % len(palette)]
                shade = .86 + digest[4] / 255 * .24
                channels = [min(255, round(int(color[i:i + 2], 16) * shade)) for i in (1, 3, 5)]
                color_cache[name] = fixed.get(name, "#" + "".join(f"{channel:02x}" for channel in channels))
            return color_cache[name]

        def refresh():
            nonlocal chart_data, selections, auto_start, auto_end
            selected = material.current()
            selected_kind, selected_name = selections[selected] if 0 <= selected < len(selections) else selections[0]
            today = datetime.now(timezone.utc).date()
            for value, previous, updated in (
                (start, auto_start, (today - timedelta(days=7)).isoformat()),
                (end, auto_end, today.isoformat()),
            ):
                if value.get() == previous:
                    value.set(updated)
            auto_start, auto_end = (today - timedelta(days=7)).isoformat(), today.isoformat()
            for entry in date_entries:
                entry.state(["disabled"] if session_only.get() else ["!disabled"])
            scope_hint.configure(text=tr('Current session · all pilots · since New session.') if session_only.get() else
                                 tr('Date range · UTC (GMT+0) · YYYY-MM-DD. Blank From includes undated history.'))
            try:
                date_texts = ("", "") if session_only.get() else (value.get().strip() for value in (start, end))
                first, last = (date.fromisoformat(value).isoformat() if value else "" for value in date_texts)
                if first and last and first > last:
                    raise ValueError
            except ValueError:
                summary.configure(text=tr('Enter a valid date range using YYYY-MM-DD.'), fg=COLORS["red"])
                return
            try:
                rows, unreadable, crits, bonuses = self.engine.ledger_rows(
                    include_criticals=True, current_session=session_only.get())
            except (OSError, ValueError):
                summary.configure(text=tr('Could not read the session archive.'), fg=COLORS["red"])
                return
            names = sorted({name for _, name in rows}, key=self.material_label)
            selections = [("all", None), ("mode", "ICE"), ("mode", "ORE"), *(("item", name) for name in names)]
            material.configure(values=[tr('All materials'), tr('Ice materials'), tr('Ore materials'),
                                       *(self.material_label(name) for name in names)])
            choice = selected_kind, selected_name
            material.current(selections.index(choice) if choice in selections else 0)
            selected_kind, selected_name = selections[material.current()]
            table.delete(*table.get_children())
            totals, daily, daily_materials = Counter(), Counter(), {}
            bonus_totals, daily_bonuses = Counter(), {}
            crit_total, bonus_total = 0, D(0)
            for (day, name), quantity in sorted(rows.items(), reverse=True):
                item = self.engine.items.get(name)
                if selected_kind == "item" and name != selected_name:
                    continue
                if selected_kind == "mode" and (not item or item.get("Mode") != selected_name):
                    continue
                if day and ((first and day < first) or (last and day > last)):
                    continue
                if not day and first:
                    continue
                totals[name] += quantity
                if day:
                    daily[day] += quantity
                    daily_materials.setdefault(day, Counter())[name] += quantity
                volume = format_number(quantity * item["Volume"], ",.2f") if item else "—"
                crit_count, bonus = crits[day, name], bonuses[day, name]
                bonus_totals[name] += min(quantity, max(D(0), bonus))
                if day:
                    daily_bonuses.setdefault(day, Counter())[name] = min(quantity, max(D(0), bonus))
                regular = quantity - bonus
                extra = format_number(bonus / regular, ".2%") if crit_count and regular > 0 else "—"
                crit_total += crit_count
                bonus_total += bonus
                image = item_icon(name, 24)
                table.insert("", "end", text=self.material_label(name), image=image or "", values=(
                    day or tr('Date unavailable'), format_number(quantity, ",.0f"), volume,
                    format_number(crit_count, ",.0f") if crit_count else "—",
                    format_number(bonus, ",.0f") if crit_count else "—", extra))
            summary_text = tr('{count} units mined · all pilots').format(count=format_number(sum(totals.values()), ",.0f"))
            summary_text += " · " + tr('{count} recorded crits · {bonus} bonus units').format(
                count=format_number(crit_total, ",.0f"), bonus=format_number(bonus_total, ",.0f"))
            if unreadable:
                summary_text += " · " + tr('{count} archive files could not be read').format(count=unreadable)
            summary.configure(text=summary_text, fg=COLORS["orange"] if unreadable else ACCENT)
            chart_data = totals, daily, daily_materials, bonus_totals, daily_bonuses
            content_height = max(205, 43 + 27 * len(totals))
            chart_height = min(content_height, max(205, dialog.winfo_screenheight() - 430))
            material_chart.configure(height=chart_height, scrollregion=(0, 0, 0, content_height))
            material_chart.yview_moveto(0)
            day_chart.configure(height=chart_height)
            if content_height > chart_height:
                material_scroll.grid(row=0, column=1, sticky="ns")
            else:
                material_scroll.grid_remove()
            minimum_height = min(dialog.winfo_screenheight() - 100, chart_height + 280)
            dialog.minsize(820, max(510, minimum_height))
            desired_height = max(dialog.winfo_height(), min(dialog.winfo_screenheight() - 100, chart_height + 390))
            dialog.geometry(f"{dialog.winfo_width()}x{desired_height}")
            draw_charts()

        def hover(canvas, text):
            canvas.tag_bind("hover", "<Leave>", lambda _: hover_text.set(tr('Hover over a chart for material quantities.')))
            for item_id, description in text.items():
                canvas.tag_bind(item_id, "<Enter>", lambda _, value=description: hover_text.set(value))

        def draw_charts(_event=None):
            totals, daily, daily_materials, bonus_totals, daily_bonuses = chart_data
            for canvas, title in ((material_chart, 'Quantity by material'), (day_chart, 'Daily quantity · UTC')):
                canvas.delete("all")
                canvas.create_text(10, 13, text=tr(title), anchor="w", fill="white")
            width = max(350, material_chart.winfo_width())
            maximum = max(totals.values(), default=1) or 1
            descriptions = {}
            for index, (name, quantity) in enumerate(totals.most_common()):
                y = 31 + index * 27
                description = f"{self.material_label(name)} · {format_number(quantity, ',.0f')}"
                description += " · " + tr('{count} critical bonus units').format(count=format_number(bonus_totals[name], ",.0f"))
                image = item_icon(name, 22)
                if image:
                    item_id = material_chart.create_image(20, y + 9, image=image, tags="hover")
                    descriptions[item_id] = description
                item_id = material_chart.create_text(36, y + 9, text=self.material_label(name), anchor="w", fill="white", width=132, font=("Segoe UI", 8), tags="hover")
                descriptions[item_id] = description
                end_x = 175 + float(quantity / maximum) * (width - 250)
                item_id = material_chart.create_rectangle(175, y + 2, end_x, y + 17, fill=material_color(name), outline="", tags="hover")
                descriptions[item_id] = description
                if bonus_totals[name] > 0:
                    bonus_x = 175 + float((quantity - bonus_totals[name]) / maximum) * (width - 250)
                    item_id = material_chart.create_rectangle(bonus_x, y + 2, end_x, y + 17,
                                                              fill=critical_color(name), outline="", tags=("hover", "critical-bonus"))
                    descriptions[item_id] = description
                material_chart.create_text(width - 9, y + 9, text=format_number(quantity, ",.0f"), anchor="e", fill="white")
            modes = {self.engine.items.get(name, {}).get("Mode") for name in totals}
            legend = []
            if "ICE" in modes:
                legend.append(("Ice crit bonus", COLORS["yellow"]))
            if "ORE" in modes:
                legend.append(("Ore crit bonus", "#61e8e1"))
            legend_y = max(198, 32 + 27 * len(totals))
            for index, (title, color) in enumerate(legend):
                x = 11 + index * 145
                material_chart.create_rectangle(x, legend_y - 3, x + 9, legend_y + 4, fill=color, outline="")
                material_chart.create_text(x + 16, legend_y, text=tr(title), anchor="w", fill=MUTED, font=("Segoe UI", 8))
            hover(material_chart, descriptions)
            if not daily:
                day_chart.create_text(10, 55, text=tr('No dated mining recorded for this selection.'), anchor="w", fill=MUTED)
                return
            dates = sorted(daily)
            start_day, end_day = map(date.fromisoformat, (dates[0], dates[-1]))
            width = max(350, day_chart.winfo_width())
            span = (end_day - start_day).days
            baseline = max(153, day_chart.winfo_height() - 52)
            left, right, height = 50, width - 16, baseline - 50
            scale = max(daily.values()) or 1
            for fraction in (0, .5, 1):
                y = baseline - height * fraction
                day_chart.create_line(left, y, right, y, fill="#35404c")
                value = scale * D(str(fraction))
                text = f"{float(value) / 1000:.1f}k" if value >= 1000 else format_number(value, ",.0f")
                day_chart.create_text(left - 6, y, text=text, anchor="e", fill=MUTED, font=("Segoe UI", 8))
            bar_width = max(2, min(24, (right - left) / (span + 1) * .65))
            descriptions = {}
            for day in dates:
                offset = (date.fromisoformat(day) - start_day).days
                x = left + 16 + (right - left - 32) * (offset / span if span else .5)
                y = baseline
                for name, quantity in sorted(daily_materials[day].items()):
                    top = y - height * float(quantity / scale)
                    item_id = day_chart.create_rectangle(x - bar_width / 2, top, x + bar_width / 2, y,
                                                        fill=material_color(name), outline="", tags="hover")
                    description = f"{day} UTC · {self.material_label(name)} · {format_number(quantity, ',.0f')}"
                    bonus = daily_bonuses.get(day, {}).get(name, D(0))
                    description += " · " + tr('{count} critical bonus units').format(count=format_number(bonus, ",.0f"))
                    descriptions[item_id] = description
                    if bonus > 0:
                        item_id = day_chart.create_rectangle(x - bar_width / 2, top, x + bar_width / 2,
                                                             top + height * float(bonus / scale),
                                                             fill=critical_color(name), outline="", tags=("hover", "critical-bonus"))
                        descriptions[item_id] = description
                    y = top
            day_chart.create_text(left, baseline + 14, text=dates[0], anchor="w", fill=MUTED, font=("Segoe UI", 8))
            if span:
                day_chart.create_text(right, baseline + 14, text=dates[-1], anchor="e", fill=MUTED, font=("Segoe UI", 8))
            for index, (name, _) in enumerate(totals.most_common(3)):
                x = 14 + index * ((width - 20) / 3)
                image = item_icon(name, 18)
                if image:
                    item_id = day_chart.create_image(x + 8, baseline + 37, image=image, tags="hover")
                    descriptions[item_id] = self.material_label(name)
                item_id = day_chart.create_text(x + 21, baseline + 37, text=self.material_label(name)[:17], anchor="w",
                                                fill=material_color(name), font=("Segoe UI", 8), tags="hover")
                descriptions[item_id] = self.material_label(name)
            hover(day_chart, descriptions)

        def scroll_materials(event):
            steps = int(-event.delta / 120) if abs(event.delta) >= 120 else (-1 if event.delta > 0 else 1)
            material_chart.yview_scroll(steps, "units")

        material_chart.bind("<MouseWheel>", scroll_materials)
        material_chart.bind("<Button-4>", lambda _: material_chart.yview_scroll(-1, "units"))
        material_chart.bind("<Button-5>", lambda _: material_chart.yview_scroll(1, "units"))
        material.bind("<<ComboboxSelected>>", lambda _: refresh())
        dialog.bind("<Return>", lambda _: refresh())
        dialog.bind("<<LedgerRefresh>>", lambda _: refresh())
        material_chart.bind("<Configure>", draw_charts)
        day_chart.bind("<Configure>", draw_charts)
        dialog.update_idletasks()
        refresh()


    def open_reprocessing(self, *, example=False):
        existing = None if example else getattr(self, "reprocess_window", None)
        if existing is not None and existing.winfo_exists():
            existing.lift()
            return
        dialog = tk.Toplevel(self.root)
        if not example:
            self.reprocess_window = dialog
        dialog.title(tr('Reprocess example') if example else tr('Reprocess — current mining session'))
        dialog.transient(self.root)
        dialog.configure(bg=BG)
        dialog.geometry("900x680")
        dialog.minsize(720, 550)
        panel = tk.Frame(dialog, bg=BG, padx=16, pady=12)
        panel.pack(fill="both", expand=True)
        label(panel, tr('REPROCESSING ESTIMATE'), font=("Segoe UI", 15, "bold")).pack(anchor="w")
        subtitle = 'Example mining data · before tax' if example else 'Current session · all pilots · before tax'
        label(panel, tr(subtitle)).pack(anchor="w", pady=(0, 10))

        metadata = self.engine.reprocessing_metadata
        icons = {}

        def item_icon(name, mined):
            if mined:
                item = self.engine.items.get(name)
                if item is None:
                    return None
                path = bundle_root() / "mined-icons" / f"{item['TypeId']}.png"
            else:
                path = bundle_root() / "reprocess-icons" / f"{name}.png"
            if path not in icons:
                try:
                    image = tk.PhotoImage(master=dialog, file=str(path))
                    scale = max(1, math.ceil(max(image.width(), image.height()) / 32))
                    icons[path] = image if scale == 1 else image.subsample(scale)
                except tk.TclError:
                    icons[path] = None
            return icons[path]

        def make_table(title):
            label(panel, title, font=("Segoe UI", 10, "bold")).pack(anchor="w", pady=(4, 3))
            frame = ttk.Frame(panel)
            frame.pack(fill="both", expand=True)
            self.style.configure("Reprocess.Treeview", rowheight=35)
            table = ttk.Treeview(frame, columns=("Amount", "Volume", "Buy", "Sell"),
                                 show="tree headings", height=4, style="Reprocess.Treeview")
            table.heading("#0", text=tr("Item"), anchor="w")
            table.column("#0", width=240, minwidth=150)
            for column, title, width in (("Amount", "Amount", 90), ("Volume", tr('Volume (m³)'), 120),
                                         ("Buy", tr('Buy total (ISK)'), 145), ("Sell", tr('Sell total (ISK)'), 145)):
                table.heading(column, text=tr(title), anchor="e")
                table.column(column, width=width, minwidth=75, anchor="e", stretch=False)
            scroll = ttk.Scrollbar(frame, orient="vertical", command=table.yview)
            table.configure(yscrollcommand=scroll.set)
            scroll.pack(side="right", fill="y")
            table.pack(side="left", fill="both", expand=True)
            summary = label(panel, font=("Segoe UI", 9, "bold"))
            summary.pack(anchor="w", pady=(4, 6))
            return table, summary

        def fill_table(table, summary, quantities, volumes, mined_materials=False):
            table.delete(*table.get_children())
            total_volume = total_buy = total_sell = D(0)
            priced_buy = priced_sell = known_volume = 0
            for name, quantity in sorted(quantities.items()):
                unit_volume = volumes.get(name)
                volume = quantity * D(str(unit_volume)) if unit_volume is not None else None
                if volume is not None:
                    total_volume += volume
                    known_volume += 1
                unit_buy, unit_sell = self.engine.reprocessing_quote(name, mined_material=mined_materials)
                buy = quantity * unit_buy if unit_buy is not None else None
                sell = quantity * unit_sell if unit_sell is not None else None
                if buy is not None:
                    total_buy += buy
                    priced_buy += 1
                if sell is not None:
                    total_sell += sell
                    priced_sell += 1
                values = (f"{format_number(quantity, ',')}", *(f"{format_number(value, ',.2f')}" if value is not None else "—"
                                               for value in (volume, buy, sell)))
                icon = item_icon(name, mined=mined_materials)
                options = {"image": icon} if icon else {}
                table.insert("", "end", text=self.material_label(name), values=values, **options)
            volume_note = f"{format_number(total_volume, ',.2f')} m³" if known_volume else "—"
            if 0 < known_volume < len(quantities):
                volume_note += tr(' (partial)')
            buy_text = f"{format_number(total_buy, ',.2f')} ISK" if priced_buy else "—"
            sell_text = f"{format_number(total_sell, ',.2f')} ISK" if priced_sell else "—"
            if 0 < priced_buy < len(quantities): buy_text += tr(' (partial)')
            if 0 < priced_sell < len(quantities): sell_text += tr(' (partial)')
            prices = f"{tr('Buy ')}{buy_text}{tr('   ·   Sell ')}{sell_text}"
            summary.configure(text=f"{tr('Volume ')}{volume_note}   ·   {prices}")

        inputs, input_total = make_table(tr('Mined materials'))
        controls = tk.Frame(panel, bg=BG)
        controls.pack(fill="x", pady=(4, 8))
        label(controls, tr('Yield (%)')).pack(side="left")
        yield_text = tk.StringVar(value=getattr(self, "reprocess_yield", str(MAX_REPROCESS_YIELD)))
        entry = ttk.Entry(controls, textvariable=yield_text, width=9)
        entry.pack(side="left", padx=8)
        calculate = button(controls, tr('Calculate / refresh'), lambda: refresh_result())
        calculate.pack(side="left")
        outputs, output_total = make_table(tr('Estimated products'))
        notes = label(panel, wraplength=850, justify="left")
        notes.pack(anchor="w")
        sample_date, _ = price_age(metadata["AsOfUtc"])
        label(panel, f"{tr('Imported BUY prices take priority · fallback quotes use Janice samples from ')}{sample_date}{tr('\nInput quotes use compressed equivalents')}", justify="left").pack(anchor="w", pady=(6, 0))
        age_label = label(panel, font=("Segoe UI", 9))
        age_label.pack(anchor="w")
        show_price_age(age_label, self.engine.state["LastPriceUpdate"])
        if not example:
            self.reprocess_price_age_label = age_label
        input_volumes = {name: item["Volume"] for name, item in self.engine.items.items()}

        def refresh_result():
            mined = {"Dark Glitter": D(100), "Gelidus": D(50), "Loparite": D(600)} if example else self.engine.session_mined_quantities()
            fill_table(inputs, input_total, mined, input_volumes, mined_materials=True)
            try:
                value = D(yield_text.get().strip().replace(",", "."))
                if example:
                    if not value.is_finite() or not 0 < value <= 100:
                        raise ValueError
                    products, leftovers, unsupported = self.engine.reprocess_quantities(mined, value)
                else:
                    products, leftovers, unsupported = self.engine.reprocess_session(value)
                    self.reprocess_yield = str(value)
            except (ArithmeticError, ValueError):
                fill_table(outputs, output_total, {}, metadata["Volumes"])
                notes.configure(text=tr('Enter a yield above 0 and up to 100%, for example 90.63.'))
                return
            fill_table(outputs, output_total, products, metadata["Volumes"])
            details = []
            if not products:
                details.append(tr('No products from complete batches at this yield.'))
            for title, quantities in ((tr('Left over'), leftovers), (tr('No recipe'), unsupported)):
                if quantities:
                    details.append(title + ": " + ", ".join(f"{self.material_label(name)} × {format_number(quantity, ',')}" for name, quantity in sorted(quantities.items())))
            notes.configure(text="\n".join(details))

        entry.bind("<Return>", lambda _: refresh_result())
        dialog.bind("<<PricesChanged>>", lambda _: refresh_result())
        refresh_result()
        return dialog

    def open_settings(self):
        if self.settings and self.settings.window.winfo_exists():
            self.settings.window.deiconify()
            self.settings.window.lift()
        else:
            self.settings = Settings(self)
        self.tutorial.options_opened()
        self.refresh_update_settings()

    def start_first_run_tutorial(self):
        if not self.engine.state['Profiles'] and not self.engine.state.get('TutorialDone'):
            self.tutorial.start()

    def quick_setup(self):
        messagebox.showinfo(tr('EVE Mining V2.18.13 - Quick setup'), tr('1. Options: choose your local Gamelogs folder.\n2. Add pilots from logs.\n3. Select pilots and use Edit selected to set ship class and actual cargo capacity.\n4. Set Lasers (0 disables hints) and raw unboosted cycle (0 = auto).\n5. Name your profile, choose ICE / ORE, then Save and activate.\n6. Confirm starting cargo: Reset if empty; right-click otherwise.\n7. Alerts: choose local cargo / attack sounds, test and save.\n\nAfter 5 minutes without mining, the session auto-pauses.\nPrices are an offline BUY snapshot; update by manual import.'), parent=self.root)

    def close(self):
        if self.timer: self.root.after_cancel(self.timer)
        try:
            if self.live: self.save()
        except Exception as exc:
            messagebox.showerror(tr('Could not save'), str(exc), parent=self.root)
            if self.live:
                self.timer = self.root.after(1000, self.tick)
            return
        for timer in (self.startup_update_timer, self.update_poll_timer):
            if timer is not None:
                self.root.after_cancel(timer)
        self.audio.close()
        self.root.destroy()


class Settings:
    def __init__(self, app):
        self.app, self.engine = app, app.engine
        self.tutorial_buttons = {}
        self.window = tk.Toplevel(app.root)
        self.window.title(tr('EVE Mining - Options'))
        self.window.configure(bg=BG)
        self.window.geometry("900x690")
        self.window.minsize(850, 650)
        self.window.transient(app.root)
        self.window.protocol("WM_DELETE_WINDOW", self.close)
        self.tabs = ttk.Notebook(self.window)
        self.tabs.pack(fill="both", expand=True, padx=10, pady=10)
        self.fleet, self.prices, self.alerts, self.display, self.languages, self.updates = [ttk.Frame(self.tabs, padding=12) for _ in range(6)]
        for frame, title in zip((self.fleet, self.prices, self.alerts, self.display, self.languages, self.updates),
                                (tr('Fleet profiles'), tr('Prices / Janice'), tr('Alerts'), tr('Display Style'), tr('Languages'), tr('Updates'))):
            self.tabs.add(frame, text=title)
        button(self.window, tr('Close'), self.close).pack(anchor="e", padx=12, pady=(0, 10))
        self.make_fleet()
        self.make_prices()
        self.make_alerts()
        self.make_display()
        self.make_languages()
        self.make_updates()

    def make_updates(self):
        parent = self.updates
        label(parent, tr('Updates'), font=("Segoe UI", 15, "bold")).pack(anchor="w", pady=(4, 8))
        label(parent, tr('Installed version: {version}').format(version="V2.18.13")).pack(anchor="w")
        self.update_startup = tk.BooleanVar(value=self.engine.state["CheckUpdatesOnStartup"])
        ttk.Checkbutton(parent, text=tr('Check for updates on startup'), variable=self.update_startup,
                        command=lambda: self.guarded(self.save_update_setting)).pack(anchor="w", pady=16)
        label(parent, tr('Queries the public GitHub Releases API. View update opens the release page in your browser.'),
              wraplength=760, justify="left").pack(anchor="w", pady=(0, 14))
        self.update_check_button = button(parent, tr('Check now'), lambda: self.app.check_updates(manual=True))
        self.update_check_button.pack(anchor="w")
        self.update_status = label(parent, wraplength=760, justify="left")
        self.update_status.pack(anchor="w", pady=14)
        self.app.refresh_update_settings()

    def save_update_setting(self):
        previous = self.engine.state["CheckUpdatesOnStartup"]
        self.engine.state["CheckUpdatesOnStartup"] = self.update_startup.get()
        try:
            self.app.save()
        except Exception:
            self.engine.state["CheckUpdatesOnStartup"] = previous
            self.update_startup.set(previous)
            raise
        if self.update_startup.get():
            self.app.check_updates()


    def make_languages(self):
        parent = self.languages
        label(parent, tr('Languages'), font=("Segoe UI", 15, "bold")).pack(anchor="w", pady=(4, 8))
        label(parent, tr('Choose the application language. English and German Gamelogs are read automatically.'),
              wraplength=800).pack(anchor="w", pady=(0, 12))
        self.language_choice = tk.StringVar(value="Deutsch" if self.engine.state["Language"] == "de" else "English")
        ttk.Combobox(parent, textvariable=self.language_choice, values=("English", "Deutsch"),
                     state="readonly", width=20).pack(anchor="w")
        button(parent, tr('Save language'), lambda: self.guarded(self.save_language)).pack(anchor="w", pady=12)
        button(parent, tr('Restart Tutorial'), self.app.tutorial.start).pack(anchor="w")

    def save_language(self):
        chosen = "de" if self.language_choice.get() == "Deutsch" else "en"
        previous = self.engine.state["Language"]
        self.engine.state["Language"] = chosen
        try:
            self.app.save()
        except Exception:
            self.engine.state["Language"] = previous
            raise
        messagebox.showinfo(tr("Languages"), tr("Language saved. Restart EVE Mining to apply it."), parent=self.window)

    def make_display(self):
        parent = self.display
        label(parent, tr('Display Style'), font=("Segoe UI", 15, "bold")).pack(anchor="w", pady=(4, 8))
        label(parent, tr('Choose the fleet view. All styles use the same tracking and alerts.')).pack(anchor="w", pady=(0, 16))
        self.display_style = tk.StringVar(value=self.engine.state["DisplayStyle"])
        for style, title in (("bars", tr('Style A — Bars')), ("gauges", tr('Style B — Gauges')), ("strip", tr('Style C — Fleet Strip'))):
            card = tk.Frame(parent, bg=PANEL, padx=12, pady=10)
            card.pack(fill="x", pady=6)
            ttk.Radiobutton(card, text=title, value=style, variable=self.display_style).pack(side="left", padx=(0, 20))
            preview = tk.Canvas(card, width=320, height=80, bg=PANEL, highlightthickness=0)
            preview.pack(side="right")
            if style == "bars":
                for i, (ratio, color) in enumerate(((.61, "green"), (.45, "yellow"), (.90, "orange"))):
                    y = i*25+8
                    preview.create_text(5, y+4, text=f"{tr('Pilot ')}{i + 1:02}", anchor="w", fill="white")
                    preview.create_rectangle(75, y, 265, y+9, fill="#2f3a47", outline="")
                    preview.create_rectangle(75, y, 75+190*ratio, y+9, fill=COLORS[color], outline="")
                    preview.create_text(300, y+4, text=f"{ratio:.0%}", fill="white")
            elif style == "gauges":
                for i, (ratio, color) in enumerate(((.61, "green"), (.45, "yellow"), (.90, "orange"))):
                    x=i*104+8
                    preview.create_arc(x, 8, x+70, 78, start=180, extent=-180, style="arc", width=7, outline="#2f3a47")
                    preview.create_arc(x, 8, x+70, 78, start=180, extent=-180*ratio, style="arc", width=7, outline=COLORS[color])
                    preview.create_text(x+35, 65, text=f"{tr('Pilot ')}{i + 1:02} · {ratio:.0%}", fill="white", font=("Segoe UI", 8))
            else:
                for i, (ratio, fill) in enumerate(((.61, "#236445"), (.45, "#6b5717"), (.90, "#86411a"))):
                    x = i*106+3
                    preview.create_rectangle(x, 21, x+100, 60, fill=BG, outline=MUTED)
                    preview.create_rectangle(x+1, 22, x+100*ratio, 59, fill=fill, outline="")
                    preview.create_text(x+6, 33, text=f"{tr('Pilot ')}{i + 1:02}", anchor="w", fill="white")
                    preview.create_text(x+94, 49, text=f"{ratio:.0%}", anchor="e", fill="white")
        label(parent, tr('Style C shows cargo, yield and ETA in compact tiles. Hover for details.\nReset and right-click cargo controls are available in all styles.'), justify="left").pack(anchor="w", pady=16)
        button(parent, tr('Apply display style'), lambda: self.guarded(self.save_display)).pack(anchor="e")

    def save_display(self):
        style = self.display_style.get()
        if style not in ("bars", "gauges", "strip"):
            raise ValueError(tr('Choose a display style.'))
        self.engine.state["DisplayStyle"] = style
        self.app.build_rows()
        self.app.refresh()
        self.app.save()

    def error(self, exc):
        messagebox.showerror("EVE Mining", str(exc), parent=self.window)

    def guarded(self, function):
        try: function()
        except Exception as exc: self.error(exc)

    def make_fleet(self):
        parent = self.fleet
        profile = ttk.Frame(parent)
        profile.pack(fill="x")
        label(profile, tr('Saved profile')).pack(side="left", padx=(0, 12))
        self.saved = ttk.Combobox(profile, state="readonly", values=[p["Name"] for p in self.engine.state["Profiles"]], width=31)
        self.saved.set(self.engine.state["ActiveProfile"])
        self.saved.pack(side="left")
        button(profile, tr('Load into editor'), self.load_profile).pack(side="left", padx=10)
        button(profile, tr('Delete profile'), lambda: self.guarded(self.delete_profile)).pack(side="right")
        name = ttk.Frame(parent)
        name.pack(fill="x", pady=12)
        label(name, tr('Profile name')).pack(side="left", padx=(0, 15))
        self.profile_name = tk.StringVar(value=tr('My fleet'))
        ttk.Entry(name, textvariable=self.profile_name, width=34).pack(side="left")
        self.profile_mode = ttk.Combobox(name, values=("ICE", "ORE"), state="readonly", width=8)
        self.profile_mode.set(self.engine.state["Mode"])
        self.profile_mode.pack(side="left", padx=10)
        label(name, "V2.18.13 · Python", font=("Segoe UI", 8)).pack(side="right")
        label(parent, tr('Double-click to edit one pilot. Select multiple pilots with Shift or Ctrl/⌘, then click Edit selected.'),
              wraplength=800).pack(fill="x", pady=(0, 8))
        treeframe = ttk.Frame(parent)
        treeframe.pack(fill="both", expand=True)
        columns = ("Use", "Character", "Ship", "Capacity", "Lasers", "Cycle")
        self.pilot_tree = ttk.Treeview(treeframe, columns=columns, show="headings", selectmode="extended", height=10)
        for column, title, width in zip(self.pilot_tree["columns"], ("Use", tr('Character (exact log name)'), tr('Ship class'), tr('Capacity (m³)'), "Lasers", tr('Raw cycle (s)')), (45, 220, 150, 115, 60, 110)):
            self.pilot_tree.heading(column, text=tr(title))
            self.pilot_tree.column(column, width=width, minwidth=40)
        scroll = ttk.Scrollbar(treeframe, orient="vertical", command=self.pilot_tree.yview)
        self.pilot_tree.configure(yscrollcommand=scroll.set)
        self.pilot_tree.pack(side="left", fill="both", expand=True)
        scroll.pack(side="right", fill="y")
        self.pilot_tree.bind("<Double-1>", self.edit_clicked_pilot)
        self.pilot_tree.bind("<Delete>", lambda _: self.remove_pilot())
        actions = ttk.Frame(parent)
        actions.pack(fill="x", pady=10)
        self.tutorial_buttons["import"] = button(actions, tr('Add pilots from logs'), lambda: self.guarded(self.discover))
        self.tutorial_buttons["import"].pack(side="left")
        button(actions, tr('Add pilot'), lambda: self.edit_pilot(new=True)).pack(side="left", padx=6)
        self.tutorial_buttons["edit"] = button(actions, tr('Edit selected'), self.edit_pilot)
        self.tutorial_buttons["edit"].pack(side="left")
        button(actions, tr('Remove'), self.remove_pilot).pack(side="left", padx=6)
        self.tutorial_buttons["fleet"] = button(actions, tr('Save and activate profile'), lambda: self.guarded(self.save_profile))
        self.tutorial_buttons["fleet"].pack(side="right")
        folder = ttk.Frame(parent)
        folder.pack(fill="x", pady=4)
        self.folder = tk.StringVar(value=self.engine.state["Folder"])
        ttk.Entry(folder, textvariable=self.folder, state="readonly").pack(side="left", fill="x", expand=True)
        self.tutorial_buttons["folder"] = button(folder, tr('Log folder...'), lambda: self.guarded(self.choose_folder))
        self.tutorial_buttons["folder"].pack(side="right", padx=(10, 0))
        threshold = ttk.Frame(parent)
        threshold.pack(fill="x", pady=10)
        label(threshold, tr('Notify when cargo reaches')).pack(side="left")
        self.threshold = tk.StringVar(value=f"{self.engine.state['CargoThreshold']:g}")
        self.threshold_spin = ttk.Spinbox(threshold, from_=1, to=100, textvariable=self.threshold, width=5, command=self.save_threshold)
        self.threshold_spin.pack(side="left", padx=10)
        self.threshold_spin.bind("<FocusOut>", lambda _: self.save_threshold())
        self.threshold_spin.bind("<Return>", lambda _: self.save_threshold())
        label(threshold, tr('% · saved automatically, all profiles'), font=("Segoe UI", 8)).pack(side="left")
        self.auto_reset = tk.BooleanVar(value=self.engine.state["AutoCargoReset"])
        ttk.Checkbutton(parent, text=tr('Auto-reset cargo after mining → following in warp → hangar notification'),
                        variable=self.auto_reset, command=lambda: self.guarded(self.save_auto_reset)).pack(anchor="w", pady=(0, 4))
        label(parent, tr('Assumes the entire hold was unloaded. Mining more than 10s after the warp cancels it.'),
              font=("Segoe UI", 8)).pack(anchor="w", pady=(0, 6))
        self.free_label = tk.Label(parent, bg=BG, fg=ACCENT, anchor="w", font=("Segoe UI", 10, "bold"))
        self.free_label.pack(fill="x", pady=(0, 7))
        self.fleet_message = label(parent, tr('Change the profile name before saving to create another setup.'), wraplength=800)
        self.fleet_message.pack(fill="x")
        self.load_profile()
        self.update_free()

    def update_free(self):
        free = self.engine.free_fleet()
        self.free_label.configure(text=f"{tr('Miners free: ')}{format_number(free['Blocks'], ',')}{tr(' ice blocks / ')}{format_number(free['Volume'], ',.0f')}{tr(' m³ · boosters excluded')}" + (tr(' · VERIFY CARGO') if free["Unconfirmed"] else ""))

    def load_profile(self):
        profile = next((p for p in self.engine.state["Profiles"] if p["Name"] == self.saved.get()), None)
        self.pilot_tree.delete(*self.pilot_tree.get_children())
        if profile:
            self.profile_name.set(profile["Name"])
            self.profile_mode.set(profile["Mode"])
            for m in profile["Members"]:
                enabled = tr("Yes") if m.get("Enabled", True) else tr("No")
                self.pilot_tree.insert("", "end", values=(enabled, m["Character"], m["ShipClass"], str(m["Capacity"]), laser_count(m), m.get("CycleSeconds", 0)))

    def discover(self):
        existing = {self.pilot_tree.item(row, "values")[1] for row in self.pilot_tree.get_children()}
        for name in self.engine.find_pilots():
            if name not in existing:
                self.pilot_tree.insert("", "end", values=(tr("Yes"), name, "Custom", "10000", 0, 0))
        self.fleet_message.configure(text=tr("Select one or more pilots to set their ship, hold capacity, lasers and raw cycle."))
        if self.pilot_tree.get_children():
            self.app.tutorial.advance("import")
        elif self.app.tutorial.active("import"):
            self.fleet_message.configure(text=tr("No pilots found. Open EVE to generate a Gamelog, or select the correct folder."))

    def edit_clicked_pilot(self, event):
        row = self.pilot_tree.identify_row(event.y)
        if row:
            self.pilot_tree.selection_set(row)
            self.edit_pilot()

    def edit_pilot(self, new=False):
        selection = self.pilot_tree.selection()
        if not new and not selection: return
        if not new and len(selection) > 1:
            self.edit_ship_setup(selection)
            return
        values = (tr("Yes"), "", "Custom", "10000", "0", "0") if new else self.pilot_tree.item(selection[0], "values")
        dialog = tk.Toplevel(self.window)
        dialog.title(tr('Pilot configuration'))
        dialog.configure(bg=BG)
        dialog.transient(self.window)
        variables = [tk.StringVar(value=v) for v in values]
        titles = ("Use", tr('Character (exact log name)'), tr('Ship class'), tr('Actual hold capacity (m³)'),
                  tr('Lasers (0 disables hints)'), tr('Raw unboosted cycle (s; 0=auto)'))
        for i, title in enumerate(titles):
            label(dialog, tr(title)).grid(row=i, column=0, sticky="w", padx=12, pady=7)
            choices = (tr("Yes"), tr("No")) if i == 0 else tuple(dict.fromkeys(SHIPS + [values[2]])) if i == 2 else None
            widget = ttk.Combobox(dialog, textvariable=variables[i], values=choices, state="readonly", width=28) if choices else ttk.Entry(dialog, textvariable=variables[i], width=31)
            widget.grid(row=i, column=1, padx=12, pady=7)
        def apply():
            data = [v.get().strip() for v in variables]
            try:
                self.parse_member(data)
                if new: self.pilot_tree.insert("", "end", values=data)
                else: self.pilot_tree.item(selection[0], values=data)
                dialog.destroy()
                self.app.tutorial.pilot_edited()
            except Exception as exc: self.error(exc)
        style = "Tutorial.TButton" if self.app.tutorial.active("fleet") else "TButton"
        button(dialog, tr('Apply'), apply, style=style).grid(row=len(titles), column=1, sticky="e", padx=12, pady=12)
        dialog.grab_set()

    def edit_ship_setup(self, selection):
        rows = [self.pilot_tree.item(row, "values") for row in selection]
        columns = zip(*(row[2:6] for row in rows))
        common = [column[0] if len(set(column)) == 1 else "" for column in columns]
        dialog = tk.Toplevel(self.window)
        dialog.title(tr('Edit ship setup for {count} pilots').format(count=len(selection)))
        dialog.configure(bg=BG)
        dialog.transient(self.window)
        label(dialog, tr('Blank fields keep each pilot’s existing value.')).grid(
            row=0, column=0, columnspan=2, sticky="w", padx=12, pady=10)
        variables = [tk.StringVar(value=value) for value in common]
        titles = ('Ship class', 'Actual hold capacity (m³)', 'Lasers (0 disables hints)', 'Raw unboosted cycle (s; 0=auto)')
        for i, title in enumerate(titles, 1):
            label(dialog, tr(title)).grid(row=i, column=0, sticky="w", padx=12, pady=7)
            if i == 1:
                choices = tuple(dict.fromkeys(["", *SHIPS, common[0]]))
                widget = ttk.Combobox(dialog, textvariable=variables[i-1], values=choices, state="readonly", width=28)
            else:
                widget = ttk.Entry(dialog, textvariable=variables[i-1], width=31)
            widget.grid(row=i, column=1, padx=12, pady=7)

        def apply():
            changes = [variable.get().strip() for variable in variables]
            updated = [row[:2] + tuple(value or old for value, old in zip(changes, row[2:6]))
                       for row in rows]
            try:
                for values in updated:
                    self.parse_member(values)
            except Exception as exc:
                messagebox.showerror(tr('EVE Mining'), str(exc), parent=dialog)
                return
            for row, values in zip(selection, updated):
                self.pilot_tree.item(row, values=values)
            self.fleet_message.configure(text=tr('Ship setup applied to {count} pilots. Save and activate to keep changes.').format(count=len(selection)))
            dialog.destroy()
            self.app.tutorial.pilot_edited()

        style = "Tutorial.TButton" if self.app.tutorial.active("fleet") else "TButton"
        button(dialog, tr('Apply'), apply, style=style).grid(row=len(titles)+1, column=1, sticky="e", padx=12, pady=12)
        dialog.bind("<Return>", lambda _: apply())
        dialog.bind("<Escape>", lambda _: dialog.destroy())
        dialog.grab_set()

    @staticmethod
    def parse_member(values):
        enabled, name, ship, capacity, lasers, cycle = values
        capacity, cycle_number = parse_number(capacity), float(parse_number(cycle or "0"))
        count = int(lasers)
        if not name.strip() or not 1000 <= capacity <= 1000000000 or not 0 <= count <= 8 or not 0 <= cycle_number <= 600:
            raise ValueError(tr('Enter a character name, capacity ≥1,000 m³, 0–8 lasers and raw cycle 0–600 seconds.'))
        return dict(Enabled=enabled in ("Yes", tr("Yes")), Character=name.strip(), ShipClass=ship or "Custom",
                    Capacity=capacity, Lasers=count, CycleSeconds=cycle_number)

    def remove_pilot(self):
        for row in self.pilot_tree.selection(): self.pilot_tree.delete(row)

    def save_profile(self):
        name = self.profile_name.get().strip()
        members = [self.parse_member(self.pilot_tree.item(row, "values")) for row in self.pilot_tree.get_children()]
        if not name or not any(m["Enabled"] for m in members) or len({m["Character"].casefold() for m in members}) != len(members):
            raise ValueError(tr('Name the profile, enable at least one pilot and use unique character names.'))
        self.app.poll()
        previous = [m["Character"] for m in self.engine.members]
        self.engine.state["Profiles"] = [p for p in self.engine.state["Profiles"] if p["Name"] != name] + [dict(Name=name, Mode=self.profile_mode.get(), Members=members)]
        self.engine.activate(name, previous)
        self.app.save()
        self.app.sync_profiles()
        self.app.build_rows()
        self.app.refresh()
        self.saved["values"] = [p["Name"] for p in self.engine.state["Profiles"]]
        self.saved.set(name)
        self.fleet_message.configure(text=tr('Profile saved. Confirm cargo after changing ships.'))
        self.app.tutorial.advance("fleet")

    def delete_profile(self):
        name = self.saved.get()
        if not name: return
        self.engine.state["Profiles"] = [p for p in self.engine.state["Profiles"] if p["Name"] != name]
        if self.engine.state["ActiveProfile"] == name:
            self.engine.state["ActiveProfile"] = ""
            if self.engine.state["Profiles"]: self.engine.activate(self.engine.state["Profiles"][0]["Name"])
        self.app.save()
        self.app.sync_profiles()
        self.app.build_rows()
        self.saved["values"] = [p["Name"] for p in self.engine.state["Profiles"]]
        self.saved.set(self.engine.state["ActiveProfile"])
        self.load_profile()

    def choose_folder(self):
        folder = filedialog.askdirectory(parent=self.window, initialdir=self.engine.state["Folder"] or str(self.engine.root), mustexist=True, title=tr('Select local EVE Gamelogs folder'))
        if not folder: return
        path = local_path(folder)
        reject_link(path)
        self.engine.state["Folder"] = str(path)
        self.engine.state["Files"].clear()
        for m in self.engine.members: self.engine.ship(m)["Known"] = False
        self.folder.set(str(path))
        self.app.save()
        self.app.tutorial.advance('folder')

    def save_auto_reset(self):
        self.engine.set_auto_cargo_reset(self.auto_reset.get())
        self.app.save()
        self.fleet_message.configure(text=tr('Automatic cargo reset enabled.') if self.auto_reset.get() else tr('Automatic cargo reset disabled.'))

    def save_threshold(self):
        try:
            value = parse_number(self.threshold.get())
            if not 1 <= value <= 100: raise ValueError(tr('Cargo threshold must be 1–100%.'))
            self.engine.state["CargoThreshold"] = value
            self.app.save()
            self.fleet_message.configure(text=f"{tr('Cargo threshold saved: ')}{value:g}%.")
        except Exception as exc:
            self.fleet_message.configure(text=str(exc))

    def make_prices(self):
        parent = self.prices
        label(parent, f"{tr('ISK/h uses the BUY prices of reprocessed products at ')}{format_number(MAX_REPROCESS_YIELD, '.2f')}{tr('% yield.')}").pack(fill="x")
        self.price_age_label = label(parent, font=("Segoe UI", 9))
        self.price_age_label.pack(fill="x")
        show_price_age(self.price_age_label, self.engine.state["LastPriceUpdate"])
        controls = ttk.Frame(parent)
        controls.pack(fill="x", pady=10)
        label(controls, tr('Filter')).pack(side="left", padx=(0, 8))
        self.price_filter = tk.StringVar()
        ttk.Entry(controls, textvariable=self.price_filter, width=35).pack(side="left")
        button(controls, tr('Export price item list'), lambda: self.guarded(self.export_items)).pack(side="right")
        self.price_tree = ttk.Treeview(parent, columns=("Material", "Buy", "Source"), show="headings", height=15)
        for col, width in (("Material", 420), ("Buy", 160), ("Source", 160)):
            self.price_tree.heading(col, text=tr('BUY ISK / unit') if col == "Buy" else tr(col))
            self.price_tree.column(col, width=width)
        scrollbar = ttk.Scrollbar(parent, orient="vertical", command=self.price_tree.yview)
        self.price_tree.configure(yscrollcommand=scrollbar.set)
        self.price_tree.pack(fill="both", expand=True)
        scrollbar.place(relx=1, rely=.15, relheight=.63, anchor="ne")
        self.price_tree.bind("<Double-1>", lambda _: self.edit_price())
        self.price_filter.trace_add("write", lambda *_: self.fill_prices())
        self.fill_prices()
        actions = ttk.Frame(parent)
        actions.pack(fill="x", pady=12)
        button(actions, tr('Paste price set...'), self.import_prices).pack(side="left")
        button(actions, tr('Edit selected BUY price'), self.edit_price).pack(side="left", padx=10)
        label(parent, tr('Double-click a material to edit its BUY override.\nPaste Item / Amount / Volume / Buy / Sell from your appraisal. Only BUY is imported.\nExport writes Reprocessing-products.txt in the application folder.'), justify="left", wraplength=800).pack(fill="x")

    def fill_prices(self):
        self.price_tree.delete(*self.price_tree.get_children())
        query = self.price_filter.get().casefold()
        materials = self.engine.items.keys() | self.engine.state["Prices"].keys() | self.engine.reprocessing_products
        for material in sorted(materials):
            display_name = self.app.material_label(material)
            if query not in material.casefold() and query not in display_name.casefold(): continue
            price, stored = self.engine.unit_price(material), self.engine.state["Prices"].get(material)
            self.price_tree.insert("", "end", iid=material, values=(display_name, f"{format_number(price, ',.2f')}" if price is not None else "", tr(stored["Source"]) if stored else ""))

    def export_items(self):
        path = self.engine.root / "Reprocessing-products.txt"
        reject_link(path)
        path.write_text(self.engine.price_list(), encoding="utf-8")
        messagebox.showinfo(tr('Exported'), f"{tr('Saved ')}{path.name}{tr(' in the application folder.')}", parent=self.window)

    def edit_price(self):
        selected = self.price_tree.selection()
        if not selected: return
        material = selected[0]
        old = self.engine.state["Prices"].get(material)
        value = simpledialog.askstring(tr('BUY override - ') + material, tr('ISK per unit (blank removes the override):'), initialvalue=str(old["Value"]) if old else "", parent=self.window)
        if value is None: return
        def apply():
            if not value.strip(): self.engine.state["Prices"].pop(material, None)
            else:
                number = parse_number(value)
                if number < 0: raise ValueError(tr('BUY price must be zero or positive.'))
                self.engine.state["Prices"][material] = dict(Value=number, Source="Custom buy")
            self.app.save()
            self.fill_prices()
            self.engine.rate_refresh = True
            self.app.refresh()
            self.app.refresh_reprocessing_prices()
        self.guarded(apply)

    def import_prices(self):
        dialog = tk.Toplevel(self.window)
        dialog.title(tr('Paste price set'))
        dialog.configure(bg=BG)
        dialog.transient(self.window)
        label(dialog, tr('Item / Amount / Volume / Buy / Sell. Only Buy is imported.')).pack(padx=12, pady=10)
        text = tk.Text(dialog, width=85, height=18, undo=True)
        text.pack(fill="both", expand=True, padx=12)
        def apply():
            try:
                prices = janice(text.get("1.0", "end"), self.engine.canonical_material)
                if not prices: raise ValueError(tr('No valid price rows found.'))
                self.engine.state["Prices"].update(prices)
                self.engine.state["LastPriceUpdate"] = datetime.now(timezone.utc).isoformat()
                self.app.save()
                self.fill_prices()
                self.engine.rate_refresh = True
                self.app.refresh()
                self.app.refresh_reprocessing_prices()
                dialog.destroy()
            except Exception as exc: self.error(exc)
        button(dialog, tr('Import BUY prices'), apply).pack(anchor="e", padx=12, pady=12)
        dialog.grab_set()

    def make_alerts(self):
        parent = self.alerts
        groups = ttk.Frame(parent)
        groups.pack(fill="x")
        standard = ttk.Frame(groups)
        standard.pack(side="left", anchor="n", padx=(0, 12))
        tracker = ttk.Frame(groups)
        tracker.pack(side="left", anchor="n")
        self.cargo_enabled, self.cargo_tone, self.cargo_volume = self.alert_controls(
            standard, "Cargo", tr('Enable cargo sound'), tr('Cargo volume'), tr('Test cargo sound'))
        self.attack_enabled, self.attack_tone, self.attack_volume = self.alert_controls(
            standard, "Attack", tr('Enable attack sound'), tr('Attack volume'), tr('Test attack sound'))
        self.attention_enabled, self.attention_tone, self.attention_volume = self.alert_controls(
            standard, "Attention", tr('Enable ship attention sound'), tr('Attention volume'), tr('Test attention sound'))
        self.rock_enabled, self.rock_tone, self.rock_volume = self.alert_controls(
            tracker, "Rock", tr('Enable rock warning sound'), tr('Rock volume'), tr('Test rock sound'))
        self.depleted_enabled, self.depleted_tone, self.depleted_volume = self.alert_controls(
            tracker, "Depleted", tr('Enable rock depleted sound'), tr('Depleted volume'), tr('Test depleted sound'))
        threshold = ttk.Frame(tracker)
        threshold.pack(anchor="w", pady=(8, 0))
        label(threshold, tr('Warn at % remaining (next rock)')).pack(side="left")
        self.rock_percent = ttk.Spinbox(threshold, from_=0, to=99, width=5)
        self.rock_percent.set(str(self.engine.state["RockWarningPercent"]))
        self.rock_percent.pack(side="left", padx=8)
        label(parent, tr('Volume: 0–100% for each alert; 0% is silent. Default: 20%.\nSliders also adjust a running preview. Use Save alert settings to keep the levels.\nAdd MP3/WAV files to Sounds, then Refresh sounds. Cargo threshold is on Fleet profiles.\nUnconfirmed cargo does not trigger sounds. Attacks take priority.\nMissing or invalid audio produces an error; no Windows system-tone fallback.'), justify="left", wraplength=800).pack(fill="x", pady=10)
        actions = ttk.Frame(parent)
        actions.pack(fill="x", pady=18)
        button(actions, tr('Save alert settings'), lambda: self.guarded(self.save_alerts)).pack(side="left")
        button(actions, tr('Refresh sounds'), lambda: self.guarded(self.refresh_sounds)).pack(side="left", padx=12)
        button(actions, tr('Stop preview'), self.app.audio.stop).pack(side="left")
        self.alert_message = label(parent, wraplength=800)
        self.alert_message.pack(fill="x")
        self.refresh_sounds()

    def alert_controls(self, parent, key, enabled_label, volume_label, test_label):
        enabled = tk.BooleanVar(value=self.engine.state[key + "Sound"])
        ttk.Checkbutton(parent, text=enabled_label, variable=enabled).pack(anchor="w", pady=(8, 4))
        row = ttk.Frame(parent)
        row.pack(anchor="w")
        tone = ttk.Combobox(row, state="readonly", width=28)
        tone.set(self.engine.state[key + "Tone"])
        tone.pack(side="left")
        volume = tk.IntVar(value=round(self.engine.state[key + "Volume"]))
        kind = key.lower()
        button(row, test_label, lambda: self.test_sound(tone.get(), volume.get(), kind)).pack(side="left", padx=8)
        self.volume_control(parent, volume_label, volume, kind)
        return enabled, tone, volume

    def refresh_sounds(self):
        choices = self.app.audio.choices()
        for combo in (self.cargo_tone, self.attack_tone, self.rock_tone, self.depleted_tone, self.attention_tone):
            selected = combo.get()
            combo["values"] = choices + ([selected] if selected and selected not in choices else [])
        self.alert_message.configure(text=f"{len(choices)}{tr(' local MP3 / WAV files available.')}")

    def volume_control(self, parent, title, variable, kind):
        row = ttk.Frame(parent)
        row.pack(anchor="w", pady=(8, 0))
        label(row, title, width=14).pack(side="left")
        tk.Scale(row, from_=0, to=100, resolution=1, orient="horizontal", variable=variable,
                 command=lambda _: self.volume_changed(kind, variable.get()), length=160,
                 showvalue=False, bg=BG, fg="white", troughcolor=PANEL,
                 highlightthickness=0, bd=0).pack(side="left")
        percentage = label(row, width=5)
        percentage.pack(side="left", padx=10)
        variable.trace_add("write", lambda *_: percentage.configure(text=f"{variable.get()}%"))
        percentage.configure(text=f"{variable.get()}%")

    def volume_changed(self, kind, value):
        if self.app.audio.kind == kind and self.app.audio.busy:
            self.app.audio.set_volume(value)

    def test_sound(self, name, volume, kind):
        try:
            self.app.audio.play(name, volume, kind)
            self.alert_message.configure(text=f"{tr('Preview: ')}{name}{tr(' at ')}{volume}%")
        except Exception as exc:
            self.alert_message.configure(text=str(exc))

    def save_alerts(self):
        cargo, attack = self.cargo_tone.get(), self.attack_tone.get()
        rock = self.rock_tone.get()
        if self.cargo_enabled.get() and not self.app.audio.resolve(cargo): raise ValueError(tr('Select an available cargo sound.'))
        if self.attack_enabled.get() and not self.app.audio.resolve(attack): raise ValueError(tr('Select an available attack sound.'))
        if self.rock_enabled.get() and not self.app.audio.resolve(rock): raise ValueError(tr('Select an available rock warning sound.'))
        depleted, attention = self.depleted_tone.get(), self.attention_tone.get()
        if self.depleted_enabled.get() and not self.app.audio.resolve(depleted):
            raise ValueError(tr('Select an available rock depleted sound.'))
        if self.attention_enabled.get() and not self.app.audio.resolve(attention):
            raise ValueError(tr('Select an available ship attention sound.'))
        percent = self.rock_percent.get().strip()
        if not percent.isdecimal() or len(percent) > 2:
            raise ValueError(tr('Enter a warning percentage from 0 to 99.'))
        self.engine.state.update(CargoSound=self.cargo_enabled.get(), AttackSound=self.attack_enabled.get(), CargoTone=cargo, AttackTone=attack,
                                 CargoVolume=self.cargo_volume.get(), AttackVolume=self.attack_volume.get(),
                                 RockSound=self.rock_enabled.get(), RockTone=rock, RockVolume=self.rock_volume.get(),
                                 DepletedSound=self.depleted_enabled.get(), DepletedTone=depleted, DepletedVolume=self.depleted_volume.get(),
                                 AttentionSound=self.attention_enabled.get(), AttentionTone=attention, AttentionVolume=self.attention_volume.get(),
                                 RockWarningPercent=int(percent))
        self.app.attack_var.set(self.attack_enabled.get())
        self.app.save()
        self.alert_message.configure(text=tr('Alert settings saved.'))

    def close(self):
        self.save_threshold()
        self.app.audio.stop()
        self.window.destroy()
        self.app.settings = None
        self.app.tutorial.show()


def lock_instance(lock):
    if os.name == "nt":
        import msvcrt
        if os.fstat(lock.fileno()).st_size == 0:
            lock.write(b"0")
            lock.flush()
        lock.seek(0)
        msvcrt.locking(lock.fileno(), msvcrt.LK_NBLCK, 1)
    else:
        import fcntl
        fcntl.flock(lock.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)


def main():
    root_path = local_path(app_root())
    lock_path = root_path / ".python-instance.lock"
    root = tk.Tk()
    root.withdraw()
    lock = None
    try:
        reject_link(lock_path)
        lock = lock_path.open("a+b")
        try: lock_instance(lock)
        except OSError: raise ValueError(tr('Close the other Python EVE Mining instance in this folder.'))
        app = App(root)
        root.deiconify()
        root.mainloop()
    except Exception as exc:
        messagebox.showerror(tr('EVE Mining V2.18.13 - error'), str(exc) + tr('\nUse a writable local folder. Administrator rights are not required.'), parent=root)
        root.destroy()
    finally:
        if lock is not None:
            lock.close()
        # The small lock file stays local to avoid a race with another instance.


if __name__ == "__main__":
    main()
