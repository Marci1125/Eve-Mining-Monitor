"""Optional release notifications using the public GitHub API."""
import json
from http.client import HTTPException
import re
from urllib.error import HTTPError, URLError
from urllib.parse import quote
from urllib.request import Request, urlopen


REPOSITORY_URL = "https://github.com/Marci1125/Eve-Mining-Monitor"
RELEASE_API_URL = "https://api.github.com/repos/Marci1125/Eve-Mining-Monitor/releases/latest"
MAX_RESPONSE_BYTES = 1024 * 1024


class UpdateCheckError(Exception):
    pass


def version_number(value):
    if not isinstance(value, str):
        raise ValueError("Invalid version")
    match = re.fullmatch(r"[vV]?(\d+)\.(\d+)(?:\.(\d+))?(?:-python)?", value.strip())
    if match is None:
        raise ValueError("Invalid version")
    return tuple(int(part or 0) for part in match.groups())


def release_information(payload, installed_version):
    if not isinstance(payload, dict) or payload.get("draft") is not False or payload.get("prerelease") is not False:
        raise UpdateCheckError("GitHub returned invalid release information.")
    tag = payload.get("tag_name")
    try:
        remote = version_number(tag)
        installed = version_number(installed_version)
    except ValueError:
        raise UpdateCheckError("GitHub returned an unsupported release version.") from None
    # Version tags are validated above. The destination is always this repository.
    return dict(Tag=tag.strip(), Number=remote, IsNewer=remote > installed, IsOlder=remote < installed,
                Url=f"{REPOSITORY_URL}/releases/tag/{quote(tag.strip(), safe='')}")


def fetch_latest_release(installed_version):
    installed = ".".join(map(str, version_number(installed_version)))
    request = Request(RELEASE_API_URL, headers={
        "Accept": "application/vnd.github+json",
        "User-Agent": f"EVE-Mining-Monitor/{installed}",
        "X-GitHub-Api-Version": "2022-11-28",
    })
    try:
        with urlopen(request, timeout=8) as response:
            content = response.read(MAX_RESPONSE_BYTES + 1)
    except HTTPError as error:
        if error.code in (403, 429):
            message = "GitHub is temporarily limiting update checks. Please try again later."
        elif error.code == 404:
            message = "No published release is available on GitHub."
        else:
            message = "GitHub update check failed. Please try again later."
        raise UpdateCheckError(message) from None
    except (URLError, OSError, HTTPException):
        raise UpdateCheckError("Could not reach GitHub. Check your internet connection and try again.") from None
    if len(content) > MAX_RESPONSE_BYTES:
        raise UpdateCheckError("GitHub returned invalid release information.")
    try:
        payload = json.loads(content.decode("utf-8-sig"))
    except (ValueError, UnicodeError):
        raise UpdateCheckError("GitHub returned invalid release information.") from None
    return release_information(payload, installed_version)
