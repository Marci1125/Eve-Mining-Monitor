import tkinter as tk
from tkinter import ttk

from i18n import tr


SETTINGS_STEPS = {"folder", "import", "fleet", "prices", "alerts", "display", "languages"}
STEPS = (
    ("options", "Click Options to set up your fleet."),
    ("folder", r"Click Log folder and choose Gamelogs. The usual Windows location is C:\Users\<your name>\Documents\EVE\logs\Gamelogs."),
    ("import", "Click Add pilots from logs to import the characters found in Gamelogs."),
    ("fleet", "1. Select your pilots. Use Shift for a range or Ctrl (Command on Mac) for individual rows.\n2. Click Edit selected, enter the ship, hold capacity, lasers and raw cycle, then click Apply. For one pilot, you can also double-click their row.\n3. Click Save and activate profile to continue."),
    ("session", "New session archives the current mining totals in Ledger and starts a fresh session."),
    ("reset", "Reset all clears the cargo counters. Use it after all ships have unloaded."),
    ("reprocess", "Click Reprocess to open a sample estimate of the products and prices for a mining session."),
    ("ledger", "Ledger combines the mining history of all tracked accounts in one view. Filter it by date or material."),
    ("rock", "Track Rock estimates what is left on one target. Enter the remaining units from a scan, then mine that target with your tracked fleet."),
    ("belt", "Belt Estimate uses a pasted ice or ore survey and your Gamelogs to estimate mining time and unloading stops."),
    ("options", "Open Options again for a quick look at the other settings."),
    ("prices", "Prices / Janice lets you export the price list and import BUY quotes for your estimates."),
    ("alerts", "Alerts lets you choose, test and adjust the volume of each warning sound."),
    ("display", "Display Style switches between Bars, Gauges and Fleet Strip."),
    ("languages", "Languages changes the interface after restart. The monitor currently supports English and German Gamelogs. More commonly used languages can be added based on player feedback."),
)


class SetupTutorial:
    def __init__(self, app):
        self.app = app
        self.step = None
        self.panel = self.highlight = self.example = self.tab_highlight = None

    def start(self):
        if self.step is not None:
            self.show()
            return
        self.review = bool(self.app.engine.current)
        self.fleet_edited = False
        self.step = self.furthest = 0
        if self.app.settings:
            self.app.settings.window.withdraw()
        self.show()

    def active(self, key):
        return self.step is not None and STEPS[self.step][0] == key

    def advance(self, key):
        if not self.active(key):
            return
        if self.step == len(STEPS) - 1:
            self.finish()
        else:
            self.step += 1
            self.furthest = max(self.furthest, self.step)
            if key == "fleet":
                self.app.settings.close()
            else:
                self.show()

    def back(self):
        if self.step is None or self.step == 0:
            return
        self.dismiss_example()
        self.step -= 1
        if STEPS[self.step][0] in SETTINGS_STEPS and not self.app.settings:
            self.app.open_settings()
        else:
            self.show()

    def clear(self):
        if self.highlight:
            widget, style, command = self.highlight
            if widget.winfo_exists():
                widget.configure(style=style, command=command)
            self.highlight = None
        if self.tab_highlight is not None and self.tab_highlight.winfo_exists():
            self.tab_highlight.configure(style="")
        self.tab_highlight = None
        if self.panel and self.panel.winfo_exists():
            self.panel.destroy()
        self.panel = None

    def finish(self):
        self.step = None
        self.clear()
        self.dismiss_example()
        self.app.engine.state["TutorialDone"] = True
        self.app.run(lambda: None)

    def show(self):
        self.clear()
        if self.step is None:
            return
        key, text = STEPS[self.step]
        settings = self.app.settings
        settings_step = key in SETTINGS_STEPS
        if settings:
            if settings_step:
                settings.window.deiconify()
            else:
                settings.window.withdraw()
        parent = self.app.body
        target = self.app.tutorial_buttons.get(key)
        next_action = None
        if settings_step and settings is None:
            text = "Open Options to continue the tutorial."
            target = self.app.options_button
        elif settings_step:
            parent = settings.window
            tab = getattr(settings, key if key in ("prices", "alerts", "display", "languages") else "fleet")
            settings.tabs.select(tab)
            target = settings.tutorial_buttons.get(key)
            if tab is not settings.fleet:
                settings.tabs.configure(style="Tutorial.TNotebook")
                self.tab_highlight = settings.tabs
            if key == "fleet" and not self.fleet_edited:
                target = settings.tutorial_buttons["edit"]
            if tab is not settings.fleet or self.review or self.step < self.furthest:
                next_action = lambda: self.advance(key)
        elif key in ("session", "reset", "ledger", "rock", "belt"):
            next_action = lambda: self.advance(key)

        if target is not None:
            style = target.cget("style")
            command = target.cget("command")
            self.highlight = target, style, command
            target.configure(style="Tutorial." + (style or "TButton"))
            if key in ("session", "reset"):
                target.configure(command=next_action)
            elif key == "reprocess":
                target.configure(command=self.open_example)

        self.panel = panel = tk.Frame(parent, bg="#223342", padx=10, pady=7,
                                     highlightbackground="#f4cf75", highlightthickness=2)
        in_settings = settings_step and settings is not None
        anchor = settings.tabs if in_settings else parent.pack_slaves()[0]
        panel.pack(fill="x", padx=8, pady=(4, 8), before=anchor)
        tk.Label(panel, bg=panel["bg"], fg="#f4cf75", anchor="w", font=("Segoe UI", 11, "bold"),
                 text=tr('Tutorial {step}/{total}').format(step=self.step + 1, total=len(STEPS))).pack(fill="x")
        tk.Label(panel, bg=panel["bg"], fg="white", anchor="w", justify="left",
                 wraplength=770 if in_settings else min(500, self.app.layout_width - 54),
                 text=tr(text)).pack(fill="x", pady=(2, 4))
        actions = tk.Frame(panel, bg=panel["bg"])
        actions.pack(fill="x")
        ttk.Button(actions, text=tr('Skip tutorial'), command=self.finish).pack(side="left")
        if next_action:
            ttk.Button(actions, text=tr('Finish tutorial' if self.step == len(STEPS) - 1 else 'Next'),
                       command=next_action, style="Tutorial.TButton").pack(side="right")
        if self.step > 0:
            ttk.Button(actions, text=tr('Back'), command=self.back).pack(side="right", padx=(0, 6))
        self.app.refresh()

    def options_opened(self):
        if self.active("options"):
            self.advance("options")
        elif self.step is not None and self.step not in range(4, 10):
            self.show()

    def pilot_edited(self):
        if self.active("fleet"):
            self.fleet_edited = True
            self.show()

    def open_example(self):
        if self.example and self.example.winfo_exists():
            self.example.lift()
            return
        self.example = example = self.app.open_reprocessing(example=True)
        example.protocol("WM_DELETE_WINDOW", self.close_example)
        actions = tk.Frame(example, bg="#223342", padx=10, pady=6,
                           highlightbackground="#f4cf75", highlightthickness=2)
        actions.pack(side="bottom", fill="x", padx=12, pady=(0, 8), before=example.winfo_children()[0])
        tk.Label(actions, bg=actions["bg"], fg="white", anchor="w", justify="left", wraplength=400,
                 text=tr('Review the sample, then click Continue tutorial.')).pack(side="left")
        continue_button = ttk.Button(actions, text=tr('Continue tutorial'), command=self.close_example,
                                     style="Tutorial.TButton")
        continue_button.pack(side="right")
        ttk.Button(actions, text=tr('Back'), command=self.back).pack(side="right", padx=6)
        continue_button.focus_set()

    def dismiss_example(self):
        if self.example and self.example.winfo_exists():
            self.example.destroy()
        self.example = None

    def close_example(self):
        self.dismiss_example()
        self.advance("reprocess")
