# EVE Mining V2.18.7 for macOS

The first-run tutorial guides you through fleet setup and the main controls. It covers editing several pilots together and opens a sample Reprocess estimate. Use **Options > Languages > Restart Tutorial** to replay it.

The Ledger shows **% extra** beside **Bonus units**. This is the recorded critical bonus divided by the regular quantity mined for that date and material.

Open Belt Estimate next to Ledger. Paste an ICE or ORE survey scan and enter the fleet downtime per unload. ICE uses complete cargo fills. ORE uses continuous mining samples measured in cubic metres. The result includes expected critical bonuses in cargo.

Track Rock plays a distinct sound once at zero remaining units. The ship attention sound plays after four estimated mining cycles of continuous irregular activity. Configure both sounds in Alerts. The Ledger shows recorded critical hits and bonus units for yields read from this version onward.

In **Fleet profiles**, select multiple pilots with Shift or Command and click
**Edit selected** to change their ship class, capacity, lasers or raw cycle
together. A blank field keeps each pilot's existing value. Save and activate
the profile when finished. Double-click to edit an individual pilot.

The drone filter is always active. Yields of 50 m³ or less do not count as
laser cycle samples. They still count toward cargo, income and reprocessing.

Moon ore reprocessing products are included in the price export. Import BUY
quotes to value them in Reprocess.

Reprocess shows bundled EVE icons for mined materials and the current price import date. Fallback sample prices retain their separate snapshot date.

ISK/h, session value and the trend use the BUY value of products recovered
in complete batches at 90.63% yield, before fees. Imported BUY quotes take
priority over the bundled product samples. Missing quotes or recipes make
the estimate partial. Export Reprocessing-products.txt from Options >
Prices / Janice to appraise the 43 reprocessing products at quantity 1.

The boost estimate tolerates an isolated irregular interval. Short gaps
retain the last reliable estimate for up to 120 seconds from its latest
sample.

Style B shows tracked compressed cargo as a dashed grey segment. Hover
over the gauge to see the exact tracked compressed volume.

This edition includes all three display styles, cargo and income tracking, reprocessing, alerts and the optional cargo reset. English and German Gamelogs are detected automatically. Choose the interface language under Options > Languages and restart. English is the default.

## Mining Ledger and Track Rock

**Ledger** shows current and archived mining across your fleet. **New session**
saves the previous session to the local **Session Logs** folder.

**Track Rock** estimates the remaining units on a single ice or ore target.
Enter the current quantity from your scan. The first regular yield in the
selected ICE or ORE mode identifies the material. Set the warning sound,
volume and threshold in **Options > Alerts**.

This package starts with blank profiles and no selected Gamelogs folder.
To update, close the old app and copy your Python state file, Session Logs
and custom sounds into the new folder.

## Start

1. Install **Python 3.12** with Tk using the [official macOS installer](https://www.python.org/downloads/macos/). Use the **universal2 installer** for Apple Silicon or Intel.
2. Extract the ZIP into a writable local folder and open **Start EVE Mining.command**. The first run creates a local Python environment and downloads the pinned audio dependency from PyPI. Subsequent launches use the local environment.
3. In the app, open **Options > Fleet profiles**, choose the EVE **Gamelogs** folder containing character session logs, and click **Add pilots from logs**. Choose your ships and cargo capacities, then save and activate the fleet.
4. Under **Options > Alerts**, test each sound. In the fleet view, use secondary click or Control-click to set or confirm cargo.

If Finder does not open the launcher, open Terminal, type `/bin/bash ` (including the space), drag **Start EVE Mining.command** into the Terminal window and press Return.

## Files and tester feedback

Keep `Source`, `Sounds` and `Licenses` together. The app saves preferences and session data in `EVE-Mining.python-state.json` beside the launcher. Use the original ZIP for sharing. The folder created by first launch contains local state and the Python environment.

This ZIP runs from Python. Please include your macOS version, whether your Mac uses Apple Silicon or Intel, and any error message when reporting an issue.
