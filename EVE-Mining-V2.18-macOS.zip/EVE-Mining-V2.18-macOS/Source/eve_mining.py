"""EVE Mining V2.18: Python/Tkinter GUI, no browser/network/game automation."""
from __future__ import annotations

import copy
from collections import Counter
from decimal import Decimal as D
from datetime import date, datetime, timezone
import math
import os
from pathlib import Path
import sys
import time
import tkinter as tk
from tkinter import font as tkfont
from tkinter import ttk, filedialog, messagebox, simpledialog

from mining_engine import (Engine, app_root, bundle_root, local_path, reject_link, janice,
                           parse_number, laser_count, price_age, SHIPS, BOOSTERS, MIN_TIME, MAX_REPROCESS_YIELD)
from local_audio import LocalAudio
from i18n import format_number, language, set_language, tr

BG, PANEL, MUTED, ACCENT = "#10161d", "#1e2732", "#8fa0b5", "#64e8b2"
COLORS = dict(red="#eb4b4b", orange="#ff9f43", yellow="#ffd237", green="#3abe78")


def isk(value):
    return f"{format_number(float(value) / (1000000000.0 if abs(value) >= 1000000000.0 else 1000000.0), ',.2f')} {('B' if abs(value) >= 1000000000.0 else 'M')}"


def label(parent, text="", **kwargs):
    return tk.Label(parent, text=text, bg=BG, fg="#f5f5f5", anchor="w", **kwargs)


def button(parent, text, command, **kwargs):
    return ttk.Button(parent, text=text, command=command, **kwargs)


def bind_cargo_menu(widget, menu):
    def popup(event):
        menu.tk_popup(event.x_root, event.y_root)
        return "break"

    widget.bind("<Button-3>", popup)
    if widget.tk.call("tk", "windowingsystem") == "aqua":
        widget.bind("<Button-2>", popup)
        widget.bind("<Control-Button-1>", popup)


def show_price_age(widget, as_of):
    date, outdated = price_age(as_of)
    suffix = tr(' · Outdated') if outdated else ""
    widget.configure(text=f"{tr('Last Price update: ')}{date}{suffix}", fg=COLORS["red"] if outdated else MUTED)


class Tooltip:
    def __init__(self, widget, text):
        self.widget, self.text, self.window = widget, text, None
        widget.bind("<Enter>", self.show)
        widget.bind("<Leave>", self.hide)
        widget.bind("<ButtonPress>", self.hide, add="+")

    def show(self, _=None):
        if not self.text or self.window:
            return
        self.window = tk.Toplevel(self.widget)
        self.window.overrideredirect(True)
        self.window.attributes("-topmost", True)
        self.window.geometry(f"+{self.widget.winfo_rootx()+10}+{self.widget.winfo_rooty()+25}")
        tk.Label(self.window, text=self.text, bg=PANEL, fg="white", justify="left", wraplength=440, padx=8, pady=6).pack()

    def hide(self, _=None):
        if self.window:
            self.window.destroy()
            self.window = None


class App:
    def __init__(self, root, engine=None, live=True):
        self.root, self.engine, self.live = root, engine or Engine(), live
        set_language(self.engine.state["Language"])
        self.audio = LocalAudio(self.engine.root)
        self.settings = None
        self.rows = []
        self.cargo_queued = False
        self.headline_at = self.saved_at = 0
        self.timer = None
        root.title("EVE Mining V2.18 - Python")
        root.configure(bg=BG)
        root.option_add("*Font", "{Segoe UI} 9")
        root.resizable(False, False)
        self.style = ttk.Style(root)
        self.style.theme_use("clam")
        self.style.configure("TFrame", background=BG)
        self.style.configure("TLabel", background=BG, foreground="white")
        self.style.configure("TButton", background=PANEL, foreground="white", padding=(8, 3), borderwidth=1)
        self.style.map("TButton", background=[("active", "#304253")])
        self.style.configure("Header.TButton", width=0, padding=(5, 3))
        self.style.configure("TCheckbutton", background=BG, foreground="white")
        self.style.map("TCheckbutton", background=[("active", BG)])
        self.style.configure("TNotebook", background=BG, borderwidth=0)
        self.style.configure("TNotebook.Tab", background=PANEL, foreground="white", padding=(12, 6))
        self.style.map("TNotebook.Tab", background=[("selected", "#304253")])
        self.style.configure("Treeview", background=PANEL, fieldbackground=PANEL, foreground="white", rowheight=25)
        self.style.configure("Treeview.Heading", background="#273343", foreground="white")
        self.style.map("Treeview", background=[("selected", "#314c60")])
        try:
            if sys.platform == "darwin":
                root.iconphoto(True, tk.PhotoImage(file=str(bundle_root() / "Corp-Logo.png")))
            else:
                root.iconbitmap(str(bundle_root() / "EVE-Mining.ico"))
        except tk.TclError:
            pass
        self.body = tk.Frame(root, bg=BG, padx=8, pady=5)
        self.body.pack(fill="both", expand=True)
        header = tk.Frame(self.body, bg=BG)
        header.pack(fill="x")
        label(header, tr('MINING INCOME - ESTIMATE'), font=("Segoe UI", 9)).pack(side="left")
        self.options_button = button(header, tr('Options'), self.open_settings, style="Header.TButton")
        self.options_button.pack(side="right")
        button(header, tr('Reprocess'), self.open_reprocessing, style="Header.TButton").pack(side="right", padx=(0, 4))
        button(header, tr('Track Rock'), self.open_rock_tracker, style="Header.TButton").pack(side="right", padx=(0, 4))
        totals = tk.Frame(self.body, bg=BG)
        totals.pack(fill="x", pady=(2, 0))
        self.headline = tk.Label(totals, text="0.00 M ISK/h", font=("Segoe UI", 22, "bold"), fg=ACCENT, bg=BG, anchor="w")
        self.headline.pack(side="left")
        free_group = tk.Frame(totals, bg=BG)
        free_group.pack(side="right")
        self.free = tk.Label(free_group, bg=BG, fg=ACCENT, justify="right", font=("Segoe UI", 8))
        self.free.pack(anchor="e")
        self.boost = tk.Label(free_group, bg=BG, fg=ACCENT, justify="right", font=("Segoe UI", 8))
        self.boost.pack(anchor="e")
        Tooltip(self.boost, tr('Estimated from raw versus observed laser cycles. Booster ships may belong to other players; the fleet profile does not identify the boost source. Overlapping strengths may remain ambiguous.'))
        self.summary, self.prices = label(self.body), label(self.body, font=("Segoe UI", 8))
        self.summary.pack(fill="x", pady=(0, 1))
        price_line = tk.Frame(self.body, bg=BG)
        price_line.pack(fill="x")
        self.prices.destroy()
        self.prices = label(price_line, font=("Segoe UI", 8))
        self.prices.pack(side="left")
        self.price_age_label = label(price_line, font=("Segoe UI", 8))
        self.price_age_label.pack(side="right")
        self.graph = tk.Canvas(self.body, height=22, bg="#0c1219", highlightthickness=0)
        self.graph.pack(fill="x", pady=(4, 2))
        Tooltip(self.graph, tr('10 MIN TREND - estimated ISK/h per minute'))
        selectors = tk.Frame(self.body, bg=BG)
        selectors.pack(fill="x", pady=(3, 3))
        self.profile_var, self.mode_var = tk.StringVar(), tk.StringVar(value=self.engine.state["Mode"])
        self.profiles = ttk.Combobox(selectors, textvariable=self.profile_var, state="readonly", width=25)
        self.profiles.pack(side="left", fill="x", expand=True)
        self.profiles.bind("<<ComboboxSelected>>", lambda _: self.run(self.switch_profile))
        self.mode = ttk.Combobox(selectors, textvariable=self.mode_var, values=("ICE", "ORE"), state="readonly", width=6)
        self.mode.pack(side="left", padx=8)
        self.mode.bind("<<ComboboxSelected>>", lambda _: self.run(self.switch_mode))
        self.reset_all = button(selectors, tr('Reset all'), lambda: self.run(self.reset_everyone), width=9)
        self.reset_all.pack(side="right")
        reset_menu = tk.Menu(selectors, tearoff=False)
        reset_menu.add_command(label=tr('Confirm all displayed cargo values'), command=lambda: self.run(self.confirm_everyone))
        bind_cargo_menu(self.reset_all, reset_menu)
        self.fleet_canvas = tk.Canvas(self.body, bg=BG, highlightthickness=0, width=466)
        self.fleet_canvas.pack(fill="x")
        self.fleet_frame = tk.Frame(self.fleet_canvas, bg=BG)
        self.fleet_window = self.fleet_canvas.create_window(0, 0, window=self.fleet_frame, anchor="nw", width=450)
        self.fleet_frame.bind("<Configure>", lambda _: self.fleet_canvas.configure(scrollregion=self.fleet_canvas.bbox("all")))
        self.fleet_canvas.bind("<Configure>", lambda e: self.fleet_canvas.itemconfigure(self.fleet_window, width=e.width))
        controls = tk.Frame(self.body, bg=BG)
        controls.pack(fill="x", pady=(4, 1))
        button(controls, tr('New session'), lambda: self.run(self.new_session)).pack(side="left")
        self.compact = button(controls, tr('Expand'), self.toggle_compact)
        self.compact.pack(side="left", padx=7)
        self.top_var, self.attack_var = tk.BooleanVar(value=self.engine.state["Window"]["TopMost"]), tk.BooleanVar(value=self.engine.state["AttackSound"])
        ttk.Checkbutton(controls, text=tr('On top'), variable=self.top_var, command=lambda: self.run(self.set_top)).pack(side="left", padx=4)
        ttk.Checkbutton(controls, text=tr('Attack sound'), variable=self.attack_var, command=lambda: self.run(self.set_attack)).pack(side="right")
        second = tk.Frame(self.body, bg=BG)
        second.pack(fill="x", pady=1)
        self.pause_button = button(second, tr('Pause session'), lambda: self.run(self.pause_session), width=17)
        self.pause_button.pack(side="left")
        self.status = label(second, wraplength=300, justify="left", font=("Segoe UI", 8))
        self.status.pack(side="left", padx=(10, 0), fill="x", expand=True)
        self.rock_status = label(self.body, font=("Segoe UI", 8))
        self.rock_status.pack(fill="x", pady=1)
        footer = tk.Frame(self.body, bg=BG)
        footer.pack(fill="x", pady=(2, 0))
        try:
            self.logo = tk.PhotoImage(file=str(bundle_root() / "Corp-Logo.png")).subsample(32)
            tk.Label(footer, image=self.logo, bg=BG).pack(side="left", padx=(0, 7))
        except tk.TclError:
            self.logo = None
        link = label(footer, tr('Quick setup'), cursor="hand2", font=("Segoe UI", 8, "underline"))
        link.pack(side="left")
        link.bind("<Button-1>", lambda _: self.quick_setup())
        button(footer, tr('Ledger'), self.open_ledger).pack(side="left", padx=(6, 0))
        label(footer, "V2.18 · Python", font=("Segoe UI", 8)).pack(side="right")
        self.sync_profiles()
        self.build_rows()
        position = self.engine.state["Window"]
        if position.get("Left", -1) >= 0 and position.get("Top", -1) >= 0:
            x, y = int(position["Left"]), int(position["Top"])
            if x < root.winfo_screenwidth() and y < root.winfo_screenheight(): root.geometry(f"+{x}+{y}")
        self.root.attributes("-topmost", self.top_var.get())
        self.root.protocol("WM_DELETE_WINDOW", self.close)
        self.refresh()
        if live:
            self.timer = root.after(1000, self.tick)
            if not self.engine.state["Profiles"]:
                root.after(250, self.quick_setup)

    def run(self, action):
        try:
            action()
            self.save()
        except Exception as exc:
            self.engine.notice = str(exc)
        self.refresh()

    def save(self):
        self.engine.state["Window"].update(Left=self.root.winfo_x(), Top=self.root.winfo_y())
        self.engine.save()
        self.saved_at = time.time()

    def poll(self):
        if self.engine.logs_available():
            self.engine.poll()
            self.play_alerts()

    def play_alerts(self):
        if self.engine.cargo_requested:
            self.cargo_queued = True
            self.engine.notice = self.engine.cargo_alert
        if self.engine.sound_requested:
            self.audio.play(self.engine.state["AttackTone"], self.engine.state["AttackVolume"], "attack")
        elif self.cargo_queued and not self.audio.busy:
            self.cargo_queued = False
            if self.engine.state["CargoSound"]:
                self.audio.play(self.engine.state["CargoTone"], self.engine.state["CargoVolume"], "cargo")
        elif self.engine.rock and self.engine.rock["Pending"] and not self.audio.busy:
            self.engine.rock["Pending"] = False
            if self.engine.state["RockSound"]:
                self.audio.play(self.engine.state["RockTone"], self.engine.state["RockVolume"], "rock")

    def tick(self):
        try:
            self.poll()
            self.engine.auto_pause(time.time())
            if time.time() - self.saved_at >= 5:
                self.save()
        except Exception as exc:
            self.engine.notice = str(exc)
        self.refresh()
        self.timer = self.root.after(1000, self.tick)

    def sync_profiles(self):
        self.profile_names = [p["Name"] for p in self.engine.state["Profiles"]]
        active = self.engine.state["ActiveProfile"]
        self.profiles["values"] = self.profile_names
        if active in self.profile_names:
            self.profiles.current(self.profile_names.index(active))
        else:
            self.profile_var.set("")
        self.mode_var.set(self.engine.state["Mode"])

    def switch_profile(self):
        index = self.profiles.current()
        if index < 0:
            return
        self.poll()
        if self.profile_names[index] != self.engine.state["ActiveProfile"]:
            self.engine.rock = None
        self.engine.activate(self.profile_names[index])
        self.sync_profiles()
        self.build_rows()

    def switch_mode(self):
        if self.mode_var.get() != self.engine.state["Mode"]:
            self.engine.rock = None
        self.engine.state["Mode"] = self.mode_var.get()
        if self.engine.current:
            self.engine.current["Mode"] = self.mode_var.get()

    def reset_everyone(self):
        self.poll()
        for m in self.engine.members:
            self.engine.reset(m)

    def confirm_everyone(self):
        self.poll()
        if any(self.engine.ship(m)["Unknown"] for m in self.engine.members):
            raise ValueError(tr('Correct uncounted cargo before confirming the fleet.'))
        for m in self.engine.members:
            self.engine.ship(m)["Known"] = True

    def reset_pilot(self, member):
        self.poll()
        self.engine.reset(member)

    def new_session(self):
        self.poll()
        self.engine.start_session(time.time())
        ledger = getattr(self, "ledger_window", None)
        if ledger is not None and ledger.winfo_exists():
            ledger.event_generate("<<LedgerRefresh>>")

    def pause_session(self):
        self.poll()
        self.engine.pause(not self.engine.paused, time.time())
        for activity in self.engine.activities.values():
            activity["Since"] = time.time()
        self.engine.notice = tr('Paused. Next mining yield resumes.') if self.engine.paused else tr('Session resumed; pause time excluded.')

    def set_top(self):
        self.root.attributes("-topmost", self.top_var.get())
        self.engine.state["Window"]["TopMost"] = self.top_var.get()

    def set_attack(self):
        self.engine.state["AttackSound"] = self.attack_var.get()

    def toggle_compact(self):
        self.run(lambda: self.engine.state["Window"].update(Compact=not self.engine.state["Window"]["Compact"]))
        self.build_rows()
        self.refresh()

    def build_rows(self):
        for widget in self.fleet_frame.winfo_children():
            widget.destroy()
        self.rows.clear()
        for column in range(getattr(self, "fleet_columns", 1)):
            self.fleet_frame.columnconfigure(column, weight=0, minsize=0, uniform="")
        small = self.engine.state["Window"]["Compact"]
        self.compact.configure(text=tr('Expand') if small else tr('Compact'))
        self.style.configure("Pilot.TButton", padding=(4, 0) if small else (8, 3))
        if self.engine.state["DisplayStyle"] == "gauges":
            self.build_gauge_rows(small)
            return
        if self.engine.state["DisplayStyle"] == "strip":
            self.build_strip_rows(small)
            return
        column_width = 464 if small else 660
        max_columns = max(1, (self.root.winfo_screenwidth() - 48) // column_width)
        self.fleet_columns = min(max_columns, max(1, math.ceil(len(self.engine.members) / 8)))
        per_column = max(1, math.ceil(len(self.engine.members) / self.fleet_columns))
        width = self.fleet_columns * column_width + 16
        self.layout_width = width
        self.root.minsize(width, 1)
        self.root.geometry(f"{width}x600")
        self.headline.configure(font=("Segoe UI", 18 if small else 22, "bold"))
        self.graph.configure(height=18 if small else 38)
        for column in range(self.fleet_columns):
            self.fleet_frame.columnconfigure(column, weight=1, uniform="pilots")
        for index, m in enumerate(self.engine.members):
            frame = tk.Frame(self.fleet_frame, bg=BG)
            frame.grid(row=index % per_column, column=index // per_column, sticky="ew",
                       padx=(0, 12 if index // per_column < self.fleet_columns - 1 else 0),
                       pady=(1 if small else 4, 0))
            top = tk.Frame(frame, bg=BG)
            top.pack(fill="x")
            name = label(top, m["Character"] + " - " + m["ShipClass"], font=("Segoe UI", 9, "bold"))
            reset = button(top, tr('Reset'), lambda member=m: self.run(lambda: self.reset_pilot(member)),
                           width=6, style="Pilot.TButton")
            reset.pack(side="right")
            name.pack(side="left")
            mined = label(top, font=("Segoe UI", 9, "bold"))
            mined.configure(fg=ACCENT)
            mined.pack(side="left", padx=(8, 0))
            info = tk.Frame(frame, bg=BG)
            info.pack(fill="x")
            bar = tk.Canvas(info if small else frame, width=78, height=4, highlightthickness=1,
                            highlightbackground=BG, highlightcolor=BG, bg="#2f3a47")
            bar.pack(side="left" if small else "top", fill="none" if small else "x", padx=(0, 6 if small else 0))
            text = label(info, font=("Segoe UI", 8), wraplength=column_width-110 if small else column_width-28,
                         justify="left")
            text.pack(side="left", fill="x", expand=True)
            detail = label(frame, font=("Segoe UI", 8)) if not small else None
            if detail:
                detail.pack(fill="x")
            tip = Tooltip(text, "")
            menu = tk.Menu(frame, tearoff=False)
            menu.add_command(label=tr('Set current cargo...'), command=lambda member=m: self.set_cargo(member))
            menu.add_command(label=tr('Confirm displayed cargo'), command=lambda member=m: self.run(lambda: self.confirm_cargo(member)))
            for widget in (name, text, bar):
                bind_cargo_menu(widget, menu)
            self.rows.append(dict(Member=m, Name=name, Yield=mined, Text=text, Bar=bar, Detail=detail, Tooltip=tip))
        if not self.rows:
            label(self.fleet_frame, tr('No active pilots. Open Options to configure your fleet.'), wraplength=440).pack(pady=15)
        self.root.update_idletasks()
        requested = self.fleet_frame.winfo_reqheight()
        self.fleet_canvas.configure(height=max(36, requested), width=width-16)
        self.root.update_idletasks()
        self.root.geometry(f"{width}x{self.body.winfo_reqheight()}")

    def build_gauge_rows(self, small):
        count = len(self.engine.members)
        # Four cards on a typical small fleet; add columns for larger fleets.
        card_width = 136 if small else 164
        available = max(3, (self.root.winfo_screenwidth() - 48) // card_width)
        self.fleet_columns = min(available, max(3, min(4, count), math.ceil(count / 3)))
        width = self.fleet_columns * card_width + 16
        self.layout_width = width
        self.root.minsize(width, 1)
        self.root.geometry(f"{width}x600")
        self.headline.configure(font=("Segoe UI", 18 if small else 22, "bold"))
        self.graph.configure(height=18 if small else 38)
        for column in range(self.fleet_columns):
            self.fleet_frame.columnconfigure(column, weight=1, uniform="pilots")
        for index, member in enumerate(self.engine.members):
            frame = tk.Frame(self.fleet_frame, bg=BG, highlightthickness=1, highlightbackground="#2f3a47", padx=2, pady=1 if small else 2)
            frame.grid(row=index // self.fleet_columns, column=index % self.fleet_columns,
                       sticky="nsew", padx=1 if small else 2, pady=1 if small else 2)
            capacity = label(frame, font=("Segoe UI", 8))
            capacity.configure(anchor="center")
            capacity.pack(fill="x")
            gauge = tk.Canvas(frame, width=122 if small else 150, height=48 if small else 56, bg=BG, highlightthickness=0)
            gauge.pack()
            text = label(frame, font=("Segoe UI", 8), wraplength=card_width-12, justify="center")
            text.configure(anchor="center")
            text.pack(fill="x")
            name = label(frame, member["Character"], font=("Segoe UI", 8 if small else 9, "bold"), wraplength=card_width-12, justify="center")
            name.configure(anchor="center")
            name.pack(fill="x")
            card_controls = tk.Frame(frame, bg=BG)
            card_controls.pack(fill="x", pady=(1, 0))
            ship_label = label(card_controls, member["ShipClass"], font=("Segoe UI", 8))
            ship_label.configure(anchor="center", fg=MUTED)
            ship_label.pack(side="left")
            reset = button(card_controls, tr('Reset'), lambda m=member: self.run(lambda: self.reset_pilot(m)), width=6, style="Pilot.TButton")
            reset.pack(side="right")
            detail = None
            if not small:
                detail = label(frame, font=("Segoe UI", 8), wraplength=150, justify="center")
                detail.pack(fill="x")
            tip = Tooltip(gauge, "")
            menu = tk.Menu(frame, tearoff=False)
            menu.add_command(label=tr('Set current cargo...'), command=lambda m=member: self.set_cargo(m))
            menu.add_command(label=tr('Confirm displayed cargo'), command=lambda m=member: self.run(lambda: self.confirm_cargo(m)))
            for widget in (gauge, capacity, name, text, ship_label):
                bind_cargo_menu(widget, menu)
            self.rows.append(dict(Member=member, Name=name, Text=text, Bar=gauge, Detail=detail,
                                  Tooltip=tip, Gauge=True, Capacity=capacity, Yield=None))
        if not count:
            label(self.fleet_frame, tr('No active pilots. Open Options to configure your fleet.')).grid(columnspan=self.fleet_columns, pady=15)
        self.root.update_idletasks()
        self.fleet_canvas.configure(height=max(36, self.fleet_frame.winfo_reqheight()), width=width-16)
        self.root.update_idletasks()
        self.root.geometry(f"{width}x{self.body.winfo_reqheight()}")

    def build_strip_rows(self, small):
        count = len(self.engine.members)
        card_width = 136 if small else 172
        available = max(1, (self.root.winfo_screenwidth() - 48) // card_width)
        self.fleet_columns = min(available, max(3, min(4, count), math.ceil(count / 3)))
        self.layout_width = self.fleet_columns * card_width + 16
        self.root.minsize(self.layout_width, 1)
        self.root.geometry(f"{self.layout_width}x600")
        self.headline.configure(font=("Segoe UI", 18 if small else 22, "bold"))
        self.graph.configure(height=18 if small else 38)
        name_font = tkfont.Font(root=self.root, family="Segoe UI", size=8, weight="bold")
        for column in range(self.fleet_columns):
            self.fleet_frame.columnconfigure(column, weight=1, uniform="pilots")
        for index, member in enumerate(self.engine.members):
            frame = tk.Frame(self.fleet_frame, bg=BG)
            frame.grid(row=index // self.fleet_columns, column=index % self.fleet_columns,
                       sticky="nsew", padx=2, pady=2)
            tile = tk.Canvas(frame, width=card_width-4, height=44, bg=PANEL, highlightthickness=0)
            tile.pack(fill="x")
            reset = button(tile, "↺", lambda m=member: self.run(lambda: self.reset_pilot(m)), style="Pilot.TButton")
            tile.create_window(card_width-7, 41, anchor="se", window=reset, width=23, height=19, tags="reset")
            Tooltip(reset, tr('Reset cargo'))
            menu = tk.Menu(frame, tearoff=False)
            menu.add_command(label=tr('Set current cargo...'), command=lambda m=member: self.set_cargo(m))
            menu.add_command(label=tr('Confirm displayed cargo'), command=lambda m=member: self.run(lambda: self.confirm_cargo(m)))
            bind_cargo_menu(tile, menu)
            detail = None
            if not small:
                detail = label(frame, font=("Segoe UI", 8), wraplength=card_width-10)
                detail.pack(fill="x")
            self.rows.append(dict(Member=member, Name=None, Yield=None, Text=None, Bar=tile,
                                  Detail=detail, Tooltip=Tooltip(tile, ""), Strip=True, NameFont=name_font))
        if not count:
            label(self.fleet_frame, tr('No active pilots. Open Options to configure your fleet.')).grid(columnspan=self.fleet_columns, pady=15)
        self.root.update_idletasks()
        self.fleet_canvas.configure(height=max(36, self.fleet_frame.winfo_reqheight()), width=self.layout_width-16)
        self.root.update_idletasks()
        self.root.geometry(f"{self.layout_width}x{self.body.winfo_reqheight()}")

    def draw_strip(self, row, ratio, color, value, info, attacked, highlighted):
        tile = row["Bar"]
        width, height = int(tile["width"]), int(tile["height"])
        fill = {"green": "#236445", "yellow": "#6b5717", "orange": "#86411a", "red": "#922f3b"}
        tile.delete("paint")
        if ratio > 0:
            tile.create_rectangle(1, 1, 1+(width-2)*ratio, height-1, fill=fill[color], outline="", tags="paint")
        tile.create_rectangle(0, 0, width-1, height-1, outline="#fff3c4" if highlighted else "#465364", tags="paint")
        font = row["NameFont"]
        name = row["Member"]["Character"]
        space = width-20-font.measure(value)
        if font.measure(name) > space:
            while name and font.measure(name+"…") > space:
                name = name[:-1]
            name += "…"
        tile.create_text(6, 12, anchor="w", text=name, fill="#fa8072" if attacked else "white", font=font, tags="paint")
        tile.create_text(width-6, 12, anchor="e", text=value, fill="white", font=font, tags="paint")
        tile.create_text(6, 32, anchor="w", text=info, fill="#f5f6f8", font=("Segoe UI", 8), tags="paint")
        tile.tag_raise("reset")

    def draw_gauge(self, row, ratio, color, quantity, flags, highlighted, compressed_ratio=0):
        canvas = row["Bar"]
        canvas.delete("all")
        edge = "#fff3c4" if highlighted else BG
        canvas.configure(highlightbackground=edge, highlightcolor=edge, highlightthickness=1)
        small = int(canvas["width"]) < 150
        center = int(canvas["width"]) / 2
        radius, top, center_y, status_y = (36, 7, 30, 43) if small else (45, 9, 36, 51)
        box = (center-radius, top, center+radius, top+radius*2)
        arc_width = 8 if small else 10
        canvas.create_arc(*box, start=180, extent=-180, style="arc", width=arc_width, outline="#2f3a47")
        if ratio > compressed_ratio:
            canvas.create_arc(*box, start=180*(1-compressed_ratio), extent=-180*(ratio-compressed_ratio),
                              style="arc", width=arc_width, outline=COLORS[color])
        if compressed_ratio > 0:
            canvas.create_arc(*box, start=180, extent=-180*compressed_ratio, style="arc",
                              width=arc_width, outline=MUTED, dash=(3, 2), tags="compressed")
        percent = 100 if ratio >= 1 else min(99, round(ratio*100))
        status = " · ".join(flags)
        if quantity:
            canvas.create_text(center, center_y, text=f"+{format_number(quantity, ',.0f')}", fill=COLORS["yellow"] if "CRIT" in flags else ACCENT,
                               font=("Segoe UI", 12 if small else 13, "bold"))
        else:
            canvas.create_text(center, center_y, text=f"{percent}%", fill=COLORS[color], font=("Segoe UI", 12 if small else 14, "bold"))
        if status:
            short = tr('FULL') if ratio >= 1 else tr('ATTACK') if tr('ATTACK') in flags else tr('CHECK') if any(f in flags for f in (tr('IRREGULAR'), tr('VERIFY CARGO'), tr('UNCOUNTED'))) else tr('CARGO') if color in ("orange", "red") else tr("CRIT") if "CRIT" in flags else tr("RESET")
            canvas.create_text(center, status_y, text=short, fill=COLORS[color], font=("Segoe UI", 7, "bold"))

    def confirm_cargo(self, member):
        self.poll()
        ship = self.engine.ship(member)
        if ship["Unknown"]:
            raise ValueError(tr('Correct uncounted cargo first.'))
        ship["Known"] = True

    def set_cargo(self, member):
        self.run(self.poll)
        ship = self.engine.ship(member)
        result = simpledialog.askstring(tr('Set current cargo'), tr('Current cargo in m³ (Reset is for an empty hold):'), initialvalue=str(ship["Volume"]), parent=self.root)
        if result is None:
            return
        def apply():
            value = parse_number(result)
            if not 0 <= value <= 1000000000:
                raise ValueError(tr('Cargo must be 0 to 1,000,000,000 m³.'))
            self.poll()
            self.engine.reset(member)
            ship.update(Volume=value, UnassignedVolume=value)
            if self.engine.state["Mode"] == "ICE":
                ship["Units"] = ship["IceBlocks"] = value / 1000
        self.run(apply)

    def refresh(self):
        now, combat = time.time(), ""
        self.refresh_rock()
        highlight_now = time.monotonic()
        for row in self.rows:
            m = row["Member"]
            quantity = self.engine.recent_yield(m["Character"], highlight_now)
            if row["Yield"] is not None:
                row["Yield"].configure(text=f"+{format_number(quantity, ',.0f')}" if quantity else "")
            ship = self.engine.ship(m)
            ratio = self.engine.hold_ratio(ship)
            warning, color = self.engine.activity_warning(m, now), self.engine.color(ship, now)
            flags = []
            if color == "red": flags.append(tr('FULL') if ratio >= 1 else tr('CARGO'))
            elif color == "orange": flags.append(tr('CARGO'))
            if ship["CriticalUntil"] > now and color != "red": flags.append("CRIT")
            if warning: flags.append(tr('IRREGULAR'))
            if not ship["Known"]: flags.append(tr('VERIFY CARGO'))
            if ship["Unknown"]: flags.append(tr('UNCOUNTED'))
            if self.engine.unload_highlights.get(m["Character"], 0) > highlight_now:
                flags.append(tr('Auto-reset: unloaded'))
            attack = self.engine.attacks.get(m["Character"])
            attacked = attack and now - attack["Time"] <= 45
            if row["Name"] is not None:
                row["Name"].configure(fg="#fa8072" if attacked else "white")
            if attacked:
                flags.insert(0, tr('ATTACK'))
                combat = f"{tr('UNDER ATTACK: ')}{m['Character']}"
                combat += f" - {attack['Attacker']}"
            free = max(D(0), ship["Capacity"] - ship["Volume"])
            eta, _ = self.engine.eta(m, now)
            compact = self.engine.state["Window"]["Compact"]
            percent = 100 if ratio >= 1 else min(99, round(ratio*100))
            text = (" | ".join(flags) + " | " if flags else "") + (
                f"{format_number(ship['Volume'], ',.0f')}/{format_number(ship['Capacity'], ',.0f')} m³ · {percent}%" if compact else
                f"{format_number(ship['Volume'], ',.0f')} / {format_number(ship['Capacity'], ',.0f')} m³ ({percent}%)")
            if self.engine.state["Mode"] == "ICE": text += f" | {format_number(int(free // 1000), ',')}{tr(' blocks fit')}"
            text += " | " + eta
            if row.get("Gauge"):
                row["Capacity"].configure(text=f"{format_number(ship['Volume'], ',.0f')} / {format_number(ship['Capacity'], ',.0f')} m³")
                info = f"{format_number(int(free // 1000), ',')}{tr(' fit')}" if self.engine.state["Mode"] == "ICE" else f"{format_number(free, ',.0f')}{tr(' m³ free')}"
                visible_flags = [f for f in flags if f not in (tr('FULL'), tr('CARGO'), "CRIT")]
                text = info + " · " + eta + ("\n" + " · ".join(visible_flags) if visible_flags else "")
            if row["Text"] is not None:
                row["Text"].configure(text=text, fg="#ffa500" if warning or not ship["Known"] or ship["Unknown"] else MUTED)
            bar = row["Bar"]
            border = "#fff3c4" if self.engine.cargo_highlights.get(m["Character"], 0) > highlight_now else BG
            bar.configure(highlightbackground=border, highlightcolor=border)
            compressed_volume = D(0)
            if row.get("Strip"):
                short_flags = {tr('IRREGULAR'): tr('CHECK'), tr('VERIFY CARGO'): tr("CHECK"), tr('UNCOUNTED'): tr('UNCOUNTED'),
                               tr('Auto-reset: unloaded'): tr('UNLOADED'), tr('ATTACK'): tr('ATTACK')}
                info = next((short_flags[flag] for flag in flags if flag in short_flags), eta)
                value = f"+{format_number(quantity, ',.0f')}" if quantity else f"{percent}%"
                self.draw_strip(row, ratio, color, value, info, attacked, border != BG)
            elif row.get("Gauge"):
                compressed_volume = self.engine.compressed_hold_volume(ship)
                compressed_ratio = ratio * float(compressed_volume / ship["Volume"]) if ship["Volume"] > 0 else 0
                self.draw_gauge(row, ratio, color, quantity, flags, border != BG, compressed_ratio)
            else:
                bar.delete("all")
                bar.create_rectangle(1, 1, 1 + max(1, bar.winfo_width() - 2) * min(1, max(0, ratio)), 5, fill=COLORS[color], outline="")
            cycle = self.engine.cycle(m, now)
            detail = f"{tr('Cycle ~')}{cycle['Seconds']:.1f}s ({cycle['Source']}{tr('); raw reference ')}{m.get('CycleSeconds', 0):.1f}s" if laser_count(m) else tr('Boost-only ship; mining activity hints disabled.')
            if row["Detail"]: row["Detail"].configure(text=detail, fg=MUTED)
            row["Tooltip"].text = f"{format_number(free, ',.2f')}{tr(' m³ free\n')}" + " · ".join(flags) + f"\n{detail}"
            row["Tooltip"].text += f"{tr('\nLast: ')}{ship['Last']}"
            row["Tooltip"].text += f"\n{warning}"
            row["Tooltip"].text += f"\n{ship['Unknown']}"
            if compressed_volume:
                row["Tooltip"].text = f"{tr('Tracked compressed cargo: ')}{format_number(compressed_volume, ',.2f')} m³\n{row['Tooltip'].text}"
            if row.get("Strip"):
                cargo = f"{m['Character']} · {m['ShipClass']}\n{format_number(ship['Volume'], ',.0f')} / {format_number(ship['Capacity'], ',.0f')} m³ ({percent}%)"
                row["Tooltip"].text = f"{cargo} · {eta}\n{row['Tooltip'].text}"
        # Wrapped warnings can make a row taller. Keep the whole fleet visible.
        self.root.update_idletasks()
        requested = max(36, self.fleet_frame.winfo_reqheight())
        if int(self.fleet_canvas["height"]) != requested:
            self.fleet_canvas.configure(height=requested)
            self.root.update_idletasks()
            # Windows may still report its initial 200px width during startup.
            # The layout width is authoritative, including before the first map.
            self.root.geometry(f"{self.layout_width}x{self.body.winfo_reqheight()}")
        income = self.engine.income(now)
        if self.engine.rate_refresh or now - self.headline_at >= 60:
            self.headline.configure(text=isk(income["Rate"]) + " ISK/h")
            self.headline_at, self.engine.rate_refresh = now, False
        self.headline.configure(fg=MUTED if self.engine.paused else ACCENT)
        seconds = int(income["Seconds"])
        self.summary.configure(text=(tr('PAUSED | ') if self.engine.paused else "") + f"{tr('Session ')}{isk(income['Value'])} ISK | {seconds // 3600:02}:{seconds % 3600 // 60:02}:{seconds % 60:02} | {format_number(income['Units'], ',.0f')}{tr(' units mined')}")
        partial = income["Missing"] or income["Unsupported"]
        price_label = f"{tr('Reprocessed BUY (')}{format_number(MAX_REPROCESS_YIELD, '.2f')}%)"
        self.prices.configure(text=price_label + (tr(' · PARTIAL') if partial else tr(' · before fees')),
                              fg="#ffa500" if partial else MUTED)
        show_price_age(self.price_age_label, self.engine.state["LastPriceUpdate"])
        free = self.engine.free_fleet()
        self.free.configure(text=(f"{tr('Miners free: ')}{format_number(free['Blocks'], ',')}/{format_number(free['TotalBlocks'], ',')}{tr(' ice blocks')}" if self.engine.state["Mode"] == "ICE" else f"{tr('Miners free: ')}{format_number(free['Volume'], ',.0f')}/{format_number(free['Capacity'], ',.0f')} m³"), fg=COLORS[self.engine.fleet_capacity_color(free)])
        self.boost.configure(text=tr('Verify cargo values first') if free["Unconfirmed"] else self.engine.boost_label(now))
        self.pause_button.configure(text=tr('Resume session') if self.engine.paused else tr('Pause session'))
        status = tr(self.engine.notice)
        self.status.configure(text=combat or status, fg="#fa8072" if combat else MUTED)
        canvas, values = self.graph, self.engine.trend(now)
        width, height = max(100, canvas.winfo_width()), int(canvas["height"])
        canvas.delete("all")
        canvas.create_line(0, height-2, width, height-2, fill="#3e576a")
        maximum = max(1, max(values))
        points = [coordinate for i, value in enumerate(values) for coordinate in (4+i*(width-8)/9, height-5-value/maximum*(height-12))]
        canvas.create_line(*points, fill=ACCENT, width=1.5)
        if self.settings and self.settings.window.winfo_exists():
            self.settings.update_free()
            show_price_age(self.settings.price_age_label, self.engine.state["LastPriceUpdate"])
        reprocess_age = getattr(self, "reprocess_price_age_label", None)
        if reprocess_age is not None and reprocess_age.winfo_exists():
            show_price_age(reprocess_age, self.engine.state["LastPriceUpdate"])

    def refresh_reprocessing_prices(self):
        dialog = getattr(self, "reprocess_window", None)
        if dialog is not None and dialog.winfo_exists():
            dialog.event_generate("<<PricesChanged>>")

    def material_label(self, name):
        return self.engine.german_materials.get(name, name) if language() == "de" else name

    def refresh_rock(self):
        rock = self.engine.rock
        if rock is None:
            self.rock_status.configure(text="")
            return
        remaining = rock["Remaining"]
        if rock["Material"] is None:
            text = tr('{count} units · waiting for first mining yield').format(count=format_number(remaining, ",.0f"))
            self.rock_status.configure(text=text, fg=MUTED)
            return
        color = COLORS["red"] if remaining == 0 else COLORS["orange"] if remaining <= rock["Threshold"] else MUTED
        text = tr('{material} · ~{remaining}/{initial} units left').format(
            material=self.material_label(rock["Material"]),
            remaining=format_number(remaining, ",.0f"), initial=format_number(rock["Initial"], ",.0f"))
        self.rock_status.configure(text=text, fg=color)

    def open_rock_tracker(self):
        dialog = tk.Toplevel(self.root)
        dialog.title(tr('Track rock · Experimental'))
        dialog.configure(bg=BG)
        dialog.transient(self.root)
        rock = self.engine.rock
        units = ttk.Entry(dialog, width=12)
        label(dialog, tr('The first mining yield identifies the material. Aim the tracked lasers at the same rock for the estimate.'),
              wraplength=390, justify="left").grid(row=0, column=0, columnspan=2, sticky="w", padx=12, pady=10)
        label(dialog, tr('Units remaining now')).grid(row=1, column=0, sticky="w", padx=12, pady=5)
        units.grid(row=1, column=1, sticky="w", padx=12, pady=5)
        actions = ttk.Frame(dialog)
        actions.grid(row=2, column=0, columnspan=2, sticky="ew", padx=12, pady=10)

        def start():
            try:
                amount = parse_number(units.get())
                self.poll()
                self.engine.start_rock(amount, time.time())
            except (ArithmeticError, ValueError, OSError) as exc:
                message = tr('Enter a whole number of units from 1 to 1,000,000,000.') if isinstance(exc, ArithmeticError) else str(exc)
                messagebox.showerror(tr('Track rock · Experimental'), message, parent=dialog)
                return
            self.refresh_rock()
            dialog.destroy()

        def stop():
            self.engine.rock = None
            self.refresh_rock()
            dialog.destroy()

        if rock:
            button(actions, tr('Stop tracking'), stop).pack(side="left")
        button(actions, tr('Start tracking'), start).pack(side="right")
        dialog.bind("<Return>", lambda _: start())
        dialog.bind("<Escape>", lambda _: dialog.destroy())
        dialog.grab_set()
        units.focus_set()

    def open_ledger(self):
        existing = getattr(self, "ledger_window", None)
        if existing is not None and existing.winfo_exists():
            existing.lift()
            existing.event_generate("<<LedgerRefresh>>")
            return
        dialog = self.ledger_window = tk.Toplevel(self.root)
        dialog.title(tr('Mining Ledger'))
        dialog.transient(self.root)
        dialog.configure(bg=BG)
        dialog.geometry("880x590")
        dialog.minsize(800, 480)
        panel = ttk.Frame(dialog, padding=12)
        panel.pack(fill="both", expand=True)
        filters = ttk.Frame(panel)
        filters.pack(fill="x")
        start, end = tk.StringVar(), tk.StringVar()
        for title, value in (('From (UTC)', start), ('To (UTC)', end)):
            ttk.Label(filters, text=tr(title)).pack(side="left")
            ttk.Entry(filters, width=12, textvariable=value).pack(side="left", padx=(4, 10))
        material = ttk.Combobox(filters, state="readonly", width=24)
        material.pack(side="left", padx=(0, 8))
        button(filters, tr('Refresh'), lambda: refresh()).pack(side="left")
        label(panel, tr('Leave dates blank for all history. Date format YYYY-MM-DD.'),
              font=("Segoe UI", 8)).pack(fill="x", pady=(4, 0))
        summary = label(panel, font=("Segoe UI", 9, "bold"))
        summary.pack(fill="x", pady=(8, 4))
        charts = ttk.Frame(panel)
        charts.pack(fill="x")
        charts.columnconfigure((0, 1), weight=1, uniform="ledger")
        material_chart = tk.Canvas(charts, bg=PANEL, width=360, height=170, highlightthickness=0)
        day_chart = tk.Canvas(charts, bg=PANEL, width=360, height=170, highlightthickness=0)
        material_chart.grid(row=0, column=0, sticky="ew", padx=(0, 5))
        day_chart.grid(row=0, column=1, sticky="ew", padx=(5, 0))
        table_frame = ttk.Frame(panel)
        table_frame.pack(fill="both", expand=True, pady=(10, 0))
        columns = ("date", "material", "quantity", "volume")
        table = ttk.Treeview(table_frame, columns=columns, show="headings")
        for key, title, width in zip(columns, ('Date (UTC)', 'Material', 'Quantity', 'Volume (m³)'), (140, 345, 120, 130)):
            anchor = "e" if key in ("quantity", "volume") else "w"
            table.heading(key, text=tr(title), anchor=anchor)
            table.column(key, width=width, anchor=anchor, stretch=key == "material")
        scroll = ttk.Scrollbar(table_frame, orient="vertical", command=table.yview)
        table.configure(yscrollcommand=scroll.set)
        scroll.pack(side="right", fill="y")
        table.pack(side="left", fill="both", expand=True)
        chart_data = Counter(), Counter()

        def refresh():
            nonlocal chart_data
            selected = material.current()
            old_names = getattr(material, "ledger_materials", [])
            selected_name = old_names[selected - 1] if 0 < selected <= len(old_names) else None
            try:
                date_texts = (value.get().strip() for value in (start, end))
                first, last = (date.fromisoformat(value).isoformat() if value else "" for value in date_texts)
                if first and last and first > last:
                    raise ValueError
            except ValueError:
                summary.configure(text=tr('Enter a valid date range using YYYY-MM-DD.'), fg=COLORS["red"])
                return
            try:
                rows, unreadable = self.engine.ledger_rows()
            except (OSError, ValueError):
                summary.configure(text=tr('Could not read the session archive.'), fg=COLORS["red"])
                return
            names = sorted({name for _, name in rows}, key=self.material_label)
            material.ledger_materials = names
            material.configure(values=[tr('All materials'), *(self.material_label(name) for name in names)])
            material.current(names.index(selected_name) + 1 if selected_name in names else 0)
            table.delete(*table.get_children())
            totals, daily = Counter(), Counter()
            for (day, name), quantity in sorted(rows.items(), reverse=True):
                if selected_name is not None and name != selected_name:
                    continue
                if (first or last) and (not day or (first and day < first) or (last and day > last)):
                    continue
                totals[name] += quantity
                if day:
                    daily[day] += quantity
                item = self.engine.items.get(name)
                volume = format_number(quantity * item["Volume"], ",.2f") if item else "—"
                table.insert("", "end", values=(day or tr('Date unavailable'), self.material_label(name),
                                                format_number(quantity, ",.0f"), volume))
            summary_text = tr('{count} units mined · all pilots').format(count=format_number(sum(totals.values()), ",.0f"))
            if unreadable:
                summary_text += " · " + tr('{count} archive files could not be read').format(count=unreadable)
            summary.configure(text=summary_text, fg=COLORS["orange"] if unreadable else ACCENT)
            chart_data = totals, daily
            draw_charts()

        def draw_charts(_event=None):
            totals, daily = chart_data
            for canvas, title in ((material_chart, 'Quantity by material · Top 6'), (day_chart, 'Daily quantity · UTC')):
                canvas.delete("all")
                canvas.create_text(10, 12, text=tr(title), anchor="w", fill="white")
            width = max(350, material_chart.winfo_width())
            maximum = max(totals.values(), default=1)
            for index, (name, quantity) in enumerate(totals.most_common(6)):
                y = 30 + index * 21
                material_chart.create_text(10, y + 7, text=self.material_label(name)[:25], anchor="w", fill="white")
                end_x = 160 + float(quantity / maximum) * (width - 235)
                material_chart.create_rectangle(160, y, end_x, y + 14, fill=ACCENT, outline="")
                material_chart.create_text(width - 10, y + 7, text=format_number(quantity, ",.0f"), anchor="e", fill="white")
            if not daily:
                day_chart.create_text(10, 55, text=tr('No dated mining recorded for this selection.'), anchor="w", fill=MUTED)
                return
            dates = sorted(daily)
            start_day, end_day = map(date.fromisoformat, (dates[0], dates[-1]))
            width = max(350, day_chart.winfo_width())
            span = (end_day - start_day).days
            baseline = 145
            day_chart.create_line(16, baseline, width - 16, baseline, fill=MUTED)
            scale = max(daily.values())
            for day, quantity in daily.items():
                offset = (date.fromisoformat(day) - start_day).days
                x = 24 + (width - 48) * (offset / span if span else .5)
                day_chart.create_line(x, baseline, x, baseline - 105 * float(quantity / scale), fill=ACCENT, width=3)
            day_chart.create_text(16, 157, text=dates[0], anchor="w", fill=MUTED)
            if span:
                day_chart.create_text(width - 16, 157, text=dates[-1], anchor="e", fill=MUTED)

        material.bind("<<ComboboxSelected>>", lambda _: refresh())
        dialog.bind("<Return>", lambda _: refresh())
        dialog.bind("<<LedgerRefresh>>", lambda _: refresh())
        material_chart.bind("<Configure>", draw_charts)
        day_chart.bind("<Configure>", draw_charts)
        dialog.update_idletasks()
        refresh()

    def open_reprocessing(self):
        existing = getattr(self, "reprocess_window", None)
        if existing is not None and existing.winfo_exists():
            existing.lift()
            return
        dialog = self.reprocess_window = tk.Toplevel(self.root)
        dialog.title(tr('Reprocess — current mining session'))
        dialog.transient(self.root)
        dialog.configure(bg=BG)
        dialog.geometry("900x680")
        dialog.minsize(720, 550)
        panel = tk.Frame(dialog, bg=BG, padx=16, pady=12)
        panel.pack(fill="both", expand=True)
        label(panel, tr('REPROCESSING ESTIMATE'), font=("Segoe UI", 15, "bold")).pack(anchor="w")
        label(panel, tr('Current session · all pilots · before tax')).pack(anchor="w", pady=(0, 10))

        metadata = self.engine.reprocessing_metadata
        icons = {}

        def item_icon(name, mined):
            if mined:
                item = self.engine.items.get(name)
                if item is None:
                    return None
                path = bundle_root() / "mined-icons" / f"{item['TypeId']}.png"
            else:
                path = bundle_root() / "reprocess-icons" / f"{name}.png"
            if path not in icons:
                try:
                    image = tk.PhotoImage(master=dialog, file=str(path))
                    scale = max(1, math.ceil(max(image.width(), image.height()) / 32))
                    icons[path] = image if scale == 1 else image.subsample(scale)
                except tk.TclError:
                    icons[path] = None
            return icons[path]

        def make_table(title):
            label(panel, title, font=("Segoe UI", 10, "bold")).pack(anchor="w", pady=(4, 3))
            frame = ttk.Frame(panel)
            frame.pack(fill="both", expand=True)
            self.style.configure("Reprocess.Treeview", rowheight=35)
            table = ttk.Treeview(frame, columns=("Amount", "Volume", "Buy", "Sell"),
                                 show="tree headings", height=4, style="Reprocess.Treeview")
            table.heading("#0", text=tr("Item"), anchor="w")
            table.column("#0", width=240, minwidth=150)
            for column, title, width in (("Amount", "Amount", 90), ("Volume", tr('Volume (m³)'), 120),
                                         ("Buy", tr('Buy total (ISK)'), 145), ("Sell", tr('Sell total (ISK)'), 145)):
                table.heading(column, text=tr(title), anchor="e")
                table.column(column, width=width, minwidth=75, anchor="e", stretch=False)
            scroll = ttk.Scrollbar(frame, orient="vertical", command=table.yview)
            table.configure(yscrollcommand=scroll.set)
            scroll.pack(side="right", fill="y")
            table.pack(side="left", fill="both", expand=True)
            summary = label(panel, font=("Segoe UI", 9, "bold"))
            summary.pack(anchor="w", pady=(4, 6))
            return table, summary

        def fill_table(table, summary, quantities, volumes, mined_materials=False):
            table.delete(*table.get_children())
            total_volume = total_buy = total_sell = D(0)
            priced_buy = priced_sell = known_volume = 0
            for name, quantity in sorted(quantities.items()):
                unit_volume = volumes.get(name)
                volume = quantity * D(str(unit_volume)) if unit_volume is not None else None
                if volume is not None:
                    total_volume += volume
                    known_volume += 1
                unit_buy, unit_sell = self.engine.reprocessing_quote(name, mined_material=mined_materials)
                buy = quantity * unit_buy if unit_buy is not None else None
                sell = quantity * unit_sell if unit_sell is not None else None
                if buy is not None:
                    total_buy += buy
                    priced_buy += 1
                if sell is not None:
                    total_sell += sell
                    priced_sell += 1
                values = (f"{format_number(quantity, ',')}", *(f"{format_number(value, ',.2f')}" if value is not None else "—"
                                               for value in (volume, buy, sell)))
                icon = item_icon(name, mined=mined_materials)
                options = {"image": icon} if icon else {}
                table.insert("", "end", text=self.material_label(name), values=values, **options)
            volume_note = f"{format_number(total_volume, ',.2f')} m³" if known_volume else "—"
            if 0 < known_volume < len(quantities):
                volume_note += tr(' (partial)')
            buy_text = f"{format_number(total_buy, ',.2f')} ISK" if priced_buy else "—"
            sell_text = f"{format_number(total_sell, ',.2f')} ISK" if priced_sell else "—"
            if 0 < priced_buy < len(quantities): buy_text += tr(' (partial)')
            if 0 < priced_sell < len(quantities): sell_text += tr(' (partial)')
            prices = f"{tr('Buy ')}{buy_text}{tr('   ·   Sell ')}{sell_text}"
            summary.configure(text=f"{tr('Volume ')}{volume_note}   ·   {prices}")

        inputs, input_total = make_table(tr('Mined materials'))
        controls = tk.Frame(panel, bg=BG)
        controls.pack(fill="x", pady=(4, 8))
        label(controls, tr('Yield (%)')).pack(side="left")
        yield_text = tk.StringVar(value=getattr(self, "reprocess_yield", str(MAX_REPROCESS_YIELD)))
        entry = ttk.Entry(controls, textvariable=yield_text, width=9)
        entry.pack(side="left", padx=8)
        calculate = button(controls, tr('Calculate / refresh'), lambda: refresh_result())
        calculate.pack(side="left")
        outputs, output_total = make_table(tr('Estimated products'))
        notes = label(panel, wraplength=850, justify="left")
        notes.pack(anchor="w")
        sample_date, _ = price_age(metadata["AsOfUtc"])
        label(panel, f"{tr('Imported BUY prices take priority · fallback quotes use Janice samples from ')}{sample_date}{tr('\nInput quotes use compressed equivalents')}", justify="left").pack(anchor="w", pady=(6, 0))
        self.reprocess_price_age_label = label(panel, font=("Segoe UI", 9))
        self.reprocess_price_age_label.pack(anchor="w")
        show_price_age(self.reprocess_price_age_label, self.engine.state["LastPriceUpdate"])
        input_volumes = {name: item["Volume"] for name, item in self.engine.items.items()}

        def refresh_result():
            mined = self.engine.session_mined_quantities()
            fill_table(inputs, input_total, mined, input_volumes, mined_materials=True)
            try:
                value = D(yield_text.get().strip().replace(",", "."))
                products, leftovers, unsupported = self.engine.reprocess_session(value)
                self.reprocess_yield = str(value)
            except (ArithmeticError, ValueError):
                fill_table(outputs, output_total, {}, metadata["Volumes"])
                notes.configure(text=tr('Enter a yield above 0 and up to 100%, for example 90.63.'))
                return
            fill_table(outputs, output_total, products, metadata["Volumes"])
            details = []
            if not products:
                details.append(tr('No products from complete batches at this yield.'))
            for title, quantities in ((tr('Left over'), leftovers), (tr('No recipe'), unsupported)):
                if quantities:
                    details.append(title + ": " + ", ".join(f"{self.material_label(name)} × {format_number(quantity, ',')}" for name, quantity in sorted(quantities.items())))
            notes.configure(text="\n".join(details))

        entry.bind("<Return>", lambda _: refresh_result())
        dialog.bind("<<PricesChanged>>", lambda _: refresh_result())
        refresh_result()

    def open_settings(self):
        if self.settings and self.settings.window.winfo_exists():
            self.settings.window.deiconify()
            self.settings.window.lift()
        else:
            self.settings = Settings(self)

    def quick_setup(self):
        messagebox.showinfo(tr('EVE Mining V2.18 - Quick setup'), tr('1. Options: choose your local Gamelogs folder.\n2. Add pilots from logs.\n3. Select pilots and use Edit selected to set ship class and actual cargo capacity.\n4. Set Lasers (0 disables hints) and raw unboosted cycle (0 = auto).\n5. Name your profile, choose ICE / ORE, then Save and activate.\n6. Confirm starting cargo: Reset if empty; right-click otherwise.\n7. Alerts: choose local cargo / attack sounds, test and save.\n\nAfter 5 minutes without mining, the session auto-pauses.\nPrices are an offline BUY snapshot; update by manual import.'), parent=self.root)

    def close(self):
        if self.timer: self.root.after_cancel(self.timer)
        try:
            if self.live: self.save()
        except Exception as exc:
            messagebox.showerror(tr('Could not save'), str(exc), parent=self.root)
            if self.live:
                self.timer = self.root.after(1000, self.tick)
            return
        self.audio.close()
        self.root.destroy()


class Settings:
    def __init__(self, app):
        self.app, self.engine = app, app.engine
        self.window = tk.Toplevel(app.root)
        self.window.title(tr('EVE Mining - Options'))
        self.window.configure(bg=BG)
        self.window.geometry("900x690")
        self.window.minsize(850, 650)
        self.window.transient(app.root)
        self.window.protocol("WM_DELETE_WINDOW", self.close)
        self.tabs = ttk.Notebook(self.window)
        self.tabs.pack(fill="both", expand=True, padx=10, pady=10)
        self.fleet, self.prices, self.alerts, self.display, self.languages = [ttk.Frame(self.tabs, padding=12) for _ in range(5)]
        for frame, title in zip((self.fleet, self.prices, self.alerts, self.display, self.languages),
                                (tr('Fleet profiles'), tr('Prices / Janice'), tr('Alerts'), tr('Display Style'), tr('Languages'))):
            self.tabs.add(frame, text=title)
        button(self.window, tr('Close'), self.close).pack(anchor="e", padx=12, pady=(0, 10))
        self.make_fleet()
        self.make_prices()
        self.make_alerts()
        self.make_display()
        self.make_languages()

    def make_languages(self):
        parent = self.languages
        label(parent, tr('Languages'), font=("Segoe UI", 15, "bold")).pack(anchor="w", pady=(4, 8))
        label(parent, tr('Choose the application language. English and German Gamelogs are read automatically.'),
              wraplength=800).pack(anchor="w", pady=(0, 12))
        self.language_choice = tk.StringVar(value="Deutsch" if self.engine.state["Language"] == "de" else "English")
        ttk.Combobox(parent, textvariable=self.language_choice, values=("English", "Deutsch"),
                     state="readonly", width=20).pack(anchor="w")
        button(parent, tr('Save language'), lambda: self.guarded(self.save_language)).pack(anchor="w", pady=12)

    def save_language(self):
        chosen = "de" if self.language_choice.get() == "Deutsch" else "en"
        previous = self.engine.state["Language"]
        self.engine.state["Language"] = chosen
        try:
            self.app.save()
        except Exception:
            self.engine.state["Language"] = previous
            raise
        messagebox.showinfo(tr("Languages"), tr("Language saved. Restart EVE Mining to apply it."), parent=self.window)

    def make_display(self):
        parent = self.display
        label(parent, tr('Display Style'), font=("Segoe UI", 15, "bold")).pack(anchor="w", pady=(4, 8))
        label(parent, tr('Choose the fleet view. All styles use the same tracking and alerts.')).pack(anchor="w", pady=(0, 16))
        self.display_style = tk.StringVar(value=self.engine.state["DisplayStyle"])
        for style, title in (("bars", tr('Style A — Bars')), ("gauges", tr('Style B — Gauges')), ("strip", tr('Style C — Fleet Strip'))):
            card = tk.Frame(parent, bg=PANEL, padx=12, pady=10)
            card.pack(fill="x", pady=6)
            ttk.Radiobutton(card, text=title, value=style, variable=self.display_style).pack(side="left", padx=(0, 20))
            preview = tk.Canvas(card, width=320, height=80, bg=PANEL, highlightthickness=0)
            preview.pack(side="right")
            if style == "bars":
                for i, (ratio, color) in enumerate(((.61, "green"), (.45, "yellow"), (.90, "orange"))):
                    y = i*25+8
                    preview.create_text(5, y+4, text=f"{tr('Pilot ')}{i + 1:02}", anchor="w", fill="white")
                    preview.create_rectangle(75, y, 265, y+9, fill="#2f3a47", outline="")
                    preview.create_rectangle(75, y, 75+190*ratio, y+9, fill=COLORS[color], outline="")
                    preview.create_text(300, y+4, text=f"{ratio:.0%}", fill="white")
            elif style == "gauges":
                for i, (ratio, color) in enumerate(((.61, "green"), (.45, "yellow"), (.90, "orange"))):
                    x=i*104+8
                    preview.create_arc(x, 8, x+70, 78, start=180, extent=-180, style="arc", width=7, outline="#2f3a47")
                    preview.create_arc(x, 8, x+70, 78, start=180, extent=-180*ratio, style="arc", width=7, outline=COLORS[color])
                    preview.create_text(x+35, 65, text=f"{tr('Pilot ')}{i + 1:02} · {ratio:.0%}", fill="white", font=("Segoe UI", 8))
            else:
                for i, (ratio, fill) in enumerate(((.61, "#236445"), (.45, "#6b5717"), (.90, "#86411a"))):
                    x = i*106+3
                    preview.create_rectangle(x, 21, x+100, 60, fill=BG, outline=MUTED)
                    preview.create_rectangle(x+1, 22, x+100*ratio, 59, fill=fill, outline="")
                    preview.create_text(x+6, 33, text=f"{tr('Pilot ')}{i + 1:02}", anchor="w", fill="white")
                    preview.create_text(x+94, 49, text=f"{ratio:.0%}", anchor="e", fill="white")
        label(parent, tr('Style C shows cargo, yield and ETA in compact tiles. Hover for details.\nReset and right-click cargo controls are available in all styles.'), justify="left").pack(anchor="w", pady=16)
        button(parent, tr('Apply display style'), lambda: self.guarded(self.save_display)).pack(anchor="e")

    def save_display(self):
        style = self.display_style.get()
        if style not in ("bars", "gauges", "strip"):
            raise ValueError(tr('Choose a display style.'))
        self.engine.state["DisplayStyle"] = style
        self.app.build_rows()
        self.app.refresh()
        self.app.save()

    def error(self, exc):
        messagebox.showerror("EVE Mining", str(exc), parent=self.window)

    def guarded(self, function):
        try: function()
        except Exception as exc: self.error(exc)

    def make_fleet(self):
        parent = self.fleet
        profile = ttk.Frame(parent)
        profile.pack(fill="x")
        label(profile, tr('Saved profile')).pack(side="left", padx=(0, 12))
        self.saved = ttk.Combobox(profile, state="readonly", values=[p["Name"] for p in self.engine.state["Profiles"]], width=31)
        self.saved.set(self.engine.state["ActiveProfile"])
        self.saved.pack(side="left")
        button(profile, tr('Load into editor'), self.load_profile).pack(side="left", padx=10)
        button(profile, tr('Delete profile'), lambda: self.guarded(self.delete_profile)).pack(side="right")
        name = ttk.Frame(parent)
        name.pack(fill="x", pady=12)
        label(name, tr('Profile name')).pack(side="left", padx=(0, 15))
        self.profile_name = tk.StringVar(value=tr('My fleet'))
        ttk.Entry(name, textvariable=self.profile_name, width=34).pack(side="left")
        self.profile_mode = ttk.Combobox(name, values=("ICE", "ORE"), state="readonly", width=8)
        self.profile_mode.set(self.engine.state["Mode"])
        self.profile_mode.pack(side="left", padx=10)
        label(name, "V2.18 · Python / offline", font=("Segoe UI", 8)).pack(side="right")
        label(parent, tr('Double-click to edit one pilot. Select multiple pilots with Shift or Ctrl/⌘, then click Edit selected.'),
              wraplength=800).pack(fill="x", pady=(0, 8))
        treeframe = ttk.Frame(parent)
        treeframe.pack(fill="both", expand=True)
        columns = ("Use", "Character", "Ship", "Capacity", "Lasers", "Cycle")
        self.pilot_tree = ttk.Treeview(treeframe, columns=columns, show="headings", selectmode="extended", height=10)
        for column, title, width in zip(self.pilot_tree["columns"], ("Use", tr('Character (exact log name)'), tr('Ship class'), tr('Capacity (m³)'), "Lasers", tr('Raw cycle (s)')), (45, 220, 150, 115, 60, 110)):
            self.pilot_tree.heading(column, text=tr(title))
            self.pilot_tree.column(column, width=width, minwidth=40)
        scroll = ttk.Scrollbar(treeframe, orient="vertical", command=self.pilot_tree.yview)
        self.pilot_tree.configure(yscrollcommand=scroll.set)
        self.pilot_tree.pack(side="left", fill="both", expand=True)
        scroll.pack(side="right", fill="y")
        self.pilot_tree.bind("<Double-1>", self.edit_clicked_pilot)
        self.pilot_tree.bind("<Delete>", lambda _: self.remove_pilot())
        actions = ttk.Frame(parent)
        actions.pack(fill="x", pady=10)
        button(actions, tr('Add pilots from logs'), lambda: self.guarded(self.discover)).pack(side="left")
        button(actions, tr('Add pilot'), lambda: self.edit_pilot(new=True)).pack(side="left", padx=6)
        button(actions, tr('Edit selected'), self.edit_pilot).pack(side="left")
        button(actions, tr('Remove'), self.remove_pilot).pack(side="left", padx=6)
        button(actions, tr('Save and activate profile'), lambda: self.guarded(self.save_profile)).pack(side="right")
        folder = ttk.Frame(parent)
        folder.pack(fill="x", pady=4)
        self.folder = tk.StringVar(value=self.engine.state["Folder"])
        ttk.Entry(folder, textvariable=self.folder, state="readonly").pack(side="left", fill="x", expand=True)
        button(folder, tr('Log folder...'), lambda: self.guarded(self.choose_folder)).pack(side="right", padx=(10, 0))
        threshold = ttk.Frame(parent)
        threshold.pack(fill="x", pady=10)
        label(threshold, tr('Notify when cargo reaches')).pack(side="left")
        self.threshold = tk.StringVar(value=f"{self.engine.state['CargoThreshold']:g}")
        self.threshold_spin = ttk.Spinbox(threshold, from_=1, to=100, textvariable=self.threshold, width=5, command=self.save_threshold)
        self.threshold_spin.pack(side="left", padx=10)
        self.threshold_spin.bind("<FocusOut>", lambda _: self.save_threshold())
        self.threshold_spin.bind("<Return>", lambda _: self.save_threshold())
        label(threshold, tr('% · saved automatically, all profiles'), font=("Segoe UI", 8)).pack(side="left")
        self.auto_reset = tk.BooleanVar(value=self.engine.state["AutoCargoReset"])
        ttk.Checkbutton(parent, text=tr('Auto-reset cargo after mining → following in warp → hangar notification'),
                        variable=self.auto_reset, command=lambda: self.guarded(self.save_auto_reset)).pack(anchor="w", pady=(0, 4))
        label(parent, tr('Assumes the entire hold was unloaded. Mining more than 10s after the warp cancels it.'),
              font=("Segoe UI", 8)).pack(anchor="w", pady=(0, 6))
        self.free_label = tk.Label(parent, bg=BG, fg=ACCENT, anchor="w", font=("Segoe UI", 10, "bold"))
        self.free_label.pack(fill="x", pady=(0, 7))
        self.fleet_message = label(parent, tr('Change the profile name before saving to create another setup.'), wraplength=800)
        self.fleet_message.pack(fill="x")
        self.load_profile()
        self.update_free()

    def update_free(self):
        free = self.engine.free_fleet()
        self.free_label.configure(text=f"{tr('Miners free: ')}{format_number(free['Blocks'], ',')}{tr(' ice blocks / ')}{format_number(free['Volume'], ',.0f')}{tr(' m³ · boosters excluded')}" + (tr(' · VERIFY CARGO') if free["Unconfirmed"] else ""))

    def load_profile(self):
        profile = next((p for p in self.engine.state["Profiles"] if p["Name"] == self.saved.get()), None)
        self.pilot_tree.delete(*self.pilot_tree.get_children())
        if profile:
            self.profile_name.set(profile["Name"])
            self.profile_mode.set(profile["Mode"])
            for m in profile["Members"]:
                enabled = tr("Yes") if m.get("Enabled", True) else tr("No")
                self.pilot_tree.insert("", "end", values=(enabled, m["Character"], m["ShipClass"], str(m["Capacity"]), laser_count(m), m.get("CycleSeconds", 0)))

    def discover(self):
        existing = {self.pilot_tree.item(row, "values")[1] for row in self.pilot_tree.get_children()}
        for name in self.engine.find_pilots():
            if name not in existing:
                self.pilot_tree.insert("", "end", values=(tr("Yes"), name, "Custom", "10000", 0, 0))
        self.fleet_message.configure(text=tr("Select one or more pilots to set their ship, hold capacity, lasers and raw cycle."))

    def edit_clicked_pilot(self, event):
        row = self.pilot_tree.identify_row(event.y)
        if row:
            self.pilot_tree.selection_set(row)
            self.edit_pilot()

    def edit_pilot(self, new=False):
        selection = self.pilot_tree.selection()
        if not new and not selection: return
        if not new and len(selection) > 1:
            self.edit_ship_setup(selection)
            return
        values = (tr("Yes"), "", "Custom", "10000", "0", "0") if new else self.pilot_tree.item(selection[0], "values")
        dialog = tk.Toplevel(self.window)
        dialog.title(tr('Pilot configuration'))
        dialog.configure(bg=BG)
        dialog.transient(self.window)
        variables = [tk.StringVar(value=v) for v in values]
        titles = ("Use", tr('Character (exact log name)'), tr('Ship class'), tr('Actual hold capacity (m³)'),
                  tr('Lasers (0 disables hints)'), tr('Raw unboosted cycle (s; 0=auto)'))
        for i, title in enumerate(titles):
            label(dialog, tr(title)).grid(row=i, column=0, sticky="w", padx=12, pady=7)
            choices = (tr("Yes"), tr("No")) if i == 0 else tuple(dict.fromkeys(SHIPS + [values[2]])) if i == 2 else None
            widget = ttk.Combobox(dialog, textvariable=variables[i], values=choices, state="readonly", width=28) if choices else ttk.Entry(dialog, textvariable=variables[i], width=31)
            widget.grid(row=i, column=1, padx=12, pady=7)
        def apply():
            data = [v.get().strip() for v in variables]
            try:
                self.parse_member(data)
                if new: self.pilot_tree.insert("", "end", values=data)
                else: self.pilot_tree.item(selection[0], values=data)
                dialog.destroy()
            except Exception as exc: self.error(exc)
        button(dialog, tr('Apply'), apply).grid(row=len(titles), column=1, sticky="e", padx=12, pady=12)
        dialog.grab_set()

    def edit_ship_setup(self, selection):
        rows = [self.pilot_tree.item(row, "values") for row in selection]
        columns = zip(*(row[2:6] for row in rows))
        common = [column[0] if len(set(column)) == 1 else "" for column in columns]
        dialog = tk.Toplevel(self.window)
        dialog.title(tr('Edit ship setup for {count} pilots').format(count=len(selection)))
        dialog.configure(bg=BG)
        dialog.transient(self.window)
        label(dialog, tr('Blank fields keep each pilot’s existing value.')).grid(
            row=0, column=0, columnspan=2, sticky="w", padx=12, pady=10)
        variables = [tk.StringVar(value=value) for value in common]
        titles = ('Ship class', 'Actual hold capacity (m³)', 'Lasers (0 disables hints)', 'Raw unboosted cycle (s; 0=auto)')
        for i, title in enumerate(titles, 1):
            label(dialog, tr(title)).grid(row=i, column=0, sticky="w", padx=12, pady=7)
            if i == 1:
                choices = tuple(dict.fromkeys(["", *SHIPS, common[0]]))
                widget = ttk.Combobox(dialog, textvariable=variables[i-1], values=choices, state="readonly", width=28)
            else:
                widget = ttk.Entry(dialog, textvariable=variables[i-1], width=31)
            widget.grid(row=i, column=1, padx=12, pady=7)

        def apply():
            changes = [variable.get().strip() for variable in variables]
            updated = [row[:2] + tuple(value or old for value, old in zip(changes, row[2:6]))
                       for row in rows]
            try:
                for values in updated:
                    self.parse_member(values)
            except Exception as exc:
                messagebox.showerror(tr('EVE Mining'), str(exc), parent=dialog)
                return
            for row, values in zip(selection, updated):
                self.pilot_tree.item(row, values=values)
            self.fleet_message.configure(text=tr('Ship setup applied to {count} pilots. Save and activate to keep changes.').format(count=len(selection)))
            dialog.destroy()

        button(dialog, tr('Apply'), apply).grid(row=len(titles)+1, column=1, sticky="e", padx=12, pady=12)
        dialog.bind("<Return>", lambda _: apply())
        dialog.bind("<Escape>", lambda _: dialog.destroy())
        dialog.grab_set()

    @staticmethod
    def parse_member(values):
        enabled, name, ship, capacity, lasers, cycle = values
        capacity, cycle_number = parse_number(capacity), float(parse_number(cycle or "0"))
        count = int(lasers)
        if not name.strip() or not 1000 <= capacity <= 1000000000 or not 0 <= count <= 8 or not 0 <= cycle_number <= 600:
            raise ValueError(tr('Enter a character name, capacity ≥1,000 m³, 0–8 lasers and raw cycle 0–600 seconds.'))
        return dict(Enabled=enabled in ("Yes", tr("Yes")), Character=name.strip(), ShipClass=ship or "Custom",
                    Capacity=capacity, Lasers=count, CycleSeconds=cycle_number)

    def remove_pilot(self):
        for row in self.pilot_tree.selection(): self.pilot_tree.delete(row)

    def save_profile(self):
        name = self.profile_name.get().strip()
        members = [self.parse_member(self.pilot_tree.item(row, "values")) for row in self.pilot_tree.get_children()]
        if not name or not any(m["Enabled"] for m in members) or len({m["Character"].casefold() for m in members}) != len(members):
            raise ValueError(tr('Name the profile, enable at least one pilot and use unique character names.'))
        self.app.poll()
        previous = [m["Character"] for m in self.engine.members]
        self.engine.state["Profiles"] = [p for p in self.engine.state["Profiles"] if p["Name"] != name] + [dict(Name=name, Mode=self.profile_mode.get(), Members=members)]
        self.engine.activate(name, previous)
        self.app.save()
        self.app.sync_profiles()
        self.app.build_rows()
        self.app.refresh()
        self.saved["values"] = [p["Name"] for p in self.engine.state["Profiles"]]
        self.saved.set(name)
        self.fleet_message.configure(text=tr('Profile saved. Confirm cargo after changing ships.'))

    def delete_profile(self):
        name = self.saved.get()
        if not name: return
        self.engine.state["Profiles"] = [p for p in self.engine.state["Profiles"] if p["Name"] != name]
        if self.engine.state["ActiveProfile"] == name:
            self.engine.state["ActiveProfile"] = ""
            if self.engine.state["Profiles"]: self.engine.activate(self.engine.state["Profiles"][0]["Name"])
        self.app.save()
        self.app.sync_profiles()
        self.app.build_rows()
        self.saved["values"] = [p["Name"] for p in self.engine.state["Profiles"]]
        self.saved.set(self.engine.state["ActiveProfile"])
        self.load_profile()

    def choose_folder(self):
        folder = filedialog.askdirectory(parent=self.window, initialdir=self.engine.state["Folder"] or str(self.engine.root), mustexist=True, title=tr('Select local EVE Gamelogs folder'))
        if not folder: return
        path = local_path(folder)
        reject_link(path)
        self.engine.state["Folder"] = str(path)
        self.engine.state["Files"].clear()
        for m in self.engine.members: self.engine.ship(m)["Known"] = False
        self.folder.set(str(path))
        self.app.save()

    def save_auto_reset(self):
        self.engine.set_auto_cargo_reset(self.auto_reset.get())
        self.app.save()
        self.fleet_message.configure(text=tr('Automatic cargo reset enabled.') if self.auto_reset.get() else tr('Automatic cargo reset disabled.'))

    def save_threshold(self):
        try:
            value = parse_number(self.threshold.get())
            if not 1 <= value <= 100: raise ValueError(tr('Cargo threshold must be 1–100%.'))
            self.engine.state["CargoThreshold"] = value
            self.app.save()
            self.fleet_message.configure(text=f"{tr('Cargo threshold saved: ')}{value:g}%.")
        except Exception as exc:
            self.fleet_message.configure(text=str(exc))

    def make_prices(self):
        parent = self.prices
        label(parent, f"{tr('ISK/h uses the BUY prices of reprocessed products at ')}{format_number(MAX_REPROCESS_YIELD, '.2f')}{tr('% yield.')}").pack(fill="x")
        self.price_age_label = label(parent, font=("Segoe UI", 9))
        self.price_age_label.pack(fill="x")
        show_price_age(self.price_age_label, self.engine.state["LastPriceUpdate"])
        controls = ttk.Frame(parent)
        controls.pack(fill="x", pady=10)
        label(controls, tr('Filter')).pack(side="left", padx=(0, 8))
        self.price_filter = tk.StringVar()
        ttk.Entry(controls, textvariable=self.price_filter, width=35).pack(side="left")
        button(controls, tr('Export price item list'), lambda: self.guarded(self.export_items)).pack(side="right")
        self.price_tree = ttk.Treeview(parent, columns=("Material", "Buy", "Source"), show="headings", height=15)
        for col, width in (("Material", 420), ("Buy", 160), ("Source", 160)):
            self.price_tree.heading(col, text=tr('BUY ISK / unit') if col == "Buy" else tr(col))
            self.price_tree.column(col, width=width)
        scrollbar = ttk.Scrollbar(parent, orient="vertical", command=self.price_tree.yview)
        self.price_tree.configure(yscrollcommand=scrollbar.set)
        self.price_tree.pack(fill="both", expand=True)
        scrollbar.place(relx=1, rely=.15, relheight=.63, anchor="ne")
        self.price_tree.bind("<Double-1>", lambda _: self.edit_price())
        self.price_filter.trace_add("write", lambda *_: self.fill_prices())
        self.fill_prices()
        actions = ttk.Frame(parent)
        actions.pack(fill="x", pady=12)
        button(actions, tr('Paste price set...'), self.import_prices).pack(side="left")
        button(actions, tr('Edit selected BUY price'), self.edit_price).pack(side="left", padx=10)
        label(parent, tr('Double-click a material to edit its BUY override.\nPaste Item / Amount / Volume / Buy / Sell from your appraisal. Only BUY is imported.\nExport writes Reprocessing-products.txt in the application folder.'), justify="left", wraplength=800).pack(fill="x")

    def fill_prices(self):
        self.price_tree.delete(*self.price_tree.get_children())
        query = self.price_filter.get().casefold()
        materials = self.engine.items.keys() | self.engine.state["Prices"].keys() | self.engine.reprocessing_products
        for material in sorted(materials):
            display_name = self.app.material_label(material)
            if query not in material.casefold() and query not in display_name.casefold(): continue
            price, stored = self.engine.unit_price(material), self.engine.state["Prices"].get(material)
            self.price_tree.insert("", "end", iid=material, values=(display_name, f"{format_number(price, ',.2f')}" if price is not None else "", tr(stored["Source"]) if stored else ""))

    def export_items(self):
        path = self.engine.root / "Reprocessing-products.txt"
        reject_link(path)
        path.write_text(self.engine.price_list(), encoding="utf-8")
        messagebox.showinfo(tr('Exported'), f"{tr('Saved ')}{path.name}{tr(' in the application folder.')}", parent=self.window)

    def edit_price(self):
        selected = self.price_tree.selection()
        if not selected: return
        material = selected[0]
        old = self.engine.state["Prices"].get(material)
        value = simpledialog.askstring(tr('BUY override - ') + material, tr('ISK per unit (blank removes the override):'), initialvalue=str(old["Value"]) if old else "", parent=self.window)
        if value is None: return
        def apply():
            if not value.strip(): self.engine.state["Prices"].pop(material, None)
            else:
                number = parse_number(value)
                if number < 0: raise ValueError(tr('BUY price must be zero or positive.'))
                self.engine.state["Prices"][material] = dict(Value=number, Source="Custom buy")
            self.app.save()
            self.fill_prices()
            self.engine.rate_refresh = True
            self.app.refresh()
            self.app.refresh_reprocessing_prices()
        self.guarded(apply)

    def import_prices(self):
        dialog = tk.Toplevel(self.window)
        dialog.title(tr('Paste price set'))
        dialog.configure(bg=BG)
        dialog.transient(self.window)
        label(dialog, tr('Item / Amount / Volume / Buy / Sell. Only Buy is imported.')).pack(padx=12, pady=10)
        text = tk.Text(dialog, width=85, height=18, undo=True)
        text.pack(fill="both", expand=True, padx=12)
        def apply():
            try:
                prices = janice(text.get("1.0", "end"), self.engine.canonical_material)
                if not prices: raise ValueError(tr('No valid price rows found.'))
                self.engine.state["Prices"].update(prices)
                self.engine.state["LastPriceUpdate"] = datetime.now(timezone.utc).isoformat()
                self.app.save()
                self.fill_prices()
                self.engine.rate_refresh = True
                self.app.refresh()
                self.app.refresh_reprocessing_prices()
                dialog.destroy()
            except Exception as exc: self.error(exc)
        button(dialog, tr('Import BUY prices'), apply).pack(anchor="e", padx=12, pady=12)
        dialog.grab_set()

    def make_alerts(self):
        parent = self.alerts
        self.cargo_enabled, self.cargo_tone, self.cargo_volume = self.alert_controls(
            parent, "Cargo", tr('Enable cargo sound'), tr('Cargo volume'), tr('Test cargo sound'))
        self.attack_enabled, self.attack_tone, self.attack_volume = self.alert_controls(
            parent, "Attack", tr('Enable attack sound'), tr('Attack volume'), tr('Test attack sound'))
        self.rock_enabled, self.rock_tone, self.rock_volume = self.alert_controls(
            parent, "Rock", tr('Enable rock warning sound'), tr('Rock volume'), tr('Test rock sound'))
        threshold = ttk.Frame(parent)
        threshold.pack(anchor="w", pady=(8, 0))
        label(threshold, tr('Warn at % remaining (next rock)')).pack(side="left")
        self.rock_percent = ttk.Spinbox(threshold, from_=0, to=99, width=5)
        self.rock_percent.set(str(self.engine.state["RockWarningPercent"]))
        self.rock_percent.pack(side="left", padx=8)
        label(parent, tr('Volume: 0–100% for each alert; 0% is silent. Default: 20%.\nSliders also adjust a running preview. Use Save alert settings to keep the levels.\nAdd MP3/WAV files to Sounds, then Refresh sounds. Cargo threshold is on Fleet profiles.\nUnconfirmed cargo does not trigger sounds. Attacks take priority.\nMissing or invalid audio produces an error; no Windows system-tone fallback.'), justify="left", wraplength=800).pack(fill="x", pady=10)
        actions = ttk.Frame(parent)
        actions.pack(fill="x", pady=18)
        button(actions, tr('Save alert settings'), lambda: self.guarded(self.save_alerts)).pack(side="left")
        button(actions, tr('Refresh sounds'), lambda: self.guarded(self.refresh_sounds)).pack(side="left", padx=12)
        button(actions, tr('Stop preview'), self.app.audio.stop).pack(side="left")
        self.alert_message = label(parent, wraplength=800)
        self.alert_message.pack(fill="x")
        self.refresh_sounds()

    def alert_controls(self, parent, key, enabled_label, volume_label, test_label):
        enabled = tk.BooleanVar(value=self.engine.state[key + "Sound"])
        ttk.Checkbutton(parent, text=enabled_label, variable=enabled).pack(anchor="w", pady=(8, 4))
        row = ttk.Frame(parent)
        row.pack(anchor="w")
        tone = ttk.Combobox(row, state="readonly", width=40)
        tone.set(self.engine.state[key + "Tone"])
        tone.pack(side="left")
        volume = tk.IntVar(value=round(self.engine.state[key + "Volume"]))
        kind = key.lower()
        button(row, test_label, lambda: self.test_sound(tone.get(), volume.get(), kind)).pack(side="left", padx=8)
        self.volume_control(parent, volume_label, volume, kind)
        return enabled, tone, volume

    def refresh_sounds(self):
        choices = self.app.audio.choices()
        for combo in (self.cargo_tone, self.attack_tone, self.rock_tone):
            selected = combo.get()
            combo["values"] = choices + ([selected] if selected and selected not in choices else [])
        self.alert_message.configure(text=f"{len(choices)}{tr(' local MP3 / WAV files available.')}")

    def volume_control(self, parent, title, variable, kind):
        row = ttk.Frame(parent)
        row.pack(anchor="w", pady=(8, 0))
        label(row, title, width=14).pack(side="left")
        tk.Scale(row, from_=0, to=100, resolution=1, orient="horizontal", variable=variable,
                 command=lambda _: self.volume_changed(kind, variable.get()), length=260,
                 showvalue=False, bg=BG, fg="white", troughcolor=PANEL,
                 highlightthickness=0, bd=0).pack(side="left")
        percentage = label(row, width=5)
        percentage.pack(side="left", padx=10)
        variable.trace_add("write", lambda *_: percentage.configure(text=f"{variable.get()}%"))
        percentage.configure(text=f"{variable.get()}%")

    def volume_changed(self, kind, value):
        if self.app.audio.kind == kind and self.app.audio.busy:
            self.app.audio.set_volume(value)

    def test_sound(self, name, volume, kind):
        try:
            self.app.audio.play(name, volume, kind)
            self.alert_message.configure(text=f"{tr('Preview: ')}{name}{tr(' at ')}{volume}%")
        except Exception as exc:
            self.alert_message.configure(text=str(exc))

    def save_alerts(self):
        cargo, attack = self.cargo_tone.get(), self.attack_tone.get()
        rock = self.rock_tone.get()
        if self.cargo_enabled.get() and not self.app.audio.resolve(cargo): raise ValueError(tr('Select an available cargo sound.'))
        if self.attack_enabled.get() and not self.app.audio.resolve(attack): raise ValueError(tr('Select an available attack sound.'))
        if self.rock_enabled.get() and not self.app.audio.resolve(rock): raise ValueError(tr('Select an available rock warning sound.'))
        percent = self.rock_percent.get().strip()
        if not percent.isdecimal() or len(percent) > 2:
            raise ValueError(tr('Enter a warning percentage from 0 to 99.'))
        self.engine.state.update(CargoSound=self.cargo_enabled.get(), AttackSound=self.attack_enabled.get(), CargoTone=cargo, AttackTone=attack,
                                 CargoVolume=self.cargo_volume.get(), AttackVolume=self.attack_volume.get(),
                                 RockSound=self.rock_enabled.get(), RockTone=rock, RockVolume=self.rock_volume.get(),
                                 RockWarningPercent=int(percent))
        self.app.attack_var.set(self.attack_enabled.get())
        self.app.save()
        self.alert_message.configure(text=tr('Alert settings saved.'))

    def close(self):
        self.save_threshold()
        self.app.audio.stop()
        self.window.destroy()
        self.app.settings = None


def lock_instance(lock):
    if os.name == "nt":
        import msvcrt
        if os.fstat(lock.fileno()).st_size == 0:
            lock.write(b"0")
            lock.flush()
        lock.seek(0)
        msvcrt.locking(lock.fileno(), msvcrt.LK_NBLCK, 1)
    else:
        import fcntl
        fcntl.flock(lock.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)


def main():
    root_path = local_path(app_root())
    lock_path = root_path / ".python-instance.lock"
    root = tk.Tk()
    root.withdraw()
    lock = None
    try:
        reject_link(lock_path)
        lock = lock_path.open("a+b")
        try: lock_instance(lock)
        except OSError: raise ValueError(tr('Close the other Python EVE Mining instance in this folder.'))
        app = App(root)
        root.deiconify()
        root.mainloop()
    except Exception as exc:
        messagebox.showerror(tr('EVE Mining V2.18 - error'), str(exc) + tr('\nUse a writable local folder. Administrator rights are not required.'), parent=root)
        root.destroy()
    finally:
        if lock is not None:
            lock.close()
        # The small lock file stays local to avoid a race with another instance.


if __name__ == "__main__":
    main()
