"""Only local MP3/WAV files from the adjacent Sounds folder are accepted."""
from pathlib import Path
from i18n import tr
import math
from mining_engine import local_path, reject_link


class LocalAudio:
    def __init__(self, root):
        self.directory = local_path(root) / "Sounds"
        self.mixer = None
        self.kind = None
        self.volume_percent = 20

    def resolve(self, name):
        if not name or Path(name).name != name or any(c in name for c in '\\/:*?"<>|') or Path(name).suffix.lower() not in {".mp3", ".wav"}:
            return None
        reject_link(self.directory)
        path = self.directory / name
        reject_link(path)
        return path if path.is_file() else None

    def choices(self):
        reject_link(self.directory)
        return sorted((p.name for p in self.directory.iterdir() if self.resolve(p.name)), key=str.casefold) if self.directory.is_dir() else []

    def initialize(self):
        if self.mixer is None:
            import pygame.mixer
            pygame.mixer.init()
            self.mixer = pygame.mixer

    def set_volume(self, percent):
        percent = float(percent)
        if not math.isfinite(percent) or not 0 <= percent <= 100:
            raise ValueError(tr('Sound volume must be 0–100%.'))
        self.volume_percent = percent
        if self.mixer is not None:
            self.mixer.music.set_volume(percent / 100)

    def play(self, name, volume_percent=20, kind=None):
        path = self.resolve(name)
        if path is None:
            raise ValueError(tr('Sound missing from Sounds folder: ') + str(name))
        self.initialize()
        self.stop()
        self.mixer.music.load(str(path))
        # SDL can reset music volume when loading a new file: apply it afterwards,
        # before starting playback, so previews and real alerts use the same level.
        self.set_volume(volume_percent)
        self.kind = kind
        self.mixer.music.play()

    @property
    def busy(self):
        return self.mixer is not None and self.mixer.music.get_busy()

    def stop(self):
        self.kind = None
        if self.mixer is not None:
            self.mixer.music.stop()
            self.mixer.music.unload()

    def close(self):
        self.stop()
        if self.mixer is not None:
            self.mixer.quit()
            self.mixer = None
