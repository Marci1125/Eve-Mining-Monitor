"""Offline application strings. Stored profile and market keys stay canonical."""
import json
from pathlib import Path
import sys


_language = "en"
_german = {}


def set_language(language):
    global _language, _german
    if language == "de" and not _german:
        root = Path(getattr(sys, "_MEIPASS", Path(__file__).parent))
        _german = json.loads((root / "assets" / "EVE-Mining-UI-de.json").read_text(encoding="utf-8"))
    _language = language


def language():
    return _language


def tr(text):
    return _german.get(text, text) if _language == "de" else text


def format_number(value, spec):
    result = format(value, spec)
    return result.translate(str.maketrans(",.", ".,")) if _language == "de" else result
