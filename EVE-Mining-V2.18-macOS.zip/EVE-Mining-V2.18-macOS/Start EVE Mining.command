#!/bin/bash
set -euo pipefail
cd -- "$(dirname -- "$0")"

if [[ "$(uname -s)" != Darwin ]]; then
    printf '%s\n' 'This launcher is for macOS.'
    exit 1
fi

python="$(command -v python3.12 || true)"
if [[ -z "$python" ]]; then
    python="/Library/Frameworks/Python.framework/Versions/3.12/bin/python3.12"
fi
if [[ ! -x "$python" ]] || ! "$python" -c 'import tkinter'; then
    printf '%s\n' 'Install Python 3.12 with Tk from https://www.python.org/downloads/macos/ and try again.'
    exit 1
fi

venv="$PWD/.venv"
if [[ ! -x "$venv/bin/python" ]]; then
    "$python" -m venv "$venv"
fi
if ! "$venv/bin/python" -c 'from importlib.metadata import version; raise SystemExit(version("pygame-ce") != "2.5.8")' 2>/dev/null; then
    printf '%s\n' 'Installing the audio dependency for this copy of EVE Mining.'
    "$venv/bin/python" -m pip --isolated --disable-pip-version-check install --index-url https://pypi.org/simple/ --only-binary=:all: --no-deps --require-hashes -r requirements-macos.txt
fi

export PYGAME_HIDE_SUPPORT_PROMPT=1
exec "$venv/bin/python" -B Source/eve_mining.py
