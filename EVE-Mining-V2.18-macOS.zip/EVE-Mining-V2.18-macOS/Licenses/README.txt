Third-party components (unmodified upstream builds)

Python 3.12.16, distributed through Astral python-build-standalone:
https://github.com/astral-sh/python-build-standalone/releases/tag/20261026
https://www.python.org/downloads/source/
License and bundled-library notices: Python-LICENSE.txt

Tk/Tcl 8.6, used by Python's tkinter:
https://www.tcl.tk/software/tcltk/
Notices: Tcl-license.terms.txt and Tk-license.terms.txt

pygame-ce 2.5.8 and its SDL audio dependencies:
https://github.com/pygame-community/pygame-ce/tree/2.5.8
Source archive: https://github.com/pygame-community/pygame-ce/archive/refs/tags/2.5.8.tar.gz
Source distribution: https://pypi.org/project/pygame-ce/2.5.8/#files
https://github.com/libsdl-org/SDL
https://github.com/libsdl-org/SDL_mixer
Notices: pygame-LGPL.txt and pygame-LICENSE.*.txt. These include notices for
the upstream pygame distribution's optional dependencies as well.

PyInstaller 6.22.3 bootloader/packaging:
https://github.com/pyinstaller/pyinstaller/tree/v6.22.3
Notice and bootloader exception: PyInstaller-COPYING.txt

The application source is supplied separately in Source in the personal
development folder. It does not modify Python, Tk/Tcl, pygame/SDL or the
PyInstaller bootloader. The sound files were supplied by the tool's user.
