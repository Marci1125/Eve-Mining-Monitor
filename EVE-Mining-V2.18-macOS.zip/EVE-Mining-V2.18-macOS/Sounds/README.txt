Add local MP3 or WAV files to this folder. In Options > Alerts, select Refresh sounds.
Choose and test the cargo, attack and rock sounds, then save your alert settings.
The default rock warning is The Asteroid is about to.wav and lasts three seconds.
