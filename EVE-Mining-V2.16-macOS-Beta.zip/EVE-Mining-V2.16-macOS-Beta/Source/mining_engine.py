"""Local log reader and mining accounting. No GUI, network client or EVE control."""
from __future__ import annotations

import copy
import ctypes
import html
import json
import math
import os
from pathlib import Path
from i18n import tr
import re
import statistics
import sys
import time
from datetime import datetime, timezone
from decimal import Decimal as D

VERSION = "2.16-python"
CARGO_DEFAULT = "Cargo - Soft spaceship.mp3"
ATTACK_DEFAULT = "Attack - Digital alarm.wav"
MAX_REPROCESS_YIELD = D("90.63")
BOOST_ESTIMATE_HOLD_SECONDS = 120
MIN_TIME = -62135596800.0
BOOSTERS = {"Porpoise", "Orca", "Rorqual"}
SHIPS = ["Custom", "Venture", "Prospect", "Endurance", "Procurer", "Retriever", "Covetor", "Skiff", "Mackinaw", "Hulk", "Porpoise", "Orca", "Rorqual"]
DATE_KEYS = {"StartedUtc", "LastMiningUtc", "LastResumeUtc", "CriticalUntil", "ActivitySince", "Time", "Start", "End"}


def bundle_root():
    return Path(getattr(sys, "_MEIPASS", Path(__file__).parent)) / "assets"


def price_age(as_of, now=None):
    try:
        updated = datetime.fromisoformat(as_of)
    except (TypeError, ValueError):
        return tr("Unknown"), False
    if updated.tzinfo is None:
        updated = updated.replace(tzinfo=timezone.utc)
    now = time.time() if now is None else now
    outdated = now - updated.timestamp() > 7 * 24 * 60 * 60
    return updated.strftime("%d.%m.%Y"), outdated


def app_root():
    return Path(sys.executable).parent if getattr(sys, "frozen", False) else Path(__file__).resolve().parent.parent


def local_path(value):
    text = str(value)
    if not text or text.startswith(("\\\\", "//")) or "://" in text:
        raise ValueError(tr('Choose a local folder. Network paths are not supported.'))
    path = Path(text).absolute()
    if os.name == "nt" and ctypes.windll.kernel32.GetDriveTypeW(str(path.anchor)) == 4:
        raise ValueError(tr('Mapped network drives are not supported.'))
    return path


def reject_link(path):
    path = Path(path)
    # Cloud files (including OneDrive) are not necessarily symbolic links.
    if path.is_symlink() or (hasattr(path, "is_junction") and path.is_junction()):
        raise ValueError(tr('Linked paths are not supported: ') + path.name)


def decode_dates(value):
    if isinstance(value, dict):
        return {k: (date_number(v) if k in DATE_KEYS and v is not None else decode_dates(v)) for k, v in value.items()}
    if isinstance(value, list):
        return [decode_dates(v) for v in value]
    return value


def date_number(value):
    if isinstance(value, (float, int, D)):
        return float(value)
    match = re.match(r"^/Date\((-?\d+)(?:[+-]\d+)?\)/$", value or "")
    if match:
        return int(match[1]) / 1000
    return datetime.fromisoformat(value.replace("Z", "+00:00")).timestamp()


def encode_dates(value):
    if isinstance(value, dict):
        return {k: (f"/Date({round(v * 1000)})/" if k in DATE_KEYS and v is not None else encode_dates(v)) for k, v in value.items()}
    if isinstance(value, list):
        return [encode_dates(v) for v in value]
    return value


def load_json(path):
    return decode_dates(json.loads(Path(path).read_text(encoding="utf-8-sig"), parse_float=D))


def new_session(now):
    return dict(StartedUtc=now, LastMiningUtc=MIN_TIME, LastResumeUtc=MIN_TIME, Mined={}, Events=[], Pauses=[])


def new_ship(member):
    return dict(Volume=D(0), Units=D(0), IceBlocks=D(0), UnassignedVolume=D(0), Capacity=member["Capacity"],
                ShipClass=member["ShipClass"], Last="-", Unknown="", Known=False, CriticalUntil=MIN_TIME,
                ActivitySince=MIN_TIME, Contents={})


def laser_count(member):
    if member["ShipClass"] in BOOSTERS:
        return 0
    if member.get("Lasers", -1) >= 0:
        return int(member["Lasers"])
    if member["ShipClass"] == "Endurance":
        return 1
    return 2 if member["ShipClass"] in SHIPS[1:3] + SHIPS[4:10] else 0


def log_time(text):
    return datetime.strptime(text, "%Y.%m.%d %H:%M:%S").replace(tzinfo=timezone.utc).timestamp()


def plain(line):
    return html.unescape(re.sub(r"<[^>]*>", "", line))


MINING = re.compile(r"^\[\s*(\d{4}\.\d{2}\.\d{2} \d{2}:\d{2}:\d{2})\s*\]\s*\(mining\).*?You mined (an additional )?([\d,]+) units? of (.+?)(?: with a lost residue of [\d,]+ units?)?\s*$")
COMPRESS = re.compile(r"^\[\s*(\d{4}\.\d{2}\.\d{2} \d{2}:\d{2}:\d{2})\s*\]\s*\(notify\)\s*Successfully compressed (.+?) into ([\d,]+) (.+?)\.\s*$")
DE_MINING = re.compile(r"^\[\s*(\d{4}\.\d{2}\.\d{2} \d{2}:\d{2}:\d{2})\s*\]\s*\(mining\)\s*(?:Kritischer Bergbauerfolg!\s*)?Sie haben (zusätzliche\s+)?([\d.,\u00a0\u202f]+)\s+Einheiten?\s+(?:von\s+)?(.+?)(?:\s+mit\s+[\d.,\u00a0\u202f]+\s+Einheiten? an Rückständen)?\s+abgebaut\.?\s*$")
DE_COMPRESS = re.compile(r"^\[\s*(\d{4}\.\d{2}\.\d{2} \d{2}:\d{2}:\d{2})\s*\]\s*\(notify\)\s*Erfolgreich (.+?) zu ([\d.,\u00a0\u202f]+) (.+?) komprimiert\.\s*$")


def log_quantity(text):
    return D("".join(character for character in text if character.isdecimal()) or "0")


def parse_mining(line):
    text = plain(line)
    match = MINING.match(text) or DE_MINING.match(text)
    if not match:
        return None
    quantity = log_quantity(match[3])
    return dict(Time=log_time(match[1]), Material=match[4].strip(), Quantity=quantity, Critical=bool(match[2]), Name="") if quantity > 0 else None


def parse_compression(line):
    text = plain(line)
    match = COMPRESS.match(text) or DE_COMPRESS.match(text)
    if match and (quantity := log_quantity(match[3])) > 0:
        return dict(Time=log_time(match[1]), Raw=match[2], Quantity=quantity, Compressed=match[4])
    return None


def parse_unload_notice(line):
    match = re.match(r"^\[\s*(\d{4}\.\d{2}\.\d{2} \d{2}:\d{2}:\d{2})\s*\]\s*\(notify\)\s*(.+?)\s*$", plain(line))
    if not match:
        return None
    if re.fullmatch(r"(?:Following .+ in warp|Folge .+ in den Warp)\.?", match[2]):
        return dict(Kind="warp", Time=log_time(match[1]))
    moved = re.fullmatch(r"([\d,]+) items? (?:was|were) moved to your hangar in (.+)", match[2])
    if not moved:
        moved = re.fullmatch(r"([\d.,\u00a0\u202f]+) (?:items?|Gegenstände?) wurden in Ihren Hangar in der Struktur (.+)", match[2])
    if moved and log_quantity(moved[1]) > 0:
        return dict(Kind="hangar", Time=log_time(match[1]))
    return None


def parse_attack(line):
    match = re.match(r"^\[\s*(\d{4}\.\d{2}\.\d{2} \d{2}:\d{2}:\d{2})\s*\]\s*\(combat\)\s*(.+)$", plain(line))
    if not match:
        return None
    hit = re.match(r"^[\d,.]+\s+(?:from|von)\s+(.+?)(?:\s+[-–]\s+.*)?$", match[2])
    if not hit:
        hit = re.match(r"^(.+?) (?:misses you completely|verfehlt Sie völlig|hat Sie völlig verfehlt)(?:[.\s].*)?$", match[2])
    return dict(Time=log_time(match[1]), Attacker=hit[1]) if hit else None


def parse_number(text):
    text = text.strip()
    if "," in text and "." in text:
        text = text.replace(".", "").replace(",", ".") if text.rfind(",") > text.rfind(".") else text.replace(",", "")
    elif re.search(r",\d{2}$", text):
        text = text.replace(",", ".")
    else:
        text = text.replace(",", "")
        if re.match(r"^\d{1,3}(\.\d{3})+$", text):
            text = text.replace(".", "")
    result = D(text)
    if not result.is_finite():
        raise ValueError(tr('Enter a finite number.'))
    return result


def janice(text, canonical_material=None):
    totals = {}
    pattern = r"^\s*(.+?)\s+([\d,.]+)\s+([\d,.]+)(?:\s*m[3³])?\s+([\d,.]+)(?:\s*ISK)?\s+([\d,.]+)(?:\s*ISK)?\s*$"
    for line in text.splitlines():
        match = re.match(pattern, line)
        if not match:
            continue
        quantity, buy = parse_number(match[2]), parse_number(match[4])
        if quantity <= 0 or buy < 0:
            continue
        name = match[1].strip()
        if canonical_material is not None:
            name = canonical_material(name)
        old_q, old_buy = totals.get(name, (D(0), D(0)))
        totals[name] = (old_q + quantity, old_buy + buy)
    return {name: dict(Value=buy / quantity, Source="Janice buy") for name, (quantity, buy) in totals.items()}


class Engine:
    def __init__(self, root=None, data_directory=None, now=None):
        self.root = local_path(root or app_root())
        self.data = local_path(data_directory or self.root)
        self.data.mkdir(parents=True, exist_ok=True)
        self.path = self.data / "EVE-Mining.python-state.json"
        reject_link(self.path)
        self.started = time.time() if now is None else now
        self.notice = tr('Ready. Select your local Gamelogs folder in Fleet / prices.')
        self.items = {i["Name"]: i for i in load_json(bundle_root() / "EVE-Mining-Volumes.json")["Items"]}
        self.reprocessing_recipes = load_json(bundle_root() / "EVE-Mining-Reprocessing.json")
        self.reprocessing_products = {product for recipe in self.reprocessing_recipes.values()
                                      for product in recipe["Products"]}
        self.reprocessing_metadata = load_json(bundle_root() / "EVE-Mining-Reprocessing-Metadata.json")
        self.german_materials = load_json(bundle_root() / "EVE-Mining-Materials-de.json")
        self.material_aliases = {
            translated.casefold(): canonical for canonical, translated in self.german_materials.items()
            if translated not in self.items and translated not in self.reprocessing_products
        }
        self.state = dict(AppVersion=VERSION, Mode="ICE", Folder="", ActiveProfile="", DefaultPricesApplied="",
                          Profiles=[], Ships={}, Files={}, Session=new_session(self.started), Prices={}, AttackSound=True,
                          CargoSound=True, CargoThreshold=95, CargoTone=CARGO_DEFAULT, AttackTone=ATTACK_DEFAULT,
                          CargoVolume=20, AttackVolume=20, AutoCargoReset=False, DisplayStyle="bars", Language="en",
                          Window=dict(Compact=True, TopMost=False, Left=-1, Top=-1))
        if self.path.exists():
            self.state.update(load_json(self.path))
        elif (self.data / "EVE-Mining.native-state.json").exists():
            reject_link(self.data / "EVE-Mining.native-state.json")
            self.state.update(load_json(self.data / "EVE-Mining.native-state.json"))
            self.notice = tr('Imported existing profiles, cargo, session and prices. Original file retained.')
        self.validate()
        defaults = load_json(bundle_root() / "EVE-Mining-Default-Prices.json")
        default_prices = {key: dict(Value=value["Price"], Source=value["Source"])
                          for key, value in defaults["Prices"].items()}
        if not self.state.get("DefaultPricesApplied"):
            for key, value in default_prices.items():
                self.state["Prices"].setdefault(key, value)
            self.state["DefaultPricesApplied"] = defaults["Version"]
        if "LastPriceUpdate" not in self.state:
            self.state["LastPriceUpdate"] = (
                defaults["AsOfUtc"] if self.state["Prices"] == default_prices else None
            )
        self.activities, self.references, self.attacks = {}, {}, {}
        self.cargo_above = {m["Character"]: self.ship(m)["Volume"] >= self.ship(m)["Capacity"] * D(self.state["CargoThreshold"]) / 100 for m in self.members}
        self.last_tone = MIN_TIME
        self.sound_requested = self.cargo_requested = False
        self.cargo_alert = ""
        self.cargo_highlights = {}
        self.mining_yields = {}
        self.unload_chains = {}
        self.unload_files = {}
        self.unload_highlights = {}
        self.rate_refresh = True
        self.inferred_booster = None
        self.last_boost_estimate = None
        self.read_file = self.read_shared

    def validate(self):
        state = self.state
        if state.get("Language") not in ("en", "de"):
            state["Language"] = "en"
        if state.get("DisplayStyle") not in ("bars", "gauges", "strip"):
            state["DisplayStyle"] = "bars"
        for key, kind in (("Profiles", list), ("Ships", dict), ("Files", dict), ("Session", dict), ("Prices", dict)):
            if not isinstance(state.get(key), kind):
                raise ValueError(tr('Incomplete saved state: ') + key)
        threshold = D(str(state.get("CargoThreshold", 95)))
        state["CargoThreshold"] = threshold if threshold.is_finite() and 1 <= threshold <= 100 else D(95)
        for key in ("CargoVolume", "AttackVolume"):
            try:
                volume = float(state.get(key, 20))
            except (TypeError, ValueError):
                volume = 20
            state[key] = volume if math.isfinite(volume) and 0 <= volume <= 100 else 20
        if state.get("Folder"):
            state["Folder"] = str(local_path(state["Folder"]))
        for profile in state["Profiles"]:
            for m in profile["Members"]:
                m["Capacity"] = D(str(m["Capacity"]))
                if not m["Capacity"].is_finite() or not 1000 <= m["Capacity"] <= 1000000000 or not m["Character"].strip():
                    raise ValueError(tr('Invalid saved fleet member.'))
        for ship in state["Ships"].values():
            for key in ("Volume", "Units", "IceBlocks", "UnassignedVolume", "Capacity"):
                ship[key] = D(str(ship.get(key, 10000 if key == "Capacity" else 0)))
            ship.setdefault("Contents", {})
            ship.setdefault("ActivitySince", MIN_TIME)
        if state.get("AppVersion") not in ("2.0", "2.0-python", "2.1-python", "2.2-python", "2.3-python", "2.4-python", "2.5-python", "2.6-python", "2.7-python", "2.8-python", "2.9-python", "2.10-python", "2.11-python", "2.12-python", "2.12.1-python", "2.13-python", "2.13.1-python", "2.13.2-python", "2.14-python", "2.14.1-python", "2.14.2-python", "2.15-python", "2.15.1-python", "2.15.2-python", VERSION):
            state["CargoTone"], state["AttackTone"] = CARGO_DEFAULT, ATTACK_DEFAULT
        for key in ("CargoTone", "AttackTone"):
            old_name = state.get(key, "")
            if old_name in ("Attack - Digital alarm.mp3", "Attack - Dino alarm.mp3"):
                replacement = old_name[:-4] + ".wav"
                if (self.root / "Sounds" / replacement).is_file():
                    state[key] = replacement
        state["AppVersion"] = VERSION

    @property
    def current(self):
        return next((p for p in self.state["Profiles"] if p["Name"] == self.state["ActiveProfile"]), None)

    @property
    def members(self):
        return [m for m in self.current["Members"] if m.get("Enabled", True)] if self.current else []

    def ship(self, member):
        return self.state["Ships"].setdefault(member["Character"], new_ship(member))

    def save(self):
        self.state["AppVersion"] = VERSION
        temp, backup = self.path.with_name(self.path.name + ".tmp"), self.path.with_name(self.path.name + ".bak")
        for path in (self.path, temp, backup):
            reject_link(path)
        text = json.dumps(encode_dates(self.state), ensure_ascii=False, allow_nan=False, default=lambda x: float(x) if isinstance(x, D) else str(x))
        with temp.open("w", encoding="utf-8", newline="\n") as stream:
            stream.write(text)
            stream.flush()
            os.fsync(stream.fileno())
        if self.path.exists():
            backup_temp = backup.with_suffix(backup.suffix + ".tmp")
            reject_link(backup_temp)
            backup_temp.write_bytes(self.path.read_bytes())
            os.replace(backup_temp, backup)
        os.replace(temp, self.path)

    def logs_available(self):
        if not self.state.get("Folder"):
            return False
        folder = local_path(self.state["Folder"])
        reject_link(folder)
        return folder.is_dir()

    def latest_files(self):
        if not self.logs_available():
            raise ValueError(tr('Select your local EVE Gamelogs folder in Fleet / prices.'))
        groups = {}
        for path in Path(self.state["Folder"]).glob("*.txt"):
            if not re.match(r"^\d{8}_\d{6}_\d+\.txt$", path.name):
                continue
            reject_link(path)
            key = path.stem.rsplit("_", 1)[1]
            if key not in groups or path.name > groups[key].name:
                groups[key] = path
        return list(groups.values())

    @staticmethod
    def read_shared(path):
        # Binary read-only open; EVE and cloud sync may continue updating the file.
        raw = Path(path).read_bytes()
        if raw.startswith((b"\xff\xfe", b"\xfe\xff")):
            return raw.decode("utf-16", errors="replace")
        return raw.decode("utf-8-sig", errors="replace")

    @staticmethod
    def listener(text):
        match = re.search(r"^\s*(?:Listener|Zuhörer|Empfänger):[ \t]*(.+?)\r?$", text, re.M)
        return match[1].strip() if match else ""

    def canonical_material(self, name):
        return self.material_aliases.get(name.casefold(), name)

    def find_pilots(self):
        return sorted({self.listener(self.read_file(p)) for p in self.latest_files()} - {""})

    def activate(self, name, previous=None):
        self.unload_chains.clear()
        self.inferred_booster = None
        self.last_boost_estimate = None
        previous = {m["Character"] for m in self.members} if previous is None else set(previous)
        self.state["ActiveProfile"] = name
        if self.current is None:
            raise ValueError(tr('Unknown profile.'))
        self.state["Mode"] = self.current["Mode"]
        fresh = set()
        for m in self.members:
            ship = self.ship(m)
            if m["Character"] not in previous or ship["Capacity"] != m["Capacity"] or ship["ShipClass"] != m["ShipClass"]:
                ship["Known"] = False
            if m["Character"] not in previous:
                fresh.add(m["Character"])
            ship.update(Capacity=m["Capacity"], ShipClass=m["ShipClass"])
            self.activities[m["Character"]] = dict(Times=[], Since=time.time(), Ratio=0)
        self.references.clear()
        if self.logs_available():
            snapshots = [(str(p), self.read_file(p)) for p in self.latest_files()]
            for path, text in snapshots:
                name = self.listener(text)
                if name in fresh:
                    self.state["Files"][path] = dict(Name=name, Count=len(text.split("\n")) - 1)

    def reset(self, member, now=None):
        self.unload_chains.pop(member["Character"], None)
        self.unload_highlights.pop(member["Character"], None)
        self.ship(member).update(Volume=D(0), Units=D(0), IceBlocks=D(0), UnassignedVolume=D(0), Contents={}, Known=True,
                                 Unknown="", CriticalUntil=MIN_TIME, ActivitySince=time.time() if now is None else now)
        self.cargo_above[member["Character"]] = False
        self.cargo_highlights.pop(member["Character"], None)

    def set_auto_cargo_reset(self, enabled):
        self.state["AutoCargoReset"] = bool(enabled)
        self.unload_chains.clear()

    def track_unload(self, member, kind, when):
        name = member["Character"]
        if not self.state["AutoCargoReset"]:
            self.unload_chains.pop(name, None)
            return
        if kind == "mining":
            # The fleet warp notification precedes actual departure. Final
            # laser/critical yields can arrive while the ship is aligning.
            chain = self.unload_chains.get(name)
            if chain and chain["Stage"] == "warp" and 0 <= when - chain["Time"] <= 10:
                return
            # Later mining invalidates the warp and starts a fresh chain.
            self.unload_chains[name] = dict(Stage="mined", Time=when)
            self.unload_highlights.pop(name, None)
            return
        chain = self.unload_chains.get(name)
        if chain is None or when < chain["Time"]:
            return
        if kind == "warp":
            self.unload_chains[name] = dict(Stage="warp", Time=when)
        elif kind == "hangar" and chain["Stage"] == "warp":
            self.reset(member, when)
            self.mining_yields.pop(name, None)
            self.unload_highlights[name] = time.monotonic() + 5
            self.notice = f"{name} — Auto-reset: unloaded"
            return True

    def add_cargo(self, ship, event):
        item = self.items.get(event["Material"])
        if item is None:
            ship.update(Known=False, Unknown=event["Material"])
            return False
        quantity = event["Quantity"]
        ship["Volume"] += quantity * item["Volume"]
        ship["Units"] += quantity
        contents = ship["Contents"]
        contents[event["Material"]] = contents.get(event["Material"], D(0)) + quantity
        if item["Mode"] == "ICE" and item["Volume"] == 1000:
            ship["IceBlocks"] += quantity
        ship["Last"] = datetime.fromtimestamp(event["Time"], timezone.utc).strftime("%H:%M:%S UTC - ") + event["Material"]
        if event["Critical"]:
            ship["CriticalUntil"] = max(ship["CriticalUntil"], event["Time"] + 30)
        return True

    def compressed_hold_volume(self, ship):
        volume = sum((quantity * self.items[name]["Volume"]
                      for name, quantity in ship["Contents"].items()
                      if name.startswith(("Compressed ", "Batch Compressed ", "Ancient Compressed "))
                      and name in self.items and quantity > 0), D(0))
        return max(D(0), min(ship["Volume"], volume))

    def compress(self, ship, event):
        raw, packed = self.items.get(event["Raw"]), self.items.get(event["Compressed"])
        if event["Compressed"] != "Compressed " + event["Raw"] or raw is None or packed is None:
            ship.update(Known=False, Unknown=tr('Unsupported compression: ') + event["Raw"])
            return False
        quantity = event["Quantity"]
        tracked = ship["Contents"].get(event["Raw"], D(0))
        used = min(tracked, quantity)
        unknown = (quantity - used) * raw["Volume"]
        if packed["Volume"] >= raw["Volume"] or unknown > ship["UnassignedVolume"] or quantity * raw["Volume"] > ship["Volume"]:
            ship.update(Known=False, Unknown=tr('Compression exceeds tracked cargo: ') + event["Raw"])
            return False
        ship["Contents"][event["Raw"]] = tracked - used
        ship["UnassignedVolume"] -= unknown
        ship["Contents"][event["Compressed"]] = ship["Contents"].get(event["Compressed"], D(0)) + quantity
        ship["Volume"] -= quantity * (raw["Volume"] - packed["Volume"])
        if raw["Mode"] == "ICE":
            ship["IceBlocks"] = max(D(0), ship["IceBlocks"] - quantity)
        ship["Last"] = f"Compressed {quantity:,.0f} {event['Raw']}"
        return True

    def poll(self, now=None):
        now = time.time() if now is None else now
        self.sound_requested = self.cargo_requested = False
        snapshots = [(str(path), self.read_file(path)) for path in self.latest_files()]
        active = {m["Character"]: m for m in self.members}
        pending = []
        unloaded = []
        for path, text in snapshots:
            name = self.listener(text)
            if name not in active:
                continue
            if self.unload_files.get(name) != path:
                self.unload_chains.pop(name, None)
                self.unload_files[name] = path
            lines, ship = text.split("\n")[:-1], self.ship(active[name])
            cursor = self.state["Files"].get(path)
            if cursor is None:
                self.unload_chains.pop(name, None)
                self.state["Files"][path] = dict(Name=name, Count=len(lines))
                ship["Known"] = False
                continue
            if len(lines) < cursor["Count"]:
                self.unload_chains.pop(name, None)
                cursor["Count"] = len(lines)
                ship["Known"] = False
                continue
            for line in lines[int(cursor["Count"]):]:
                unload = parse_unload_notice(line)
                if unload:
                    if self.track_unload(active[name], unload["Kind"], unload["Time"]):
                        unloaded.append(name)
                attack = parse_attack(line)
                if attack and -5 <= now - attack["Time"] <= 15:
                    self.attacks[name] = attack
                    if self.state["AttackSound"] and now - self.last_tone >= 30:
                        self.sound_requested, self.last_tone = True, now
                event = parse_mining(line)
                if event:
                    event["Material"] = self.canonical_material(event["Material"])
                    event["Name"] = name
                    self.track_unload(active[name], "mining", event["Time"])
                    self.mining_yields.setdefault(name, []).append((event["Quantity"], time.monotonic() + 5))
                    self.add_cargo(ship, event)
                    pending.append(event)
                    ignored_yield = active[name].get("IgnoreCycleYieldM3", 0)
                    item = self.items.get(event["Material"])
                    is_cycle_sample = not ignored_yield or (
                        item is not None and event["Quantity"] * item["Volume"] > ignored_yield
                    )
                    if not event["Critical"] and is_cycle_sample:
                        activity = self.activity(name)
                        activity["Times"].append(event["Time"])
                        activity["Times"] = [t for t in activity["Times"] if t > now - 1200]
                else:
                    compression = parse_compression(line)
                    if compression:
                        compression["Raw"] = self.canonical_material(compression["Raw"])
                        compression["Compressed"] = self.canonical_material(compression["Compressed"])
                        self.compress(ship, compression)
            cursor["Count"] = len(lines)
        for event in sorted(pending, key=lambda e: e["Time"]):
            self.add_income(event)
        self.auto_pause(now)
        self.state["Session"]["Events"] = [e for e in self.state["Session"]["Events"] if e["Time"] > now - 600]
        self.check_cargo_alerts()
        if unloaded:
            self.notice = tr('Auto-reset: unloaded — ') + ", ".join(dict.fromkeys(unloaded))

    def recent_yield(self, name, now=None):
        now = time.monotonic() if now is None else now
        recent = [(quantity, until) for quantity, until in self.mining_yields.get(name, []) if until > now]
        if recent:
            self.mining_yields[name] = recent
        else:
            self.mining_yields.pop(name, None)
        return sum((quantity for quantity, _ in recent), D(0))

    def check_cargo_alerts(self):
        now = time.monotonic()
        self.cargo_highlights = {name: until for name, until in self.cargo_highlights.items() if until > now}
        self.cargo_requested = False
        for m in self.members:
            ship, name = self.ship(m), m["Character"]
            above = self.at_cargo_limit(ship)
            if not above:
                self.cargo_highlights.pop(name, None)
            if above and not self.cargo_above.get(name, False) and ship["Known"] and not ship["Unknown"]:
                self.cargo_alert = f"{name} cargo reached {self.state['CargoThreshold']:g}%"
                self.cargo_requested = bool(self.state["CargoSound"])
                self.cargo_highlights[name] = now + 5
            self.cargo_above[name] = above

    @property
    def paused(self):
        return any(p["End"] is None for p in self.state["Session"]["Pauses"])

    def pause(self, paused, now):
        if paused and not self.paused:
            self.state["Session"]["Pauses"].append(dict(Start=now, End=None))
        elif not paused:
            for pause in self.state["Session"]["Pauses"]:
                if pause["End"] is None:
                    pause["End"] = now
            self.state["Session"]["LastResumeUtc"] = now
        self.rate_refresh = True

    def auto_pause(self, now):
        session = self.state["Session"]
        last = max(session["StartedUtc"], session["LastMiningUtc"], session["LastResumeUtc"])
        if not self.paused and now - last >= 300:
            self.pause(True, last + 300)
            self.notice = tr('Auto-paused: no mining yield for 5 minutes.')

    def add_income(self, event):
        self.auto_pause(event["Time"])
        if self.paused and any(p["End"] is None and event["Time"] >= p["Start"] for p in self.state["Session"]["Pauses"]):
            self.pause(False, event["Time"])
            self.notice = tr('Session resumed automatically.')
            for activity in self.activities.values():
                activity["Since"] = event["Time"]
        if any(event["Time"] >= p["Start"] and (p["End"] is None or event["Time"] < p["End"]) for p in self.state["Session"]["Pauses"]):
            return
        quantities = self.state["Session"]["Mined"].setdefault(event["Name"], {})
        quantities[event["Material"]] = quantities.get(event["Material"], D(0)) + event["Quantity"]
        self.state["Session"]["Events"].append(event)
        self.state["Session"]["LastMiningUtc"] = max(self.state["Session"]["LastMiningUtc"], event["Time"])

    def active_seconds(self, now):
        session = self.state["Session"]
        seconds = now - session["StartedUtc"]
        for pause in session["Pauses"]:
            end = min(pause["End"], now) if pause["End"] is not None else now
            seconds -= max(0, end - max(pause["Start"], session["StartedUtc"]))
        return max(1, seconds)

    def session_mined_quantities(self, name=None):
        mined = {}
        for pilot, quantities in self.state["Session"]["Mined"].items():
            if name is not None and name != pilot:
                continue
            for material, quantity in quantities.items():
                mined[material] = mined.get(material, D(0)) + quantity
        return mined

    def reprocess_session(self, yield_percent):
        if not yield_percent.is_finite() or not 0 < yield_percent <= 100:
            raise ValueError(tr('Enter a yield above 0 and up to 100%.'))
        return self.reprocess_quantities(self.session_mined_quantities(), yield_percent)

    def reprocess_quantities(self, mined, yield_percent):
        products, leftovers, unsupported = {}, {}, {}
        for material, quantity in sorted(mined.items()):
            if quantity <= 0:
                continue
            recipe = self.reprocessing_recipes.get(material)
            if recipe is None:
                unsupported[material] = quantity
                continue
            batches, remaining = divmod(quantity, recipe["Batch"])
            if remaining:
                leftovers[material] = remaining
            for product, units in recipe["Products"].items():
                recovered = int(batches * units * yield_percent / 100)
                if recovered:
                    products[product] = products.get(product, 0) + recovered
        return products, leftovers, unsupported

    def unit_price(self, material):
        target = material if material.startswith("Compressed ") else "Compressed " + material
        for key in (target, material):
            price = self.state["Prices"].get(key)
            if price and price["Source"] in ("Janice buy", "Custom buy"):
                return D(price["Value"])
        return None

    def reprocessing_quote(self, material, mined_material=False):
        quotes = self.reprocessing_metadata["Quotes"]
        quote = quotes.get(material)
        if quote is None and mined_material:
            quote = quotes.get("Compressed " + material)
        buy = self.unit_price(material)
        if quote is None:
            return buy, None
        return (D(str(quote[0])) if buy is None else buy), D(str(quote[1]))

    def reprocessed_value(self, products):
        value = missing = D(0)
        for material, quantity in products.items():
            buy, _ = self.reprocessing_quote(material)
            if buy is None:
                missing += quantity
            else:
                value += quantity * buy
        return value, missing

    def income(self, now, name=None):
        mined = self.session_mined_quantities(name)
        products, _, no_recipe = self.reprocess_quantities(mined, MAX_REPROCESS_YIELD)
        value, missing = self.reprocessed_value(products)
        unsupported = sum(no_recipe.values(), D(0))
        seconds = self.active_seconds(now)
        return dict(Value=value, Missing=missing, Unsupported=unsupported, Units=sum(mined.values(), D(0)),
                    Seconds=seconds, Rate=float(value) * 3600 / seconds)

    def start_session(self, now):
        self.state["Session"] = new_session(now)
        self.rate_refresh = True
        self.notice = tr('New session. Cargo totals retained.')

    def red(self, ship):
        return ship["Volume"] >= ship["Capacity"] * D(".95") or (self.state["Mode"] == "ICE" and ship["Capacity"] - ship["Volume"] < 1000)

    def hold_ratio(self, ship):
        ratio = ship["Volume"] / ship["Capacity"]
        if self.state["Mode"] == "ICE" and ship["Capacity"] - ship["Volume"] < 1000:
            return 1.0
        return float(max(D(0), min(D(1), ratio)))

    def fleet_capacity_color(self, fleet):
        if fleet["Unconfirmed"]:
            return "orange"
        if self.state["Mode"] == "ICE":
            free, total = fleet["Blocks"], fleet["TotalBlocks"]
        else:
            free, total = fleet["Volume"], fleet["Capacity"]
        remaining = float(free / total) if total else 1
        if remaining <= .05: return "red"
        if remaining <= .10: return "orange"
        if remaining <= .25: return "yellow"
        return "green"

    def at_cargo_limit(self, ship):
        return ship["Volume"] >= ship["Capacity"] * D(self.state["CargoThreshold"]) / 100

    def color(self, ship, now):
        if self.red(ship):
            return "red"
        if self.at_cargo_limit(ship):
            return "orange"
        return "yellow" if ship["CriticalUntil"] > now else "green"

    def boost_label(self, now):
        reductions = []
        latest_sample = MIN_TIME
        if self.paused:
            self.inferred_booster = None
            self.last_boost_estimate = None
            return tr('Boost idle')
        for member in self.members:
            raw = float(member.get("CycleSeconds", 0))
            lasers = laser_count(member)
            if raw <= 0 or lasers <= 0:
                continue
            times = sorted(t for t in self.activity(member["Character"])["Times"] if t <= now)
            if len(times) < lasers + 6 or now - times[-1] > max(30, raw * 1.5):
                continue
            recent = times[-(lasers + 6):]
            intervals = [recent[i] - recent[i - lasers] for i in range(lasers, len(recent))]
            cycle = statistics.median(intervals)
            tolerance = max(3, cycle * .12)
            consistent = sum(abs(value - cycle) <= tolerance for value in intervals)
            if cycle > 0 and consistent >= len(intervals) - 1:
                reductions.append(1 - cycle / raw)
                latest_sample = max(latest_sample, times[-1])
        if not reductions:
            if self.last_boost_estimate:
                label, sample_time = self.last_boost_estimate
                if 0 <= now - sample_time <= BOOST_ESTIMATE_HOLD_SECONDS:
                    return label
            self.inferred_booster = None
            self.last_boost_estimate = None
            return tr('Boost learning')
        reduction = statistics.median(reductions)
        if max(reductions) - min(reductions) > .05:
            return tr('Mixed cycles')
        if reduction < .05:
            self.inferred_booster = None
            self.last_boost_estimate = None
            return tr('No boost observed')

        # CCP Mining Laser Optimization reference fits: level V, Burst II,
        # mindlink, with the Industrial Core inactive or a T2 core active.
        base = .15 * 1.5 * 1.25 * 1.25
        fits = {"Porpoise": (1.10, 1.075), "Orca": (1.15, 1.15), "Rorqual": (1.25, 1.40)}
        matches = {ship for ship, (hull, core) in fits.items()
                   if any(abs(reduction - base * hull * factor) <= .015 for factor in (1, core))}
        percent = f"{reduction:.0%}"
        if len(matches) == 1:
            self.inferred_booster = next(iter(matches))
        elif self.inferred_booster not in matches:
            self.inferred_booster = None
        label = (f"~{self.inferred_booster} Boost ({percent})" if self.inferred_booster
                 else f"~{percent}{tr(' cycle reduction')}")
        self.last_boost_estimate = label, latest_sample
        return label

    def free_fleet(self):
        volume, capacity, blocks, total_blocks, count, unconfirmed = D(0), D(0), 0, 0, 0, False
        for m in self.members:
            if m["ShipClass"] in BOOSTERS:
                continue
            ship = self.ship(m)
            free = max(D(0), ship["Capacity"] - ship["Volume"])
            volume += free
            capacity += ship["Capacity"]
            blocks += int(free // 1000)
            total_blocks += int(ship["Capacity"] // 1000)
            count += 1
            unconfirmed |= not ship["Known"] or bool(ship["Unknown"])
        return dict(Volume=volume, Blocks=blocks, Capacity=capacity, TotalBlocks=total_blocks,
                    Pilots=count, Unconfirmed=unconfirmed)

    def activity(self, name):
        return self.activities.setdefault(name, dict(Times=[], Since=self.started, Ratio=0))

    def observed(self, m):
        lasers = laser_count(m)
        times = sorted(self.activity(m["Character"])["Times"])[-12:]
        if lasers <= 0 or len(times) < max(6, lasers * 3):
            return 0
        values = [times[i] - times[i - lasers] for i in range(lasers, len(times)) if 5 <= times[i] - times[i - lasers] <= 600]
        return statistics.median(values) if values else 0

    def unequal_cadence(self, m):
        times = sorted(self.activity(m["Character"])["Times"])[-16:]
        if laser_count(m) != 2 or len(times) < 10:
            return 0
        values = sorted(times[i] - times[i - 2] for i in range(2, len(times)))
        median = statistics.median(values)
        low, high = values[math.floor((len(values) - 1) * .2)], values[math.ceil((len(values) - 1) * .8)]
        return median if median >= 5 and high - low >= 2 and low >= median * .8 and high <= median * 1.2 else 0

    def cycle(self, m, now):
        lasers, own, baseline = laser_count(m), self.observed(m), float(m.get("CycleSeconds", 0))
        seconds, source, settling = own or baseline, tr('Observed') if own else tr('Baseline'), False
        samples = []
        for peer in self.members:
            if peer["ShipClass"] != m["ShipClass"] or laser_count(peer) != lasers or lasers <= 0:
                continue
            observed = self.observed(peer)
            if observed > 0:
                if baseline > 0 and peer.get("CycleSeconds", 0) > 0:
                    samples.append(observed / float(peer["CycleSeconds"]))
                elif baseline <= 0:
                    samples.append(observed)
        if len(samples) >= 2:
            reference = statistics.median(samples)
            cohort = reference * baseline if baseline > 0 else reference
            activity = self.activity(m["Character"])
            dual = self.unequal_cadence(m)
            if dual > 0:
                activity["Ratio"] = dual / cohort
            expected = cohort * (activity["Ratio"] or 1)
            if own <= 0 or own > expected * 1.4 or own < expected * .7:
                seconds, source = expected, tr('Fleet estimate')
            elif activity["Ratio"] > 0:
                source = tr('Individual observed')
            if activity["Ratio"] <= 0 and own > cohort * 1.4 and len(activity["Times"]) < 10:
                seconds, source = own, tr('Learning individual cadence')
            key = (m["ShipClass"], lasers, baseline > 0)
            stored = self.references.setdefault(key, dict(Value=reference, Until=MIN_TIME))
            if abs(reference / stored["Value"] - 1) > .2:
                stored.update(Value=reference, Until=now + max(120, cohort * 3))
            settling = stored["Until"] > now
        elif baseline > 0 and own > baseline * 1.5:
            seconds, source = baseline, tr('Baseline (low event rate)')
        return dict(Seconds=seconds, Source=source, Settling=settling)

    def activity_warning(self, m, now):
        lasers, ship = laser_count(m), self.ship(m)
        if self.paused or lasers <= 0 or not ship["Known"] or self.red(ship):
            return ""
        activity = self.activity(m["Character"])
        since = max(activity["Since"], ship["ActivitySince"])
        timing = self.cycle(m, now)
        cycle, silence = timing["Seconds"], max(120, timing["Seconds"] * 3)
        times = sorted(t for t in activity["Times"] if t <= now)
        last = times[-1] if times else since
        peers = any(p["Character"] != m["Character"] and laser_count(p) > 0 and any(now - silence < t <= now for t in self.activity(p["Character"])["Times"]) for p in self.members)
        if now - since > silence and now - last > silence and peers:
            return tr('NO YIELD (fleet is mining)')
        if cycle <= 0 or timing["Settling"]:
            return ""
        recent = [t for t in times if t > now - 2.2 * cycle]
        required = 2 * lasers
        if len(recent) >= required and now - recent[-1] <= 1.4 * cycle:
            tail = recent[-required:]
            if tail[-1] - tail[0] >= .6 * cycle and all(tail[i] - tail[i - lasers] <= 1.4 * cycle for i in range(lasers, len(tail))):
                return ""
        window = min(600, max(120, cycle * 4))
        if now - since < window:
            return ""
        count = sum(t > now - window for t in times)
        return f"IRREGULAR (check {lasers} lasers)" if 0 < count < window / cycle * lasers * .7 else ""

    def eta(self, m, now):
        ship = self.ship(m)
        if not ship["Known"] or ship["Unknown"]:
            return tr('ETA verify'), None
        free = max(D(0), ship["Capacity"] - ship["Volume"])
        target = (free // 1000) * 1000 if self.state["Mode"] == "ICE" else free
        if target <= 0:
            return tr('Full'), 0
        events = sorted((e for e in self.state["Session"]["Events"] if e["Name"] == m["Character"] and max(self.started, now - 300) <= e["Time"] <= now), key=lambda e: e["Time"])
        if not events:
            return (tr('ETA --') if laser_count(m) <= 0 else tr('ETA paused') if now - self.started > 120 else tr('ETA learning')), None
        if now - events[-1]["Time"] > max(120, 2.5 * self.cycle(m, now)["Seconds"]):
            return tr('ETA paused'), None
        elapsed = events[-1]["Time"] - events[0]["Time"]
        if elapsed < 30:
            return tr('ETA learning'), None
        if any(e["Material"] not in self.items for e in events):
            return tr('ETA unknown'), None
        volume = sum((self.items[e["Material"]]["Volume"] * e["Quantity"] for e in events if e["Time"] > events[0]["Time"]), D(0))
        if volume <= 0:
            return tr('ETA learning'), None
        seconds = float(target / volume) * elapsed
        text = f"~{int(seconds // 3600)}h {int(seconds % 3600 // 60):02}m" if seconds >= 3600 else f"~{int(seconds // 60)}m {int(seconds % 60):02}s"
        return text, seconds

    def price_list(self):
        return "\n".join(name + "\t1" for name in sorted(self.reprocessing_products))

    def trend(self, now):
        buckets = [{} for _ in range(10)]
        mined = self.session_mined_quantities()
        for event in self.state["Session"]["Events"]:
            age = (now - event["Time"]) / 60
            if 0 <= age < 10:
                material, quantity = event["Material"], event["Quantity"]
                bucket = buckets[9 - int(age)]
                bucket[material] = bucket.get(material, D(0)) + quantity
                mined[material] = mined.get(material, D(0)) - quantity
        values = [0.] * 10
        if not any(buckets):
            return values
        # A batch earns its value in the minute when it becomes complete.
        products, _, _ = self.reprocess_quantities(mined, MAX_REPROCESS_YIELD)
        previous, _ = self.reprocessed_value(products)
        for index, bucket in enumerate(buckets):
            if not bucket:
                continue
            for material, quantity in bucket.items():
                mined[material] += quantity
            products, _, _ = self.reprocess_quantities(mined, MAX_REPROCESS_YIELD)
            value, _ = self.reprocessed_value(products)
            values[index] = float(value - previous) * 60
            previous = value
        return values
