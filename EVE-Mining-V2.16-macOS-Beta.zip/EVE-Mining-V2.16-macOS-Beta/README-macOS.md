# EVE Mining V2.16 for macOS

Moon ore reprocessing products are included in the price export. Import BUY
quotes to value them in Reprocess.

Reprocess shows bundled EVE icons for mined materials and the current price import date. Fallback sample prices retain their separate snapshot date.

The pilot editor can exclude yields at or below a volume cutoff from cycle
timing. Use 0 to disable the filter. Cargo and session totals include all yields.

ISK/h, session value and the trend use the BUY value of products recovered
in complete batches at 90.63% yield, before fees. Imported BUY quotes take
priority over the bundled product samples. Missing quotes or recipes make
the estimate partial. Export Reprocessing-products.txt from Options >
Prices / Janice to appraise the 43 reprocessing products at quantity 1.

The boost estimate tolerates an isolated irregular interval. Short gaps
retain the last reliable estimate for up to 120 seconds from its latest
sample. Select a pilot in Fleet profiles, tick Mining drones, then save and
activate the profile. This excludes yields of up to 50 m³ from cycle timing.
The pilot editor allows a different cutoff.

Style B shows tracked compressed cargo as a dashed grey segment. Hover
over the gauge to see the exact tracked compressed volume.

Tester build based on V2.16. It includes all three display styles, cargo and income tracking, reprocessing, alerts and the optional cargo reset. English and German Gamelogs are detected automatically. Choose the interface language under Options > Languages and restart. English is the default.

## Start

1. Install **Python 3.12** with Tk using the [official macOS installer](https://www.python.org/downloads/macos/). Use the **universal2 installer** for Apple Silicon or Intel.
2. Extract the ZIP into a writable local folder and open **Start EVE Mining.command**. The first run creates a local Python environment and downloads the pinned audio dependency from PyPI. Subsequent launches use the local environment.
3. In the app, open **Options > Fleet profiles**, choose the EVE **Gamelogs** folder containing character session logs, and click **Add pilots from logs**. Choose your ships and cargo capacities, then save and activate the fleet.
4. Under **Options > Alerts**, test each sound. In the fleet view, use secondary click or Control-click to set or confirm cargo.

If Finder does not open the launcher, open Terminal, type `/bin/bash ` (including the space), drag **Start EVE Mining.command** into the Terminal window and press Return.

## Files and tester feedback

Keep `Source`, `Sounds` and `Licenses` together. The app saves preferences and session data in `EVE-Mining.python-state.json` beside the launcher. Use the original ZIP for sharing. The folder created by first launch contains local state and the Python environment.

This ZIP runs from Python. A Mac is needed to verify Finder launch, Tk layout, game log selection and audio playback. Please include your macOS version, whether your Mac uses Apple Silicon or Intel, and any error message when reporting an issue.
