EVE Mining V2.1 - Python edition

START
Run EVE-Mining.exe. No Python installation or administrator rights are needed.
Keep Sounds and Licenses beside it in a writable local folder.
This edition uses Python 3.12, Tkinter and PyInstaller one-file packaging.
The bootloader extracts its bundled runtime to Windows' temporary directory
at startup. This is normal PyInstaller behavior, not a strict folder sandbox.
Application settings and your sound files remain beside the EXE.
The C# V2.0 edition is preserved separately.

QUICK SETUP
1. Open Fleet / prices > Fleet profiles and select local EVE Gamelogs.
2. Add pilots from logs. Double-click each pilot (or Edit selected).
3. Enter ship class, actual hold capacity, lasers and raw unboosted cycle.
   Usually 2 lasers for barges/exhumers, 0 for boosters; cycle 0 = automatic.
4. Name the profile, choose ICE / ORE, then Save and activate profile.
5. Confirm starting cargo: Reset if empty; otherwise right-click the pilot.
   Right-click Reset all to confirm all displayed cargo values together.
6. Alerts: choose cargo / attack sounds, test and Save alert settings.
English EVE mining/combat log notifications are required.

PROFILES AND UPDATES
Settings, profiles, cargo, prices and session are stored in
EVE-Mining.python-state.json, with .bak / .tmp files used during saving.
To migrate from C# V2.0 or V1.1, copy EVE-Mining.native-state.json beside
the EXE before first use. Python reads it only if no Python state exists.
The native state file is not modified. Future saves use the Python file.
The personal folder already contains your migrated Python settings.
For sharing, exclude BOTH state files, their backups/temporary files and
.python-instance.lock. Use the prepared blank Python-Share folder instead.
Do not zip your personal folder and assume profiles are removed.

LOCAL OPERATION
Reads only TXT logs in the configured local Gamelogs folder; never writes
or deletes those logs, controls EVE, or automates mining actions.
Prices and material volumes are bundled, with no network price requests,
browser launch, telemetry, updater or runtime shell-script execution.
Export compressed item list writes Compressed-items.txt beside the EXE.
The local .python-instance.lock prevents two instances in the same folder.
Windows, Python/Tk and SDL still provide ordinary UI, file and audio APIs.
OneDrive synchronization is independent of this application.
UNC paths and mapped network drives are not supported.

MINING
ICE / ORE volumes, compression, cargo resets, critical highlights (30s),
95% red warning, estimated time to full, irregular mining hints, miners'
free space excluding boosters, incoming-attack alerts, and auto-pause after
5 minutes without mining are included. The next mining yield resumes.
New session resets income/time while preserving cargo counters.
Reset after full transfers/jettison/unloading; correct partial cargo manually.
Headline ISK/h refreshes every 60 seconds, or on session/pause changes.
Unequal laser cycles and boosts are learned from recent log cadence.
Mining hints and ETA remain estimates; logs do not report cargo transfers.

PRICES
The 186 default BUY quotes are a dated snapshot, not live prices.
Raw units are valued at matching compressed BUY quotes; compression does
not count income a second time. Paste a new Janice-style price set manually,
or double-click a material to edit a BUY override. Only BUY prices are used.

SOUNDS
Add MP3/WAV files directly to Sounds and click Alerts > Refresh sounds.
Select cargo and attack sounds independently. Test / Stop preview are on
Alerts. Save alert settings persists choices. No Windows system-tone fallback.
Cargo volume and Attack volume each range from 0-100% (0% is silent).
Both start at 20%. Save alert settings keeps the levels; a running preview
can be adjusted with its slider. Actual alerts use the same saved levels.
Both bundled attack alarms are exactly four seconds long, with a short
fade at the end. They are now WAV files; existing selections of the two
old bundled MP3 names automatically map to the shortened WAV versions.
Cargo threshold is on Fleet profiles; changes save on Enter, focus loss
or the spin arrows. Cargo alerts re-arm after cargo drops below the limit.
Unknown/unconfirmed cargo does not trigger cargo audio; attack audio wins
priority and pending cargo audio waits until playback finishes.

DEVELOPERS
Optional Source contains the application, tests, build command and pinned
build requirements. Pillow is needed only for developer UI screenshots.
The packaged app excludes developer tests, Pillow and personal state.
Third-party notices and source references are in Licenses.
Changing language/packaging is not a guarantee against antivirus detections.
