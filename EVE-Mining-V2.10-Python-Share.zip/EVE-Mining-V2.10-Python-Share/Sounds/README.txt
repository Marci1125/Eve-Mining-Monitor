EVE Mining V2.7 - Local sounds

Put your own .mp3 or .wav files directly in this folder.
Open Fleet / prices > Alerts > Refresh sounds, select a file, test it and
click Save alert settings. Cargo and attack sounds can be chosen separately.
Cargo volume and Attack volume are independently adjustable (0-100%).
Default volume is 20%; Save alert settings keeps your choices.
Attack - Digital alarm.wav and Attack - Dino alarm.wav are each 4 seconds.
The original long MP3 versions have been replaced in this folder.
Use Stop preview to stop long samples. Short audio clips work best.
No subfolders, links, playlists, URLs or Windows system sounds are used.
Unsupported/corrupt files show a playback error rather than a fallback tone.
Keep this Sounds folder beside EVE-Mining.exe when moving/sharing the tool.
