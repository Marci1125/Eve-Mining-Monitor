EVE Mining V2.18 - Windows Share edition

NEW IN V2.18
Track Rock sits to the left of Reprocess. Enter the units remaining from
your scan. The first regular ICE or ORE yield in the selected mode identifies
the material. Matching yields and recorded residue reduce the estimate.
Critical bonus yield counts toward cargo. In Alerts, choose the warning
tone, volume and threshold for the next rock (default 10%). The bundled
The Asteroid is about to.wav plays for 3 seconds. Use a single target per
material and include all pilots mining it. Start a new estimate for each
rock. The estimate ends if you close the monitor or switch profile or mode.

NEW IN V2.17.3
Open Ledger on the main panel to see mining across all tracked pilots.
Filter the charts and table by material or by UTC date. Refresh reloads the
current session and completed sessions. New session archives the previous
session as JSON in Session Logs, beside the EXE. Keep that folder when
updating. Existing session totals without daily history appear as Date
unavailable. Past sessions cleared before this update are outside the archive.

NEW IN V2.17.1
The drone filter is always active. Yields of 50 m³ or less do not count as
laser cycle samples. They still count toward cargo, income and reprocessing.

NEW IN V2.17
Select multiple pilots in Fleet profiles with Shift or Ctrl/Command, then
click Edit selected to set ship class, actual capacity, lasers or raw cycle
for the group. Leave a field blank to keep each pilot's value. Save and
activate the profile to keep the edits. Double-click to edit a single pilot.

NEW IN V2.16
English and German Gamelogs are detected automatically. Options > Languages
sets the interface language after a restart. English is the default.

NEW IN V2.15.2
Style B shows tracked compressed cargo as a dashed grey segment. Hover
over the gauge to see the exact tracked compressed volume.

NEW IN V2.15.1
The boost estimate tolerates an isolated irregular interval. Short gaps
retain the last reliable estimate for up to 120 seconds from its latest
sample.

NEW IN V2.15
ISK/h, session value and the trend use the BUY value of products recovered
in complete batches at 90.63% yield, before fees. Imported BUY quotes take
priority over the bundled product samples. Missing quotes or recipes make
the estimate partial. Export Reprocessing-products.txt from Options >
Prices / Janice to appraise the 43 reprocessing products at quantity 1.

NEW IN V2.14.2
Reprocess shows bundled EVE icons for mined materials and the current price
import date. Fallback sample prices retain their separate snapshot date.

NEW IN V2.14.1
Moon ore reprocessing products are included in the price export. Import BUY
quotes to value them in Reprocess.

NEW IN V2.14
Style C Fleet Strip uses shallow cargo tiles with a colored fill, percentage
or recent yield, ETA and Reset. Choose it in Options > Display Style.

NEW IN V2.13.2
Style B compact cards are narrower and shorter. Gauges are centered in
each card. Expand keeps the larger gauges and cycle details. The cargo percentage is inside
the gauge and is temporarily replaced by recent +yield for five seconds.
Once the yield expires, the current percentage returns to the same place.

NEW IN V2.13.1
Fixes a startup sizing race that could compress the main window to its
initial Windows width. Both styles now keep their calculated layout width
when refreshing warnings or restoring the saved window position.
Switching from Style B back to Style A clears the old column grouping so
all pilots remain visible.

NEW IN V2.13
Options > Display Style switches between Style A bars and Style B cargo
gauges. Both show the same tracking, alerts, resets and yield indicators.
ICE holds show 100% when another whole block cannot fit. ORE uses actual
volume. Miners free shows remaining/total capacity, excluding boosters,
with green/yellow/orange/red status colors. The boost estimate uses raw versus observed laser cycles, including
external boosters. A prior ship estimate stays while readings still match;
clear changes can select another hull. Overlapping strengths can remain
ambiguous. The active fleet profile does not identify the boost source.

NEW IN V2.12.1
Final mining cycles logged within 10 seconds after Following ... in warp
no longer cancel automatic unloading detection. A later mining yield
still requires a new warp. No timeout is applied to the hangar message.

NEW IN V2.12
Optional automatic cargo reset on Fleet profiles. For each pilot, a mining
yield followed by Following ... in warp and a positive items-moved-to-hangar
notification resets cargo once. No time limit. Mining after the warp
cancels that pending warp; another warp is required. Manual reset, profile
or log-file changes, disabling the option, and restarting clear the chain.
Session income and reprocessing totals are retained. Partial unloading can
look the same in logs; only enable when you unload the entire mining hold.

NEW IN V2.11
Denser compact layout with smaller controls and a shorter header. Large
fleets use multiple columns so pilots stay visible without scrolling.
Expand still shows detailed cycle information.

NEW IN V2.10
The price export includes all four isotopes at quantity 1. Imported BUY
prices are used in Reprocess; missing SELL quotes remain unpriced.

NEW IN V2.9
Mining +quantity now appears for five seconds after a new log entry is read,
even when the game writes that entry late. Previously processed entries
are not displayed again.

NEW IN V2.8
A green +quantity beside each pilot shows mining yields for five seconds.
Simultaneous laser yields add together, including critical bonus units.
Works with both ICE and ORE.

NEW IN V2.7
Reprocessing product icons are bundled for every recipe output. Additional
icons come from the CCP EVE Image Server.

NEW IN V2.6
Last Price update shows the latest BUY import or the bundled snapshot date.
The date turns red after seven days. Reprocess tracks its sample prices
separately. Older imported data without a recorded date shows Unknown.

NEW IN V2.5
Reprocess shows mined materials and products in two tables with quantities,
volumes, and dated Janice sample prices where available. Heavy Water, Liquid
Ozone and Strontium Clathrates have local item icons.

NEW IN V2.4
Reprocess estimates products from the current mining session at an adjustable
yield (default 90.63%). It uses CCP SDE recipes, complete batches and whole
product units, before tax. Leftovers and unsupported items are listed.

NEW IN V2.3
A bright border marks each pilot crossing the cargo alert threshold for five
seconds. Multiple pilots can be highlighted together. The boost estimate is
based on recent log intervals and can lag changes in-game.

START
Run EVE-Mining.exe. No Python installation or administrator rights are needed.
Keep Sounds and Licenses beside it in a writable local folder.
This edition uses Python 3.12, Tkinter and PyInstaller one-file packaging.
The bootloader extracts its bundled runtime to Windows' temporary directory
at startup. This is normal PyInstaller behavior, not a strict folder sandbox.
Application settings and your sound files remain beside the EXE.
The C# V2.0 edition is preserved separately.

QUICK SETUP
1. Open Options > Fleet profiles and select local EVE Gamelogs.
2. Add pilots from logs. Select pilots and click Edit selected, or
   double-click a single pilot.
3. Enter ship class, actual hold capacity, lasers and raw unboosted cycle.
   Usually 2 lasers for barges/exhumers, 0 for boosters; cycle 0 = automatic.
4. Name the profile, choose ICE / ORE, then Save and activate profile.
5. Confirm starting cargo: Reset if empty; otherwise right-click the pilot.
   Right-click Reset all to confirm all displayed cargo values together.
6. Alerts: choose cargo / attack sounds, test and Save alert settings.
English and German EVE mining/combat log notifications are supported.

PROFILES AND UPDATES
Settings, profiles, cargo, prices and session are stored in
EVE-Mining.python-state.json, with .bak / .tmp files used during saving.
To migrate from C# V2.0 or V1.1, copy EVE-Mining.native-state.json beside
the EXE before first use. Python reads it only if no Python state exists.
The native state file is not modified. Future saves use the Python file.
This package starts with blank profiles and no selected Gamelogs folder.
To update, close the old app and copy your Python state file, Session Logs
and custom sounds into the new folder. Share the original ZIP.

LOCAL OPERATION
Reads only TXT logs in the configured local Gamelogs folder; never writes
or deletes those logs, controls EVE, or automates mining actions.
Prices and material volumes are bundled, with no network price requests,
browser launch, telemetry, updater or runtime shell-script execution.
Export price item list writes Reprocessing-products.txt beside the EXE.
The local .python-instance.lock prevents two instances in the same folder.
Windows, Python/Tk and SDL still provide ordinary UI, file and audio APIs.
OneDrive synchronization is independent of this application.
UNC paths and mapped network drives are not supported.

MINING
ICE / ORE volumes, compression, cargo resets, critical highlights (30s),
95% red warning, estimated time to full, irregular mining hints, miners'
free space excluding boosters, incoming-attack alerts, and auto-pause after
5 minutes without mining are included. The next mining yield resumes.
New session resets income/time while preserving cargo counters.
Reset after full transfers/jettison/unloading; correct partial cargo manually.
Headline ISK/h refreshes every 60 seconds, or on session/pause changes.
Unequal laser cycles and boosts are learned from recent log cadence.
Mining hints and ETA remain estimates; logs do not report cargo transfers.

PRICES
The income estimate uses the BUY prices of recovered products. Compressed
quotes can still value mined materials in the Reprocess input table. Paste
a Janice price set or double-click a material to edit its BUY override.

SOUNDS
Add MP3/WAV files directly to Sounds and click Alerts > Refresh sounds.
Select cargo and attack sounds independently. Test / Stop preview are on
Alerts. Save alert settings persists choices. No Windows system-tone fallback.
Cargo volume and Attack volume each range from 0-100% (0% is silent).
Both start at 20%. Save alert settings keeps the levels; a running preview
can be adjusted with its slider. Actual alerts use the same saved levels.
Both bundled attack alarms are exactly four seconds long, with a short
fade at the end. They are now WAV files; existing selections of the two
old bundled MP3 names automatically map to the shortened WAV versions.
Cargo threshold is on Fleet profiles; changes save on Enter, focus loss
or the spin arrows. Cargo alerts re-arm after cargo drops below the limit.
Unknown/unconfirmed cargo does not trigger cargo audio; attack audio wins
priority and pending cargo audio waits until playback finishes.

DEVELOPERS
Optional Source contains the application, tests, build command and pinned
build requirements. Pillow is needed only for developer UI screenshots.
The packaged app excludes developer tests, Pillow and personal state.
Third-party notices and source references are in Licenses.
Changing language/packaging is not a guarantee against antivirus detections.
